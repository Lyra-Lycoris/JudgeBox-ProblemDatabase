package t27_random_walk_expect

func solve(n: Int64, p: Int64, q: Int64): Int64 {
    // TODO: 返回从 0 出发首次到达 >= n 的期望步数对 1000000007 取模的结果
return 0
}
