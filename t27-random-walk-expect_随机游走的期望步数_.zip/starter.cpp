#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long p, long long q) {
    // TODO: 返回从 0 出发首次到达 >= n 的期望步数对 1000000007 取模的结果
return 0;
}
