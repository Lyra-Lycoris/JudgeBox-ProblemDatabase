    static long solve(long n, long p, long q) {
        // TODO: 返回从 0 出发首次到达 >= n 的期望步数对 1000000007 取模的结果
        return 0;
    }
