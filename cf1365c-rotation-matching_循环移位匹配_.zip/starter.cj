package cf1365c

func solve(n: Int64, a: Array<Int64>, b: Array<Int64>): Int64 {
    // TODO: 计算循环移位后最多相同的位置数
    return 0
}
