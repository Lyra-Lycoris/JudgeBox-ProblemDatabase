    static long solve(int n, long[] a, long[] b) {
        int[] pos = new int[n + 1];
        for (int i = 0; i < n; ++i) pos[(int) b[i]] = i;
        int[] count = new int[n];
        int best = 0;
        for (int i = 0; i < n; ++i) {
            int shift = (i - pos[(int) a[i]] + n) % n;
            ++count[shift];
            if (count[shift] > best) best = count[shift];
        }
        return best;
    }
