    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder sb = new StringBuilder();
        char[] buffer = new char[1 << 16];
        int read;
        while ((read = br.read(buffer)) > 0) {
            sb.append(buffer, 0, read);
        }
        StringTokenizer st = new StringTokenizer(sb.toString());
        int n = Integer.parseInt(st.nextToken());
        long[] a = new long[n];
        long[] b = new long[n];
        for (int i = 0; i < n; ++i) a[i] = Long.parseLong(st.nextToken());
        for (int i = 0; i < n; ++i) b[i] = Long.parseLong(st.nextToken());
        System.out.println(solve(n, a, b));
    }
