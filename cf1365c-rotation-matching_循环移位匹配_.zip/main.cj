package cf1365c

import std.collection.ArrayList
import std.convert.Parsable

main(): Unit {
    let tokens = ArrayList<String>()
    while (tokens.size < 1) {
        for (part in readln().trimAscii().split(" ")) {
            if (!part.isEmpty()) {
                tokens.add(part)
            }
        }
    }
    let n = Int64.parse(tokens[0])
    while (tokens.size < 2 * n + 1) {
        for (part in readln().trimAscii().split(" ")) {
            if (!part.isEmpty()) {
                tokens.add(part)
            }
        }
    }
    let a = Array<Int64>(n, repeat: 0)
    let b = Array<Int64>(n, repeat: 0)
    for (i in 0..n) {
        a[i] = Int64.parse(tokens[1 + i])
        b[i] = Int64.parse(tokens[1 + n + i])
    }
    println(solve(n, a, b))
}
