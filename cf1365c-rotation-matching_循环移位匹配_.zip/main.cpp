#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a, const vector<long long>& b);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n)) return 0;
    vector<long long> a(n), b(n);
    for (auto& x : a) cin >> x;
    for (auto& x : b) cin >> x;
    cout << solve(n, a, b) << '\n';
    return 0;
}
