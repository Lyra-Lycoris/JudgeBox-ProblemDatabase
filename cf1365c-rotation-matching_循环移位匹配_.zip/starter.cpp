#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a, const vector<long long>& b) {
    // TODO: 计算循环移位后最多相同的位置数
    (void)n;
    (void)a;
    (void)b;
    return 0;
}
