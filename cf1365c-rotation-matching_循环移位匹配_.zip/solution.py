def solve(n: int, a: list[int], b: list[int]) -> int:
    pos = [0] * (n + 1)
    for i, value in enumerate(b):
        pos[value] = i
    count = [0] * n
    best = 0
    for i, value in enumerate(a):
        shift = (i - pos[value]) % n
        c = count[shift] + 1
        count[shift] = c
        if c > best:
            best = c
    return best
