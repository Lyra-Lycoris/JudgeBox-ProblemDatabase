#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a, const vector<long long>& b) {
    vector<int> pos(n + 1, 0);
    for (int i = 0; i < n; ++i) pos[static_cast<int>(b[i])] = i;
    vector<int> count(n, 0);
    int best = 0;
    for (int i = 0; i < n; ++i) {
        int shift = (i - pos[static_cast<int>(a[i])] + n) % n;
        ++count[shift];
        if (count[shift] > best) best = count[shift];
    }
    return static_cast<long long>(best);
}
