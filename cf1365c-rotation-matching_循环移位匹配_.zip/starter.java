    static long solve(int n, long[] a, long[] b) {
        // TODO: 计算循环移位后最多相同的位置数
        return 0;
    }
