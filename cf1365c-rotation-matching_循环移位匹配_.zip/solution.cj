package cf1365c

func solve(n: Int64, a: Array<Int64>, b: Array<Int64>): Int64 {
    let pos = Array<Int64>(n + 1, repeat: 0)
    for (i in 0..n) {
        pos[b[i]] = i
    }
    let cnt = Array<Int64>(n, repeat: 0)
    var best = 0
    for (i in 0..n) {
        let shift = (i - pos[a[i]] + n) % n
        cnt[shift] += 1
        if (cnt[shift] > best) {
            best = cnt[shift]
        }
    }
    return best
}
