def solve(n: int, a: list[int], b: list[int]) -> int:
    # TODO: 计算循环移位后最多相同的位置数
    return 0
