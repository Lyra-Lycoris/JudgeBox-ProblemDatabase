#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回和最大的非空连续子段的和
return 0;
}
