import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回和最大的非空连续子段的和
    return 0
