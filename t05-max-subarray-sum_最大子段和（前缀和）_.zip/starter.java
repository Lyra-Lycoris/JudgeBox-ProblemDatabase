    static long solve(long n, long[] a) {
        // TODO: 返回和最大的非空连续子段的和
        return 0;
    }
