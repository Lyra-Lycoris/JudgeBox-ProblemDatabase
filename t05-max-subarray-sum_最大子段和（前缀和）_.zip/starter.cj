package t05_max_subarray_sum

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回和最大的非空连续子段的和
return 0
}
