#include <bits/stdc++.h>
using namespace std;

long long solve(long long l, long long r, long long k) {
    // TODO: 返回 [l, r] 中任意相邻两位数字之差都不超过 k 的整数个数
return 0;
}
