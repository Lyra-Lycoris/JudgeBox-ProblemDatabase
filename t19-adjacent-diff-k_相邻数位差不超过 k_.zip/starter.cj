package t19_adjacent_diff_k

func solve(l: Int64, r: Int64, k: Int64): Int64 {
    // TODO: 返回 [l, r] 中任意相邻两位数字之差都不超过 k 的整数个数
return 0
}
