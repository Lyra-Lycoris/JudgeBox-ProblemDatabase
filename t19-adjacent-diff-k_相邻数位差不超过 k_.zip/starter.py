import sys


def solve(l: int, r: int, k: int) -> int:
    # TODO: 返回 [l, r] 中任意相邻两位数字之差都不超过 k 的整数个数
    return 0
