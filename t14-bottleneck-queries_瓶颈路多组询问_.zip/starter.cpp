#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, long long q, const vector<vector<long long>>& e, const vector<vector<long long>>& queries) {
    // TODO: 对每个询问返回瓶颈值：路径上最大边权的最小可能值
return {};
}
