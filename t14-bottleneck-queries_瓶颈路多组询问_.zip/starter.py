import sys


def solve(n: int, m: int, q: int, e: list[list[int]], queries: list[list[int]]) -> list[int]:
    # TODO: 对每个询问返回瓶颈值：路径上最大边权的最小可能值
    return []
