package t14_bottleneck_queries

import std.convert.Parsable
import std.collection.*

var __tokens = ArrayList<String>()
var __cursor = 0

func __nextToken(): String {
    while (__cursor >= __tokens.size) {
        __tokens = ArrayList<String>()
        let parts = readln().trimAscii().split(" ")
        for (part in parts) {
            if (!part.isEmpty()) {
                __tokens.add(part)
            }
        }
        __cursor = 0
    }
    let value = __tokens[__cursor]
    __cursor += 1
    return value
}

func __nextInt(): Int64 {
    return Int64.parse(__nextToken())
}

func __nextInts(count: Int64): Array<Int64> {
    let values = Array<Int64>(count, repeat: 0)
    for (i in 0..count) {
        values[i] = __nextInt()
    }
    return values
}

func __nextStrings(count: Int64): Array<String> {
    let values = Array<String>(count, repeat: "")
    for (i in 0..count) {
        values[i] = __nextToken()
    }
    return values
}

main(): Unit {
    let n = __nextInt()
    let m = __nextInt()
    let q = __nextInt()
    let e = Array<Array<Int64>>(m, { _ => __nextInts(3) })
    let queries = Array<Array<Int64>>(q, { _ => __nextInts(2) })
    let __answer = solve(n, m, q, e, queries)
    for (i in 0..__answer.size) {
        if (i > 0) { print(" ") }
        print(__answer[i].toString())
    }
    println("")
}
