    static long[] solve(long n, long m, long q, long[][] e, long[][] queries) {
        // TODO: 对每个询问返回瓶颈值：路径上最大边权的最小可能值
        return new long[0];
    }
