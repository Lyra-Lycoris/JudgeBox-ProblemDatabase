#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, long long q, const vector<vector<long long>>& e, const vector<vector<long long>>& queries);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    long long q; cin >> q;
    vector<vector<long long>> e(m, vector<long long>(3)); for (auto& row : e) for (auto& x : row) cin >> x;
    vector<vector<long long>> queries(q, vector<long long>(2)); for (auto& row : queries) for (auto& x : row) cin >> x;
    vector<long long> answer = solve(n, m, q, e, queries);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
