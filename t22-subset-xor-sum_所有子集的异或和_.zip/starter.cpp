#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回所有 2^n 个子集的异或和之和对 10^9+7 取模的结果
return 0;
}
