import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回所有 2^n 个子集的异或和之和对 10^9+7 取模的结果
    return 0
