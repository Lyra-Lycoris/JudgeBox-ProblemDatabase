package t22_subset_xor_sum

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有 2^n 个子集的异或和之和对 10^9+7 取模的结果
return 0
}
