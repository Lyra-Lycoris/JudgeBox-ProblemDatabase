package t15_subtree_size

func solve(n: Int64, p: Array<Int64>): Array<Int64> {
    // TODO: 返回 n 个整数，第 i 个是节点 i 子树内的节点个数
return Array<Int64>()
}
