    static long[] solve(long n, long[] p) {
        // TODO: 返回 n 个整数，第 i 个是节点 i 子树内的节点个数
        return new long[0];
    }
