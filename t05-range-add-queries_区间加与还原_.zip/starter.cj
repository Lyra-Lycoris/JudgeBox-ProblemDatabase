package t05_range_add_queries

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 返回所有区间加操作执行完毕后的数组
return Array<Int64>()
}
