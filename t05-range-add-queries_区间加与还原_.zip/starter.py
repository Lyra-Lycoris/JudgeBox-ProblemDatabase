import sys


def solve(n: int, a: list[int], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 返回所有区间加操作执行完毕后的数组
    return []
