    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 返回所有区间加操作执行完毕后的数组
        return new long[0];
    }
