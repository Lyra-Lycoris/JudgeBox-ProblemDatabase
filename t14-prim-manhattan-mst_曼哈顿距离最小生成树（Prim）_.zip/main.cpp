#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& p);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<vector<long long>> p(n, vector<long long>(2)); for (auto& row : p) for (auto& x : row) cin >> x;
    long long answer = solve(n, p);
    cout << answer << '\n';
    return 0;
}
