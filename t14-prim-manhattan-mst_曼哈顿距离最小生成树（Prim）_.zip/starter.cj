package t14_prim_manhattan_mst

func solve(n: Int64, p: Array<Array<Int64>>): Int64 {
    // TODO: 返回曼哈顿距离完全图的最小生成树总权重
return 0
}
