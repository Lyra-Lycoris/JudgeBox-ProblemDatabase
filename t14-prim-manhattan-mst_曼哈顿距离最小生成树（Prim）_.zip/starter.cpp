#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& p) {
    // TODO: 返回曼哈顿距离完全图的最小生成树总权重
return 0;
}
