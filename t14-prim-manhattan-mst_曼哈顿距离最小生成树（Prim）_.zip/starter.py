import sys


def solve(n: int, p: list[list[int]]) -> int:
    # TODO: 返回曼哈顿距离完全图的最小生成树总权重
    return 0
