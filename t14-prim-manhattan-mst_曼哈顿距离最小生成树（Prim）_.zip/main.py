import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    p = [[int(x) for x in data[pos + r * 2: pos + (r + 1) * 2]] for r in range(n)]
    pos += n * 2
    print(solve(n, p))


main()
