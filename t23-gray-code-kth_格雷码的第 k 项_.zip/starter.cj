package t23_gray_code_kth

func solve(n: Int64, k: Int64): Int64 {
    // TODO: 返回 n 位格雷码序列中下标为 k（从 0 开始）的那一项的十进制值
return 0
}
