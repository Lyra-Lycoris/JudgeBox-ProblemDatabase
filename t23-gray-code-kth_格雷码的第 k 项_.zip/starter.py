import sys


def solve(n: int, k: int) -> int:
    # TODO: 返回 n 位格雷码序列中下标为 k（从 0 开始）的那一项的十进制值
    return 0
