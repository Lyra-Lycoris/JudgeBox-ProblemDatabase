#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k) {
    // TODO: 返回 n 位格雷码序列中下标为 k（从 0 开始）的那一项的十进制值
return 0;
}
