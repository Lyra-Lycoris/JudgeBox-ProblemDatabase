#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    long long answer = solve(n, k);
    cout << answer << '\n';
    return 0;
}
