    static long solve(long a, long b, long m) {
        // TODO: 返回 a 的 b 次方对 m 取模的结果（0^0 约定为 1）
        return 0;
    }
