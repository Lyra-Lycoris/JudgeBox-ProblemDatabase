import sys


def solve(a: int, b: int, m: int) -> int:
    # TODO: 返回 a 的 b 次方对 m 取模的结果（0^0 约定为 1）
    return 0
