import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    a = int(data[pos]); pos += 1
    b = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    print(solve(a, b, m))


main()
