package t23_fast_pow

func solve(a: Int64, b: Int64, m: Int64): Int64 {
    // TODO: 返回 a 的 b 次方对 m 取模的结果（0^0 约定为 1）
return 0
}
