#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& rects);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<vector<long long>> rects(n, vector<long long>(4)); for (auto& row : rects) for (auto& x : row) cin >> x;
    long long answer = solve(n, rects);
    cout << answer << '\n';
    return 0;
}
