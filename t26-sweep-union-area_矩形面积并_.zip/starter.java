    static long solve(long n, long[][] rects) {
        // TODO: 返回所有矩形覆盖区域的总面积（重叠部分只算一次）
        return 0;
    }
