import sys


def solve(n: int, rects: list[list[int]]) -> int:
    # TODO: 返回所有矩形覆盖区域的总面积（重叠部分只算一次）
    return 0
