import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    rects = [[int(x) for x in data[pos + r * 4: pos + (r + 1) * 4]] for r in range(n)]
    pos += n * 4
    print(solve(n, rects))


main()
