package t26_sweep_union_area

func solve(n: Int64, rects: Array<Array<Int64>>): Int64 {
    // TODO: 返回所有矩形覆盖区域的总面积（重叠部分只算一次）
return 0
}
