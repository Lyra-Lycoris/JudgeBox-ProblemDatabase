    static long solve(long n, long[] a, long k) {
        // TODO: 返回和能被 k 整除的非空连续子段个数
        return 0;
    }
