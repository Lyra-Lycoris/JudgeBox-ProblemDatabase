package t05_prefix_mod_pairs

func solve(n: Int64, a: Array<Int64>, k: Int64): Int64 {
    // TODO: 返回和能被 k 整除的非空连续子段个数
return 0
}
