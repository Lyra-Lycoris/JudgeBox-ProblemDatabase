#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long k) {
    // TODO: 返回和能被 k 整除的非空连续子段个数
return 0;
}
