import sys


def solve(n: int, a: list[int], k: int) -> int:
    # TODO: 返回和能被 k 整除的非空连续子段个数
    return 0
