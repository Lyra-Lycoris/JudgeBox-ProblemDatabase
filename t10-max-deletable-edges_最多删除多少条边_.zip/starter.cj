package t10_max_deletable_edges

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回在保持每个连通块内部连通的前提下最多能删除的边数
return 0
}
