    static long solve(long n, long m, long[][] e) {
        // TODO: 返回在保持每个连通块内部连通的前提下最多能删除的边数
        return 0;
    }
