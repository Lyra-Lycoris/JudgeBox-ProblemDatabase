#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回在保持每个连通块内部连通的前提下最多能删除的边数
return 0;
}
