import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回在保持每个连通块内部连通的前提下最多能删除的边数
    return 0
