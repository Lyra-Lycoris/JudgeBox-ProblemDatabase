#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<long long>& s, const vector<long long>& d);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<long long> s(m); for (auto& x : s) cin >> x;
    vector<long long> d(m); for (auto& x : d) cin >> x;
    long long answer = solve(n, m, s, d);
    cout << answer << '\n';
    return 0;
}
