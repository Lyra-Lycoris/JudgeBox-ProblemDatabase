package t09_meeting_rooms_busiest

func solve(n: Int64, m: Int64, s: Array<Int64>, d: Array<Int64>): Int64 {
    // TODO: 返回举办会议次数最多的会议室编号（并列取编号最小者）
return 0
}
