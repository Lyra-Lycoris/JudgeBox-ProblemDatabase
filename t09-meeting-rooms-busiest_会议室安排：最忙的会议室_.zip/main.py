import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    s = [int(x) for x in data[pos:pos + m]]; pos += m
    d = [int(x) for x in data[pos:pos + m]]; pos += m
    print(solve(n, m, s, d))


main()
