#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<long long>& s, const vector<long long>& d) {
    // TODO: 返回举办会议次数最多的会议室编号（并列取编号最小者）
return 0;
}
