import sys


def solve(n: int, m: int, s: list[int], d: list[int]) -> int:
    # TODO: 返回举办会议次数最多的会议室编号（并列取编号最小者）
    return 0
