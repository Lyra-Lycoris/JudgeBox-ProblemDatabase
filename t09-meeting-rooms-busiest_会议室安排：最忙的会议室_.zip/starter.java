    static long solve(long n, long m, long[] s, long[] d) {
        // TODO: 返回举办会议次数最多的会议室编号（并列取编号最小者）
        return 0;
    }
