#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<string>& tokens) {
    // TODO: 返回逆波兰表达式的值，除法向零取整
return 0;
}
