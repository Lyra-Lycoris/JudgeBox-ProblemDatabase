#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<string>& tokens);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long k; cin >> k;
    vector<string> tokens(k); for (auto& x : tokens) cin >> x;
    long long answer = solve(k, tokens);
    cout << answer << '\n';
    return 0;
}
