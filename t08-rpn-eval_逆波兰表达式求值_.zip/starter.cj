package t08_rpn_eval

func solve(k: Int64, tokens: Array<String>): Int64 {
    // TODO: 返回逆波兰表达式的值，除法向零取整
return 0
}
