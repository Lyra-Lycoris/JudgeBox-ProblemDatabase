    static long solve(long k, String[] tokens) {
        // TODO: 返回逆波兰表达式的值，除法向零取整
        return 0;
    }
