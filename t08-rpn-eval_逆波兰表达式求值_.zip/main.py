import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    k = int(data[pos]); pos += 1
    tokens = [x.decode() for x in data[pos:pos + k]]; pos += k
    print(solve(k, tokens))


main()
