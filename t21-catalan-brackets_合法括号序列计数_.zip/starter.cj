package t21_catalan_brackets

func solve(n: Int64): Int64 {
    // TODO: 返回由 n 对括号构成的合法括号序列个数对 1000000007 取模的结果
return 0
}
