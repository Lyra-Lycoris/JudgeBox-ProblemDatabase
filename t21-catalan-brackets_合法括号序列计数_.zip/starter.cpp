#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回由 n 对括号构成的合法括号序列个数对 1000000007 取模的结果
return 0;
}
