package t19_obstacle_paths

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>): Int64 {
    // TODO: 返回从左上角走到右下角、只向右或向下且不经过障碍的路径数对 1000000007 取模的结果
return 0
}
