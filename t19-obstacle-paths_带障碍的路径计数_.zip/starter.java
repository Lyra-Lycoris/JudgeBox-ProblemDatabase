    static long solve(long n, long m, long[][] g) {
        // TODO: 返回从左上角走到右下角、只向右或向下且不经过障碍的路径数对 1000000007 取模的结果
        return 0;
    }
