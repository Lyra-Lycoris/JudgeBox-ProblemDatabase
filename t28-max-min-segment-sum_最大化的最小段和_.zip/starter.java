    static long solve(long n, long k, long[] a) {
        // TODO: 返回所有切分方案中「最小段和」的最大值
        return 0;
    }
