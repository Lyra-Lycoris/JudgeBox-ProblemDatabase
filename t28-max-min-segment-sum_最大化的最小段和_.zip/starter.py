import sys


def solve(n: int, k: int, a: list[int]) -> int:
    # TODO: 返回所有切分方案中「最小段和」的最大值
    return 0
