#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回所有切分方案中「最小段和」的最大值
return 0;
}
