package t28_max_min_segment_sum

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有切分方案中「最小段和」的最大值
return 0
}
