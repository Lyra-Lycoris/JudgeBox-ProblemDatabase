package t07_longest_consecutive

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回最长的一段连续整数的长度（相同数值只算一个）
return 0
}
