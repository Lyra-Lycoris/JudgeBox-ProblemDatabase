    static long solve(long n, long[] a) {
        // TODO: 返回最长的一段连续整数的长度（相同数值只算一个）
        return 0;
    }
