#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回最长的一段连续整数的长度（相同数值只算一个）
return 0;
}
