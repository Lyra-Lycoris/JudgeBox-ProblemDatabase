import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回最长的一段连续整数的长度（相同数值只算一个）
    return 0
