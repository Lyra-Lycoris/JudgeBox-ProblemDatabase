import sys


def solve(n: int, ids: list[int], chinese: list[int], math: list[int], english: list[int]) -> list[int]:
    # TODO: 返回按规则排名后的学号序列
    return []
