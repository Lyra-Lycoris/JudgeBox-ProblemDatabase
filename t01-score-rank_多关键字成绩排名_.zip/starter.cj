package t01_score_rank

func solve(n: Int64, ids: Array<Int64>, chinese: Array<Int64>, math: Array<Int64>, english: Array<Int64>): Array<Int64> {
    // TODO: 返回按规则排名后的学号序列
return Array<Int64>()
}
