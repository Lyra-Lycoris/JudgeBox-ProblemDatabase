    static long[] solve(long n, long[] ids, long[] chinese, long[] math, long[] english) {
        // TODO: 返回按规则排名后的学号序列
        return new long[0];
    }
