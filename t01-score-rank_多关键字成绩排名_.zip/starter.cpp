#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& ids, const vector<long long>& chinese, const vector<long long>& math, const vector<long long>& english) {
    // TODO: 返回按规则排名后的学号序列
return {};
}
