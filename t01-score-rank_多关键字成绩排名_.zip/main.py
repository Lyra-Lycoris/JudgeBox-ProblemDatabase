import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    ids = [int(x) for x in data[pos:pos + n]]; pos += n
    chinese = [int(x) for x in data[pos:pos + n]]; pos += n
    math = [int(x) for x in data[pos:pos + n]]; pos += n
    english = [int(x) for x in data[pos:pos + n]]; pos += n
    print(' '.join(str(x) for x in solve(n, ids, chinese, math, english)))


main()
