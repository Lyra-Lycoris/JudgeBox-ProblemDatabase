#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& ids, const vector<long long>& chinese, const vector<long long>& math, const vector<long long>& english);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> ids(n); for (auto& x : ids) cin >> x;
    vector<long long> chinese(n); for (auto& x : chinese) cin >> x;
    vector<long long> math(n); for (auto& x : math) cin >> x;
    vector<long long> english(n); for (auto& x : english) cin >> x;
    vector<long long> answer = solve(n, ids, chinese, math, english);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
