    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long[] ids = new long[(int) (n)];
        for (int i = 0; i < ids.length; ++i) ids[i] = Long.parseLong(st.nextToken());
        long[] chinese = new long[(int) (n)];
        for (int i = 0; i < chinese.length; ++i) chinese[i] = Long.parseLong(st.nextToken());
        long[] math = new long[(int) (n)];
        for (int i = 0; i < math.length; ++i) math[i] = Long.parseLong(st.nextToken());
        long[] english = new long[(int) (n)];
        for (int i = 0; i < english.length; ++i) english[i] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, ids, chinese, math, english);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
