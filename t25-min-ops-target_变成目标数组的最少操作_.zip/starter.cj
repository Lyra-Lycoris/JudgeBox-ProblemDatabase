package t25_min_ops_target

func solve(n: Int64, a: Array<Int64>, b: Array<Int64>): Int64 {
    // TODO: 返回把 a 变成 b 的最少操作次数（每次可把一段连续子数组整体加 1 或整体减 1）
return 0
}
