package t21_coprime_count

func solve(n: Int64, m: Int64): Int64 {
    // TODO: 返回 1 到 n 中与 m 互素（gcd(x, m) = 1）的整数个数
return 0
}
