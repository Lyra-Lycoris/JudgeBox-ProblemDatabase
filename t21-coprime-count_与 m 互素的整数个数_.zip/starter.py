import sys


def solve(n: int, m: int) -> int:
    # TODO: 返回 1 到 n 中与 m 互素（gcd(x, m) = 1）的整数个数
    return 0
