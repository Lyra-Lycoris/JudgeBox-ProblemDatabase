#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m) {
    // TODO: 返回 1 到 n 中与 m 互素（gcd(x, m) = 1）的整数个数
return 0;
}
