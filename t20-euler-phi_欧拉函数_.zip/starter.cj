package t20_euler_phi

func solve(n: Int64): Int64 {
    // TODO: 返回 φ(n)，即 1 到 n 中与 n 互质的整数个数
return 0
}
