#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 φ(n)，即 1 到 n 中与 n 互质的整数个数
return 0;
}
