    static long solve(long n, long[] a) {
        // TODO: 返回最长严格上升子序列的长度
        return 0;
    }
