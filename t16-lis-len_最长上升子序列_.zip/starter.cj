package t16_lis_len

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回最长严格上升子序列的长度
return 0
}
