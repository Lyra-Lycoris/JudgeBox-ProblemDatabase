import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回最长严格上升子序列的长度
    return 0
