import sys


def solve(n: int, m: int, e: list[list[int]]) -> bool:
    # TODO: 判断无向图是否为二分图：是输出 YES，否则 NO
    return False
