package t13_bipartite_check

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Bool {
    // TODO: 判断无向图是否为二分图：是输出 YES，否则 NO
return false
}
