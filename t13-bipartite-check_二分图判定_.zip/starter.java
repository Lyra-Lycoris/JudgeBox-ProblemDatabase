    static boolean solve(long n, long m, long[][] e) {
        // TODO: 判断无向图是否为二分图：是输出 YES，否则 NO
        return false;
    }
