#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 判断无向图是否为二分图：是输出 YES，否则 NO
return false;
}
