    static long solve(long n, long m, long[][] g) {
        // TODO: 返回只由 1 组成的子矩形中面积的最大值，没有 1 时返回 0
        return 0;
    }
