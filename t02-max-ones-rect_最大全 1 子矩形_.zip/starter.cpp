#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& g) {
    // TODO: 返回只由 1 组成的子矩形中面积的最大值，没有 1 时返回 0
return 0;
}
