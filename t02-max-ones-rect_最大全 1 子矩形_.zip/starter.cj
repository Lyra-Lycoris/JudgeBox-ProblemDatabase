package t02_max_ones_rect

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>): Int64 {
    // TODO: 返回只由 1 组成的子矩形中面积的最大值，没有 1 时返回 0
return 0
}
