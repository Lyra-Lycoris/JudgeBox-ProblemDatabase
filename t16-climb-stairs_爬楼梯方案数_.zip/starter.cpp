#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回爬上 n 级台阶的方案数对 1000000007 取模的结果
return 0;
}
