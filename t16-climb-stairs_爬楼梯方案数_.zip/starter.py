import sys


def solve(n: int) -> int:
    # TODO: 返回爬上 n 级台阶的方案数对 1000000007 取模的结果
    return 0
