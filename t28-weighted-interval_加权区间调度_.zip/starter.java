    static long solve(long n, long[][] seg) {
        // TODO: 返回能选出的互不重叠区间的最大总权重
        return 0;
    }
