#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& seg);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<vector<long long>> seg(n, vector<long long>(3)); for (auto& row : seg) for (auto& x : row) cin >> x;
    long long answer = solve(n, seg);
    cout << answer << '\n';
    return 0;
}
