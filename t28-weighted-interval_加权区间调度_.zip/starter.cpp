#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& seg) {
    // TODO: 返回能选出的互不重叠区间的最大总权重
return 0;
}
