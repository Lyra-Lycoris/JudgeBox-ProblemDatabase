package t28_weighted_interval

func solve(n: Int64, seg: Array<Array<Int64>>): Int64 {
    // TODO: 返回能选出的互不重叠区间的最大总权重
return 0
}
