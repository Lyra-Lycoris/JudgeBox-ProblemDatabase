import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    seg = [[int(x) for x in data[pos + r * 3: pos + (r + 1) * 3]] for r in range(n)]
    pos += n * 3
    print(solve(n, seg))


main()
