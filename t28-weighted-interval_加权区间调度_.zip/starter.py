import sys


def solve(n: int, seg: list[list[int]]) -> int:
    # TODO: 返回能选出的互不重叠区间的最大总权重
    return 0
