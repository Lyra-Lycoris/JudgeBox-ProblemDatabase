    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 按顺序返回每次区间最大值询问的答案
        return new long[0];
    }
