package t26_sqrt_range_add_max

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次区间最大值询问的答案
return Array<Int64>()
}
