#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& ops) {
    // TODO: 按顺序返回每次区间最大值询问的答案
return {};
}
