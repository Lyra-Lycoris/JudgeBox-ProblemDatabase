#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long cap, const vector<long long>& w, const vector<long long>& v) {
    // TODO: 返回容量 cap 下 0/1 背包能取得的最大价值
return 0;
}
