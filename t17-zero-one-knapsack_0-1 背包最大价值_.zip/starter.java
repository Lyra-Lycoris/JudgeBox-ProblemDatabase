    static long solve(long n, long cap, long[] w, long[] v) {
        // TODO: 返回容量 cap 下 0/1 背包能取得的最大价值
        return 0;
    }
