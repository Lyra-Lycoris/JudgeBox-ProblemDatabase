    static boolean solve(long n, long[] a, long target) {
        // TODO: 返回是否存在两个不同下标的元素之和等于 target
        return false;
    }
