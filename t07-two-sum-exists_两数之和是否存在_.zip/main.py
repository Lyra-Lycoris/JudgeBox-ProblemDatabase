import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    target = int(data[pos]); pos += 1
    print('YES' if solve(n, a, target) else 'NO')


main()
