package t07_two_sum_exists

func solve(n: Int64, a: Array<Int64>, target: Int64): Bool {
    // TODO: 返回是否存在两个不同下标的元素之和等于 target
return false
}
