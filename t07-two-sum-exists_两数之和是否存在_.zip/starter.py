import sys


def solve(n: int, a: list[int], target: int) -> bool:
    # TODO: 返回是否存在两个不同下标的元素之和等于 target
    return False
