#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, const vector<long long>& a, long long target) {
    // TODO: 返回是否存在两个不同下标的元素之和等于 target
return false;
}
