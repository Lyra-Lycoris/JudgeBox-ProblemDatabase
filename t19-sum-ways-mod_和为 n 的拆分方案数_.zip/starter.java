    static long solve(long n, long m) {
        // TODO: 返回把 n 拆成不超过 m 的正整数之和的方案数对 1000000007 取模的结果
        return 0;
    }
