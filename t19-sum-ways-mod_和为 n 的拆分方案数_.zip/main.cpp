#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    long long answer = solve(n, m);
    cout << answer << '\n';
    return 0;
}
