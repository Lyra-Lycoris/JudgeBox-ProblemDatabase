#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long m, const vector<long long>& b) {
    // TODO: 返回合并后有序数组中中间两个元素之和（长度为奇数时就是中位数的两倍）
return 0;
}
