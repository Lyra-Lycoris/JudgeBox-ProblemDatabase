package t25_two_sorted_median

func solve(n: Int64, a: Array<Int64>, m: Int64, b: Array<Int64>): Int64 {
    // TODO: 返回合并后有序数组中中间两个元素之和（长度为奇数时就是中位数的两倍）
return 0
}
