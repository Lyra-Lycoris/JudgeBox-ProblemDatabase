    static long solve(long n, long[] a, long m, long[] b) {
        // TODO: 返回合并后有序数组中中间两个元素之和（长度为奇数时就是中位数的两倍）
        return 0;
    }
