import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    m = int(data[pos]); pos += 1
    op = [int(x) for x in data[pos:pos + m]]; pos += m
    val = [int(x) for x in data[pos:pos + m]]; pos += m
    print(' '.join(str(x) for x in solve(m, op, val)))


main()
