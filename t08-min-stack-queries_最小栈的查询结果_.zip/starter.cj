package t08_min_stack_queries

func solve(m: Int64, op: Array<Int64>, val: Array<Int64>): Array<Int64> {
    // TODO: 按顺序执行操作，返回所有查询操作（op=3）得到的最小值，按发生顺序排列
return Array<Int64>()
}
