import sys


def solve(m: int, op: list[int], val: list[int]) -> list[int]:
    # TODO: 按顺序执行操作，返回所有查询操作（op=3）得到的最小值，按发生顺序排列
    return []
