    static long[] solve(long m, long[] op, long[] val) {
        // TODO: 按顺序执行操作，返回所有查询操作（op=3）得到的最小值，按发生顺序排列
        return new long[0];
    }
