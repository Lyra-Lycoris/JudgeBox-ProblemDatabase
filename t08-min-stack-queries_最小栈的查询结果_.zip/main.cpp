#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long m, const vector<long long>& op, const vector<long long>& val);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long m; cin >> m;
    vector<long long> op(m); for (auto& x : op) cin >> x;
    vector<long long> val(m); for (auto& x : val) cin >> x;
    vector<long long> answer = solve(m, op, val);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
