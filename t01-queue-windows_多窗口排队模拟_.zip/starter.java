    static long solve(long n, long k, long[] arrive, long[] serve) {
        // TODO: 返回所有顾客等待时间之和
        return 0;
    }
