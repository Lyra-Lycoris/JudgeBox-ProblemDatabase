import sys


def solve(n: int, k: int, arrive: list[int], serve: list[int]) -> int:
    # TODO: 返回所有顾客等待时间之和
    return 0
