#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& arrive, const vector<long long>& serve) {
    // TODO: 返回所有顾客等待时间之和
return 0;
}
