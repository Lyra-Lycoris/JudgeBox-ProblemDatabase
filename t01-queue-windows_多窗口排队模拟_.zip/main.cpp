#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& arrive, const vector<long long>& serve);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<long long> arrive(n); for (auto& x : arrive) cin >> x;
    vector<long long> serve(n); for (auto& x : serve) cin >> x;
    long long answer = solve(n, k, arrive, serve);
    cout << answer << '\n';
    return 0;
}
