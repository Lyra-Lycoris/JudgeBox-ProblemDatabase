import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    arrive = [int(x) for x in data[pos:pos + n]]; pos += n
    serve = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, k, arrive, serve))


main()
