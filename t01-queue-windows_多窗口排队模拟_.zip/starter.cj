package t01_queue_windows

func solve(n: Int64, k: Int64, arrive: Array<Int64>, serve: Array<Int64>): Int64 {
    // TODO: 返回所有顾客等待时间之和
return 0
}
