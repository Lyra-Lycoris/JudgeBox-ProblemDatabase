import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 统计满足 i < j < k 且 a[i] + a[j] + a[k] = 0 的三元组个数
    return 0
