package t02_triple_zero

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 统计满足 i < j < k 且 a[i] + a[j] + a[k] = 0 的三元组个数
return 0
}
