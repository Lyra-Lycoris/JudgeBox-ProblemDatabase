#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 统计满足 i < j < k 且 a[i] + a[j] + a[k] = 0 的三元组个数
return 0;
}
