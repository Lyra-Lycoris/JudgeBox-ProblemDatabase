    static long solve(long n, long[] a) {
        // TODO: 统计满足 i < j < k 且 a[i] + a[j] + a[k] = 0 的三元组个数
        return 0;
    }
