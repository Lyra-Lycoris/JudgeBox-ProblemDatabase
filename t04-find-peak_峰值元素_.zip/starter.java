    static long solve(long n, long[] a) {
        // TODO: 返回任意一个峰值元素的下标（从 0 开始），评测使用特殊评判
        return 0;
    }
