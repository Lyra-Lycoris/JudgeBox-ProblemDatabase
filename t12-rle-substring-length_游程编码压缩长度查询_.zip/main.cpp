#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, string s, long long q, const vector<vector<long long>>& qs);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    string s; cin >> s;
    long long q; cin >> q;
    vector<vector<long long>> qs(q, vector<long long>(2)); for (auto& row : qs) for (auto& x : row) cin >> x;
    vector<long long> answer = solve(n, s, q, qs);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
