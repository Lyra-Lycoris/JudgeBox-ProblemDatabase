import sys


def solve(n: int, s: str, q: int, qs: list[list[int]]) -> list[int]:
    # TODO: 对每个询问返回子串 s[l..r] 的游程编码长度
    return []
