    static long[] solve(long n, String s, long q, long[][] qs) {
        // TODO: 对每个询问返回子串 s[l..r] 的游程编码长度
        return new long[0];
    }
