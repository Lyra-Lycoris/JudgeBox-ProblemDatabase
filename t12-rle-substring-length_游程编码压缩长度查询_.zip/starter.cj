package t12_rle_substring_length

func solve(n: Int64, s: String, q: Int64, qs: Array<Array<Int64>>): Array<Int64> {
    // TODO: 对每个询问返回子串 s[l..r] 的游程编码长度
return Array<Int64>()
}
