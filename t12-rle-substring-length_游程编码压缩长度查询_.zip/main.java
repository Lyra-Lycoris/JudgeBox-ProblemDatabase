    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        String s = st.nextToken();
        long q = Long.parseLong(st.nextToken());
        long[][] qs = new long[(int) (q)][(int) (2)];
        for (int i = 0; i < qs.length; ++i) for (int j = 0; j < qs[i].length; ++j) qs[i][j] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, s, q, qs);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
