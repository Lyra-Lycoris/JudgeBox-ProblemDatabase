#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, string s, long long q, const vector<vector<long long>>& qs) {
    // TODO: 对每个询问返回子串 s[l..r] 的游程编码长度
return {};
}
