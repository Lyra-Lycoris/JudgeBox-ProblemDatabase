package t04_rope_cutting

func solve(n: Int64, a: Array<Int64>, k: Int64): Int64 {
    // TODO: 返回能切出的 k 段等长绳子的最大长度（整数厘米）；若长度为 1 也切不出 k 段则返回 0
return 0
}
