import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    s = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    print(' '.join(str(x) for x in solve(s, k)))


main()
