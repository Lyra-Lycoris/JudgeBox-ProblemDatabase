package t25_k_positive_sum

func solve(s: Int64, k: Int64): Array<Int64> {
    // TODO: 返回恰好 k 个正整数，它们的和等于 s；本题使用特殊评判
return Array<Int64>()
}
