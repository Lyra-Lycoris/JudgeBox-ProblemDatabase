#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long s, long long k) {
    // TODO: 返回恰好 k 个正整数，它们的和等于 s；本题使用特殊评判
return {};
}
