#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long s, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long s; cin >> s;
    long long k; cin >> k;
    vector<long long> answer = solve(s, k);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
