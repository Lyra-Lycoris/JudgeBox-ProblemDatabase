package t11_kth_smallest_dynamic

func solve(q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次第 k 小查询的答案
return Array<Int64>()
}
