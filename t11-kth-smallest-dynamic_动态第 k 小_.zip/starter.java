    static long[] solve(long q, long[][] ops) {
        // TODO: 按顺序返回每次第 k 小查询的答案
        return new long[0];
    }
