#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long q, const vector<vector<long long>>& ops) {
    // TODO: 按顺序返回每次第 k 小查询的答案
return {};
}
