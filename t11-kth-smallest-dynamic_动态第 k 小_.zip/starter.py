import sys


def solve(q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次第 k 小查询的答案
    return []
