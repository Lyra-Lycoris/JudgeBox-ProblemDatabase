    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long q = Long.parseLong(st.nextToken());
        long[][] ops = new long[(int) (q)][(int) (2)];
        for (int i = 0; i < ops.length; ++i) for (int j = 0; j < ops[i].length; ++j) ops[i][j] = Long.parseLong(st.nextToken());
        long[] __answer = solve(q, ops);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
