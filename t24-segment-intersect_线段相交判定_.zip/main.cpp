#include <bits/stdc++.h>
using namespace std;

bool solve(long long ax, long long ay, long long bx, long long by, long long cx, long long cy, long long dx, long long dy);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while (T--) {
        long long ax; cin >> ax;
        long long ay; cin >> ay;
        long long bx; cin >> bx;
        long long by; cin >> by;
        long long cx; cin >> cx;
        long long cy; cin >> cy;
        long long dx; cin >> dx;
        long long dy; cin >> dy;
        bool answer = solve(ax, ay, bx, by, cx, cy, dx, dy);
        cout << (answer ? "YES" : "NO") << '\n';
    }
    return 0;
}
