import sys


def solve(ax: int, ay: int, bx: int, by: int, cx: int, cy: int, dx: int, dy: int) -> bool:
    # TODO: 返回线段 AB 与线段 CD 是否有公共点
    return False
