    static boolean solve(long ax, long ay, long bx, long by, long cx, long cy, long dx, long dy) {
        // TODO: 返回线段 AB 与线段 CD 是否有公共点
        return false;
    }
