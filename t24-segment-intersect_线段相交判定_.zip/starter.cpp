#include <bits/stdc++.h>
using namespace std;

bool solve(long long ax, long long ay, long long bx, long long by, long long cx, long long cy, long long dx, long long dy) {
    // TODO: 返回线段 AB 与线段 CD 是否有公共点
return false;
}
