package t24_segment_intersect

func solve(ax: Int64, ay: Int64, bx: Int64, by: Int64, cx: Int64, cy: Int64, dx: Int64, dy: Int64): Bool {
    // TODO: 返回线段 AB 与线段 CD 是否有公共点
return false
}
