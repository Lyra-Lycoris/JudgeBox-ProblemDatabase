    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        int T = Integer.parseInt(st.nextToken());
        for (int __case = 0; __case < T; ++__case) {
            long ax = Long.parseLong(st.nextToken());
            long ay = Long.parseLong(st.nextToken());
            long bx = Long.parseLong(st.nextToken());
            long by = Long.parseLong(st.nextToken());
            long cx = Long.parseLong(st.nextToken());
            long cy = Long.parseLong(st.nextToken());
            long dx = Long.parseLong(st.nextToken());
            long dy = Long.parseLong(st.nextToken());
            System.out.println(solve(ax, ay, bx, by, cx, cy, dx, dy) ? "YES" : "NO");
        }
    }
