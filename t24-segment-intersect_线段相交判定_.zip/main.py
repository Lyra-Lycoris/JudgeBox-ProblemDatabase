import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    for _ in range(t):
        ax = int(data[pos]); pos += 1
        ay = int(data[pos]); pos += 1
        bx = int(data[pos]); pos += 1
        by = int(data[pos]); pos += 1
        cx = int(data[pos]); pos += 1
        cy = int(data[pos]); pos += 1
        dx = int(data[pos]); pos += 1
        dy = int(data[pos]); pos += 1
        print('YES' if solve(ax, ay, bx, by, cx, cy, dx, dy) else 'NO')


main()
