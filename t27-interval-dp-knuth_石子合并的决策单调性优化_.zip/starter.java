    static long solve(long n, long[] a) {
        // TODO: 返回把所有石子合并成一堆的最小总代价
        return 0;
    }
