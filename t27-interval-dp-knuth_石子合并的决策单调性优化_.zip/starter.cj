package t27_interval_dp_knuth

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把所有石子合并成一堆的最小总代价
return 0
}
