    static long solve(long n, long m) {
        // TODO: 返回在 n 行 m 列棋盘上放置互不攻击的国王的方案数（可以一个都不放）
        return 0;
    }
