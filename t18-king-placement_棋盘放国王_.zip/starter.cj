package t18_king_placement

func solve(n: Int64, m: Int64): Int64 {
    // TODO: 返回在 n 行 m 列棋盘上放置互不攻击的国王的方案数（可以一个都不放）
return 0
}
