#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n) {
    // TODO: 输出 n 个互不相同的整数，每个在 [1, 10^18] 内，且相邻两项按位与为 0
return {};
}
