import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    print(' '.join(str(x) for x in solve(n)))


main()
