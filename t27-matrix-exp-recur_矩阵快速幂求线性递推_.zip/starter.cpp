#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long x, long long y, long long p, long long q) {
    // TODO: 返回 f(n) 对 1000000007 取模的结果
return 0;
}
