    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long x = Long.parseLong(st.nextToken());
        long y = Long.parseLong(st.nextToken());
        long p = Long.parseLong(st.nextToken());
        long q = Long.parseLong(st.nextToken());
        System.out.println(solve(n, x, y, p, q));
    }
