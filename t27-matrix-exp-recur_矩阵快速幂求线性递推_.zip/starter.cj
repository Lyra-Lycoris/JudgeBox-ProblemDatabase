package t27_matrix_exp_recur

func solve(n: Int64, x: Int64, y: Int64, p: Int64, q: Int64): Int64 {
    // TODO: 返回 f(n) 对 1000000007 取模的结果
return 0
}
