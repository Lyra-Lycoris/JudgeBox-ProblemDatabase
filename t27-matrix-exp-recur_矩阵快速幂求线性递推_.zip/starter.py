import sys


def solve(n: int, x: int, y: int, p: int, q: int) -> int:
    # TODO: 返回 f(n) 对 1000000007 取模的结果
    return 0
