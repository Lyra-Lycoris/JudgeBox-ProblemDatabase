    static long solve(long n, long x, long y, long p, long q) {
        // TODO: 返回 f(n) 对 1000000007 取模的结果
        return 0;
    }
