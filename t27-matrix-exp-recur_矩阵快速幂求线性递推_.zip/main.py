import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    x = int(data[pos]); pos += 1
    y = int(data[pos]); pos += 1
    p = int(data[pos]); pos += 1
    q = int(data[pos]); pos += 1
    print(solve(n, x, y, p, q))


main()
