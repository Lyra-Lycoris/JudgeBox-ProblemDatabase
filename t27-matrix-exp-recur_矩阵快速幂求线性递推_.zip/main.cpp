#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long x, long long y, long long p, long long q);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long x; cin >> x;
    long long y; cin >> y;
    long long p; cin >> p;
    long long q; cin >> q;
    long long answer = solve(n, x, y, p, q);
    cout << answer << '\n';
    return 0;
}
