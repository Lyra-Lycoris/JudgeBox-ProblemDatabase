#include <bits/stdc++.h>
using namespace std;

long long solve(string start, string target, long long n, const vector<string>& dead);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string start; cin >> start;
    string target; cin >> target;
    long long n; cin >> n;
    vector<string> dead(n); for (auto& x : dead) cin >> x;
    long long answer = solve(start, target, n, dead);
    cout << answer << '\n';
    return 0;
}
