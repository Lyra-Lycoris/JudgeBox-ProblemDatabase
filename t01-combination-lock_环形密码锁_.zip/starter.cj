package t01_combination_lock

func solve(start: String, target: String, n: Int64, dead: Array<String>): Int64 {
    // TODO: 返回最少转动次数，无法到达返回 -1
return 0
}
