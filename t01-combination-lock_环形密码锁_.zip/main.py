import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    start = data[pos].decode(); pos += 1
    target = data[pos].decode(); pos += 1
    n = int(data[pos]); pos += 1
    dead = [x.decode() for x in data[pos:pos + n]]; pos += n
    print(solve(start, target, n, dead))


main()
