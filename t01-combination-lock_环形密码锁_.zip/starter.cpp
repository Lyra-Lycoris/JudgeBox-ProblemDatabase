#include <bits/stdc++.h>
using namespace std;

long long solve(string start, string target, long long n, const vector<string>& dead) {
    // TODO: 返回最少转动次数，无法到达返回 -1
return 0;
}
