import sys


def solve(start: str, target: str, n: int, dead: list[str]) -> int:
    # TODO: 返回最少转动次数，无法到达返回 -1
    return 0
