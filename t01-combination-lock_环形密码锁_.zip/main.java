    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        String start = st.nextToken();
        String target = st.nextToken();
        long n = Long.parseLong(st.nextToken());
        String[] dead = new String[(int) (n)];
        for (int i = 0; i < dead.length; ++i) dead[i] = st.nextToken();
        System.out.println(solve(start, target, n, dead));
    }
