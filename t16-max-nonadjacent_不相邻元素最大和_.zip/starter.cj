package t16_max_nonadjacent

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回不能同时选取相邻元素时能取得的最大和
return 0
}
