import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回不能同时选取相邻元素时能取得的最大和
    return 0
