#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回所有元素和恰好为 k 的连续子数组个数
return 0;
}
