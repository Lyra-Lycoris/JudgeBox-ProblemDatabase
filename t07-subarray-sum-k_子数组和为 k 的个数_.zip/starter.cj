package t07_subarray_sum_k

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有元素和恰好为 k 的连续子数组个数
return 0
}
