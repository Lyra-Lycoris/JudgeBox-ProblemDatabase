import sys


def solve(n: int, k: int, a: list[int]) -> int:
    # TODO: 返回所有元素和恰好为 k 的连续子数组个数
    return 0
