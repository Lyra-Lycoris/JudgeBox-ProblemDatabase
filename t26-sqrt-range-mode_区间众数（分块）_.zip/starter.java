    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 按顺序返回每次询问区间 [l, r] 的众数（并列时取较小值）
        return new long[0];
    }
