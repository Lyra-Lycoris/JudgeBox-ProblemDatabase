import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    q = int(data[pos]); pos += 1
    ops = [[int(x) for x in data[pos + r * 2: pos + (r + 1) * 2]] for r in range(q)]
    pos += q * 2
    print(' '.join(str(x) for x in solve(n, a, q, ops)))


main()
