#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& ops);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> a(n); for (auto& x : a) cin >> x;
    long long q; cin >> q;
    vector<vector<long long>> ops(q, vector<long long>(2)); for (auto& row : ops) for (auto& x : row) cin >> x;
    vector<long long> answer = solve(n, a, q, ops);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
