import sys


def solve(n: int, a: list[int], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次询问区间 [l, r] 的众数（并列时取较小值）
    return []
