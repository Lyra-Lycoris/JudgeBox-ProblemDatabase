#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& ops) {
    // TODO: 按顺序返回每次询问区间 [l, r] 的众数（并列时取较小值）
return {};
}
