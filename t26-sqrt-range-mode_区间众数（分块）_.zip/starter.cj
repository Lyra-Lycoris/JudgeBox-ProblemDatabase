package t26_sqrt_range_mode

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次询问区间 [l, r] 的众数（并列时取较小值）
return Array<Int64>()
}
