    static long solve(long n, String s) {
        // TODO: 返回第一个只出现一次的字符的下标（从 1 开始），不存在返回 -1
        return 0;
    }
