#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<string>& words) {
    // TODO: 返回互不相同的异位词分组个数
return 0;
}
