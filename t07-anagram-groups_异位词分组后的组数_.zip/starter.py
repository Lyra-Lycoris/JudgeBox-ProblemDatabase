import sys


def solve(n: int, words: list[str]) -> int:
    # TODO: 返回互不相同的异位词分组个数
    return 0
