import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    words = [x.decode() for x in data[pos:pos + n]]; pos += n
    print(solve(n, words))


main()
