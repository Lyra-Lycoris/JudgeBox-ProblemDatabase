#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<string>& words);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<string> words(n); for (auto& x : words) cin >> x;
    long long answer = solve(n, words);
    cout << answer << '\n';
    return 0;
}
