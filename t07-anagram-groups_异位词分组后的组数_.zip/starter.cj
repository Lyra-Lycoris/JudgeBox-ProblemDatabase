package t07_anagram_groups

func solve(n: Int64, words: Array<String>): Int64 {
    // TODO: 返回互不相同的异位词分组个数
return 0
}
