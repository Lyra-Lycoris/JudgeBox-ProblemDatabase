    static long solve(long n, String[] words) {
        // TODO: 返回互不相同的异位词分组个数
        return 0;
    }
