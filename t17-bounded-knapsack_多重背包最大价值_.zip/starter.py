import sys


def solve(n: int, cap: int, w: list[int], v: list[int], c: list[int]) -> int:
    # TODO: 返回容量 cap 下多重背包能取得的最大价值
    return 0
