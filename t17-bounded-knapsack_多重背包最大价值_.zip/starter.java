    static long solve(long n, long cap, long[] w, long[] v, long[] c) {
        // TODO: 返回容量 cap 下多重背包能取得的最大价值
        return 0;
    }
