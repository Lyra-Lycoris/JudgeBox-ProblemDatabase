    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long cap = Long.parseLong(st.nextToken());
        long[] w = new long[(int) (n)];
        for (int i = 0; i < w.length; ++i) w[i] = Long.parseLong(st.nextToken());
        long[] v = new long[(int) (n)];
        for (int i = 0; i < v.length; ++i) v[i] = Long.parseLong(st.nextToken());
        long[] c = new long[(int) (n)];
        for (int i = 0; i < c.length; ++i) c[i] = Long.parseLong(st.nextToken());
        System.out.println(solve(n, cap, w, v, c));
    }
