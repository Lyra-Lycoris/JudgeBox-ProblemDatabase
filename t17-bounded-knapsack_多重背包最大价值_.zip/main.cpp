#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long cap, const vector<long long>& w, const vector<long long>& v, const vector<long long>& c);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long cap; cin >> cap;
    vector<long long> w(n); for (auto& x : w) cin >> x;
    vector<long long> v(n); for (auto& x : v) cin >> x;
    vector<long long> c(n); for (auto& x : c) cin >> x;
    long long answer = solve(n, cap, w, v, c);
    cout << answer << '\n';
    return 0;
}
