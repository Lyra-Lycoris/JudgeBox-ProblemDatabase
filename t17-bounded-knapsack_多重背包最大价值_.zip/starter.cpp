#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long cap, const vector<long long>& w, const vector<long long>& v, const vector<long long>& c) {
    // TODO: 返回容量 cap 下多重背包能取得的最大价值
return 0;
}
