package t17_bounded_knapsack

func solve(n: Int64, cap: Int64, w: Array<Int64>, v: Array<Int64>, c: Array<Int64>): Int64 {
    // TODO: 返回容量 cap 下多重背包能取得的最大价值
return 0
}
