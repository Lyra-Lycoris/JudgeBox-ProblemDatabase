import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回所有数对 a[i] xor a[j] (i < j) 的最大值
    return 0
