#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回所有数对 a[i] xor a[j] (i < j) 的最大值
return 0;
}
