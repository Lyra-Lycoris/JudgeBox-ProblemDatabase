package t02_max_xor_pair

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有数对 a[i] xor a[j] (i < j) 的最大值
return 0
}
