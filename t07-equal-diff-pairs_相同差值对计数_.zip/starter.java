    static long solve(long n, long[] a) {
        // TODO: 返回满足 |a[i]-a[j]| = |i-j| 的下标对 (i<j) 个数
        return 0;
    }
