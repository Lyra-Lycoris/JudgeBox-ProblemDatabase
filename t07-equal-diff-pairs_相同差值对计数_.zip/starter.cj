package t07_equal_diff_pairs

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回满足 |a[i]-a[j]| = |i-j| 的下标对 (i<j) 个数
return 0
}
