import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回满足 i < j 且 a[i] > a[j] 的数对个数
    return 0
