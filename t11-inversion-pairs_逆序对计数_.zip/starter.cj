package t11_inversion_pairs

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回满足 i < j 且 a[i] > a[j] 的数对个数
return 0
}
