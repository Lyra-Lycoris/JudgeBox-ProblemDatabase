import sys


def solve(n: int) -> int:
    # TODO: 返回首次出现连续 n 次正面所需抛掷次数的期望 E_n 对 1000000007 取模的结果（E_n 一定是整数）
    return 0
