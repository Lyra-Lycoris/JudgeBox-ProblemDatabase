#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k) {
    // TODO: 返回最后剩下的人的编号（从 1 开始）
return 0;
}
