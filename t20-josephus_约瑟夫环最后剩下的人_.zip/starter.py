import sys


def solve(n: int, k: int) -> int:
    # TODO: 返回最后剩下的人的编号（从 1 开始）
    return 0
