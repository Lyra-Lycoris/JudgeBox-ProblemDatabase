package t20_josephus

func solve(n: Int64, k: Int64): Int64 {
    // TODO: 返回最后剩下的人的编号（从 1 开始）
return 0
}
