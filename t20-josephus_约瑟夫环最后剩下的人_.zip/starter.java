    static long solve(long n, long k) {
        // TODO: 返回最后剩下的人的编号（从 1 开始）
        return 0;
    }
