package t10_kruskal_mst

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回最小生成树的总权重；图不连通时返回 -1
return 0
}
