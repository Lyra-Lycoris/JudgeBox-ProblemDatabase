    static long solve(long n, long m, long[][] e) {
        // TODO: 返回最小生成树的总权重；图不连通时返回 -1
        return 0;
    }
