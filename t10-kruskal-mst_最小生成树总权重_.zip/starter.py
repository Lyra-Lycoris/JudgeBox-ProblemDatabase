import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回最小生成树的总权重；图不连通时返回 -1
    return 0
