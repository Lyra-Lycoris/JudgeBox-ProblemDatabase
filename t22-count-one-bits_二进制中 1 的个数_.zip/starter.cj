package t22_count_one_bits

func solve(n: Int64): Int64 {
    // TODO: 返回 n 的二进制表示中数字 1 的个数
return 0
}
