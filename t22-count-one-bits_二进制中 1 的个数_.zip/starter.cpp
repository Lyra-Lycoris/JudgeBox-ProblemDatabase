#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 n 的二进制表示中数字 1 的个数
return 0;
}
