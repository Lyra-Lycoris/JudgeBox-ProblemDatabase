#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long m, const vector<long long>& b, long long x);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> a(n); for (auto& x : a) cin >> x;
    long long m; cin >> m;
    vector<long long> b(m); for (auto& x : b) cin >> x;
    long long x; cin >> x;
    long long answer = solve(n, a, m, b, x);
    cout << answer << '\n';
    return 0;
}
