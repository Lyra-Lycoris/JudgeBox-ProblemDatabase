import sys


def solve(n: int, a: list[int], m: int, b: list[int], x: int) -> int:
    # TODO: 返回满足 a[i] + b[j] <= x 的下标对 (i, j) 的数量
    return 0
