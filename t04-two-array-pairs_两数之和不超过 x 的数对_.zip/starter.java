    static long solve(long n, long[] a, long m, long[] b, long x) {
        // TODO: 返回满足 a[i] + b[j] <= x 的下标对 (i, j) 的数量
        return 0;
    }
