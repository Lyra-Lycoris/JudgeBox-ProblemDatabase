#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long m, const vector<long long>& b, long long x) {
    // TODO: 返回满足 a[i] + b[j] <= x 的下标对 (i, j) 的数量
return 0;
}
