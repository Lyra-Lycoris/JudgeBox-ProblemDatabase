package t04_two_array_pairs

func solve(n: Int64, a: Array<Int64>, m: Int64, b: Array<Int64>, x: Int64): Int64 {
    // TODO: 返回满足 a[i] + b[j] <= x 的下标对 (i, j) 的数量
return 0
}
