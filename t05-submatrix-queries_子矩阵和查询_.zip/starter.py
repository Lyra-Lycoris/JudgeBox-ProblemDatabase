import sys


def solve(n: int, m: int, g: list[list[int]], q: int, queries: list[list[int]]) -> list[int]:
    # TODO: 依次返回每个查询子矩阵内元素之和
    return []
