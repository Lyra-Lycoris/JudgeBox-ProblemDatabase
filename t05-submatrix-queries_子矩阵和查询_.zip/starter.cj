package t05_submatrix_queries

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>, q: Int64, queries: Array<Array<Int64>>): Array<Int64> {
    // TODO: 依次返回每个查询子矩阵内元素之和
return Array<Int64>()
}
