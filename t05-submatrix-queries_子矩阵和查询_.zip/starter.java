    static long[] solve(long n, long m, long[][] g, long q, long[][] queries) {
        // TODO: 依次返回每个查询子矩阵内元素之和
        return new long[0];
    }
