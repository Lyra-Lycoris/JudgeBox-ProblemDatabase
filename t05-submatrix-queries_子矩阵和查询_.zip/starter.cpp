#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<vector<long long>>& g, long long q, const vector<vector<long long>>& queries) {
    // TODO: 依次返回每个查询子矩阵内元素之和
return {};
}
