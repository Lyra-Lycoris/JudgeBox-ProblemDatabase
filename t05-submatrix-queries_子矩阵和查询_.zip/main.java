    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long m = Long.parseLong(st.nextToken());
        long[][] g = new long[(int) (n)][(int) (m)];
        for (int i = 0; i < g.length; ++i) for (int j = 0; j < g[i].length; ++j) g[i][j] = Long.parseLong(st.nextToken());
        long q = Long.parseLong(st.nextToken());
        long[][] queries = new long[(int) (q)][(int) (4)];
        for (int i = 0; i < queries.length; ++i) for (int j = 0; j < queries[i].length; ++j) queries[i][j] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, m, g, q, queries);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
