import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    g = [[int(x) for x in data[pos + r * m: pos + (r + 1) * m]] for r in range(n)]
    pos += n * m
    q = int(data[pos]); pos += 1
    queries = [[int(x) for x in data[pos + r * 4: pos + (r + 1) * 4]] for r in range(q)]
    pos += q * 4
    print(' '.join(str(x) for x in solve(n, m, g, q, queries)))


main()
