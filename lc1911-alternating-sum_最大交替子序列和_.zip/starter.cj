package lc1911

func solve(nums: Array<Int64>): Int64 {
    // TODO: 求所有非空子序列交替和的最大值
    return 0
}
