#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& nums) {
    // TODO: 求所有非空子序列交替和的最大值
    (void)nums;
    return 0;
}
