package lc1911

func solve(nums: Array<Int64>): Int64 {
    // up:   已选子序列的最后一个元素取 + 号时的最大交替和
    // down: 已选子序列的最后一个元素取 - 号时的最大交替和
    let neg: Int64 = -1152921504606846976
    var up = neg
    var down = 0
    for (x in nums) {
        let nup = max(up, down + x)
        let ndown = max(down, up - x)
        up = nup
        down = ndown
    }
    return up
}
