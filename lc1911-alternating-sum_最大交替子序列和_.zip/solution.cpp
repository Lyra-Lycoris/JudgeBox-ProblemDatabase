#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& nums) {
    const long long NEG = -(1LL << 60);
    // up:   已选子序列的最后一个元素取 + 号时的最大交替和
    // down: 已选子序列的最后一个元素取 - 号时的最大交替和
    long long up = NEG, down = 0;
    for (long long x : nums) {
        long long nup = max(up, down + x);
        long long ndown = max(down, up - x);
        up = nup;
        down = ndown;
    }
    return up;
}
