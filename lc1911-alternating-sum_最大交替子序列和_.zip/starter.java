    static long solve(long[] nums) {
        // TODO: 求所有非空子序列交替和的最大值
        return 0;
    }
