    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine().trim());
        long[] nums = new long[n];
        int index = 0;
        while (index < n) {
            String line = br.readLine();
            if (line == null) break;
            StringTokenizer st = new StringTokenizer(line);
            while (st.hasMoreTokens() && index < n) {
                nums[index++] = Long.parseLong(st.nextToken());
            }
        }
        System.out.println(solve(nums));
    }
