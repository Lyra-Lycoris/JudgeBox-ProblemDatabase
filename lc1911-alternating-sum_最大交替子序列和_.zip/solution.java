    static long solve(long[] nums) {
        final long NEG = -(1L << 60);
        long up = NEG, down = 0;
        for (long x : nums) {
            long nup = Math.max(up, down + x);
            long ndown = Math.max(down, up - x);
            up = nup;
            down = ndown;
        }
        return up;
    }
