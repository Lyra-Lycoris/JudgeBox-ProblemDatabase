def solve(nums: list[int]) -> int:
    neg = -(1 << 60)
    up, down = neg, 0
    for x in nums:
        up, down = max(up, down + x), max(down, up - x)
    return up
