package t05_range_cover_max

func solve(n: Int64, q: Int64, segs: Array<Array<Int64>>): Array<Int64> {
    // TODO: 返回两个整数：最大覆盖次数、以及达到它的最左位置
return Array<Int64>()
}
