import sys


def solve(n: int, q: int, segs: list[list[int]]) -> list[int]:
    # TODO: 返回两个整数：最大覆盖次数、以及达到它的最左位置
    return []
