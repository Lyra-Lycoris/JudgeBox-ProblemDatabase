    static long[] solve(long n, long q, long[][] segs) {
        // TODO: 返回两个整数：最大覆盖次数、以及达到它的最左位置
        return new long[0];
    }
