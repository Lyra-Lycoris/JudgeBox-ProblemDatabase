#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long q, const vector<vector<long long>>& segs) {
    // TODO: 返回两个整数：最大覆盖次数、以及达到它的最左位置
return {};
}
