#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& w) {
    // TODO: 返回从 0 号城市出发、恰好经过每座城市一次并回到 0 号城市的最小花费，无解返回 -1
return 0;
}
