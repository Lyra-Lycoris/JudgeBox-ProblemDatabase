package t18_tsp_cycle

func solve(n: Int64, w: Array<Array<Int64>>): Int64 {
    // TODO: 返回从 0 号城市出发、恰好经过每座城市一次并回到 0 号城市的最小花费，无解返回 -1
return 0
}
