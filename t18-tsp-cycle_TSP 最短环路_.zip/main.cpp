#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& w);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<vector<long long>> w(n, vector<long long>(n)); for (auto& row : w) for (auto& x : row) cin >> x;
    long long answer = solve(n, w);
    cout << answer << '\n';
    return 0;
}
