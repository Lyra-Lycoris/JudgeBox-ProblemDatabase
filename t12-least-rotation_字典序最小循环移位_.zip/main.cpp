#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    string s; cin >> s;
    long long answer = solve(n, s);
    cout << answer << '\n';
    return 0;
}
