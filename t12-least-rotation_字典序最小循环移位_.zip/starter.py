import sys


def solve(n: int, s: str) -> int:
    # TODO: 返回字典序最小的循环移位的起始下标（从 0 开始），并列时取最小下标
    return 0
