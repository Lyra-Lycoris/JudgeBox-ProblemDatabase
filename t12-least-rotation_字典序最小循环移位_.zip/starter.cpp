#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string s) {
    // TODO: 返回字典序最小的循环移位的起始下标（从 0 开始），并列时取最小下标
return 0;
}
