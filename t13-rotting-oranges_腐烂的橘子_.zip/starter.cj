package t13_rotting_oranges

func solve(n: Int64, m: Int64, grid: Array<Array<Int64>>): Int64 {
    // TODO: 返回所有新鲜橘子都腐烂所需的最少分钟数，若不可能则返回 -1
return 0
}
