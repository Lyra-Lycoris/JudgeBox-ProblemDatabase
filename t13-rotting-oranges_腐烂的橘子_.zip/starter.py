import sys


def solve(n: int, m: int, grid: list[list[int]]) -> int:
    # TODO: 返回所有新鲜橘子都腐烂所需的最少分钟数，若不可能则返回 -1
    return 0
