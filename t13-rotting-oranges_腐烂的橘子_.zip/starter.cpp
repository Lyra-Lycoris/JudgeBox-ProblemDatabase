#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& grid) {
    // TODO: 返回所有新鲜橘子都腐烂所需的最少分钟数，若不可能则返回 -1
return 0;
}
