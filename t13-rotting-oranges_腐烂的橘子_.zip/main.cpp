#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& grid);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<vector<long long>> grid(n, vector<long long>(m)); for (auto& row : grid) for (auto& x : row) cin >> x;
    long long answer = solve(n, m, grid);
    cout << answer << '\n';
    return 0;
}
