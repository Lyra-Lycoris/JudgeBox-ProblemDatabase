    static long[] solve(long n) {
        // TODO: 输出任意一个长度为 n、每项在 [1, 10^9] 内且相邻两项按位与为 0 的数组
        return new long[0];
    }
