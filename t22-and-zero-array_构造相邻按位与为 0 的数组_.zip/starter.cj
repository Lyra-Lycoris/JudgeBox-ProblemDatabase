package t22_and_zero_array

func solve(n: Int64): Array<Int64> {
    // TODO: 输出任意一个长度为 n、每项在 [1, 10^9] 内且相邻两项按位与为 0 的数组
return Array<Int64>()
}
