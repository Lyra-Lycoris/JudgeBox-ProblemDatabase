#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, long long p) {
    // TODO: 返回 C(n, k) mod p，其中 p 是质数且 n < p
return 0;
}
