package t20_comb_mod

func solve(n: Int64, k: Int64, p: Int64): Int64 {
    // TODO: 返回 C(n, k) mod p，其中 p 是质数且 n < p
return 0
}
