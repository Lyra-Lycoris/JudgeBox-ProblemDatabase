#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, long long p);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    long long p; cin >> p;
    long long answer = solve(n, k, p);
    cout << answer << '\n';
    return 0;
}
