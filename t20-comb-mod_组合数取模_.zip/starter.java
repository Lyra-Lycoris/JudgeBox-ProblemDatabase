    static long solve(long n, long k, long p) {
        // TODO: 返回 C(n, k) mod p，其中 p 是质数且 n < p
        return 0;
    }
