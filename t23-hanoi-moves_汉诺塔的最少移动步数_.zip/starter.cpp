#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回把 n 个圆盘从 A 柱移到 C 柱的最少移动次数
return 0;
}
