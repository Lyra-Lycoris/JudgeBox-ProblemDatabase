package t23_hanoi_moves

func solve(n: Int64): Int64 {
    // TODO: 返回把 n 个圆盘从 A 柱移到 C 柱的最少移动次数
return 0
}
