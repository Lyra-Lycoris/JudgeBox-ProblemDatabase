import sys


def solve(n: int) -> int:
    # TODO: 返回把 n 个圆盘从 A 柱移到 C 柱的最少移动次数
    return 0
