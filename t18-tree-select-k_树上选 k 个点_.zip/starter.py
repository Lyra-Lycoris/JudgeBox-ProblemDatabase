import sys


def solve(n: int, k: int, w: list[int], p: list[int]) -> int:
    # TODO: 返回满足“选了点就必须选它的父亲”的恰好 k 个点的最大权值和
    return 0
