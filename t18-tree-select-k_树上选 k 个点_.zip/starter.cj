package t18_tree_select_k

func solve(n: Int64, k: Int64, w: Array<Int64>, p: Array<Int64>): Int64 {
    // TODO: 返回满足“选了点就必须选它的父亲”的恰好 k 个点的最大权值和
return 0
}
