#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& w, const vector<long long>& p) {
    // TODO: 返回满足“选了点就必须选它的父亲”的恰好 k 个点的最大权值和
return 0;
}
