#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& w, const vector<long long>& p);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<long long> w(n); for (auto& x : w) cin >> x;
    vector<long long> p(n-1); for (auto& x : p) cin >> x;
    long long answer = solve(n, k, w, p);
    cout << answer << '\n';
    return 0;
}
