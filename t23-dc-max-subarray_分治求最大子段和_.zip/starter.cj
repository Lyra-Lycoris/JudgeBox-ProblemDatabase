package t23_dc_max_subarray

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有非空连续子段和的最大值
return 0
}
