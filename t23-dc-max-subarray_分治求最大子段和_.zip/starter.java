    static long solve(long n, long[] a) {
        // TODO: 返回所有非空连续子段和的最大值
        return 0;
    }
