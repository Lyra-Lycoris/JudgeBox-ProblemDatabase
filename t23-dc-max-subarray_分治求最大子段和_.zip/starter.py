import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回所有非空连续子段和的最大值
    return 0
