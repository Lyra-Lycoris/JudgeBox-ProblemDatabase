#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<string>& words, long long q, const vector<string>& queries) {
    // TODO: 对每个询问返回以它作为前缀的单词个数
return {};
}
