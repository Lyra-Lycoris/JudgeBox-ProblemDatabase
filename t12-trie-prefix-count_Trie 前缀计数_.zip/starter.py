import sys


def solve(n: int, words: list[str], q: int, queries: list[str]) -> list[int]:
    # TODO: 对每个询问返回以它作为前缀的单词个数
    return []
