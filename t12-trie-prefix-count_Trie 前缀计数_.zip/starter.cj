package t12_trie_prefix_count

func solve(n: Int64, words: Array<String>, q: Int64, queries: Array<String>): Array<Int64> {
    // TODO: 对每个询问返回以它作为前缀的单词个数
return Array<Int64>()
}
