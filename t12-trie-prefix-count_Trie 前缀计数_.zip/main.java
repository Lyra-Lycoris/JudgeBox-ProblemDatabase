    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        String[] words = new String[(int) (n)];
        for (int i = 0; i < words.length; ++i) words[i] = st.nextToken();
        long q = Long.parseLong(st.nextToken());
        String[] queries = new String[(int) (q)];
        for (int i = 0; i < queries.length; ++i) queries[i] = st.nextToken();
        long[] __answer = solve(n, words, q, queries);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
