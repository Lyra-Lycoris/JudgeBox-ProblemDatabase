#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<string>& words, long long q, const vector<string>& queries);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<string> words(n); for (auto& x : words) cin >> x;
    long long q; cin >> q;
    vector<string> queries(q); for (auto& x : queries) cin >> x;
    vector<long long> answer = solve(n, words, q, queries);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
