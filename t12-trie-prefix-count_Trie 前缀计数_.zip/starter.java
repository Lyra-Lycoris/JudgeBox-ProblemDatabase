    static long[] solve(long n, String[] words, long q, String[] queries) {
        // TODO: 对每个询问返回以它作为前缀的单词个数
        return new long[0];
    }
