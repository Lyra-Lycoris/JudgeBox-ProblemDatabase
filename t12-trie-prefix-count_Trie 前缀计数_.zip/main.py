import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    words = [x.decode() for x in data[pos:pos + n]]; pos += n
    q = int(data[pos]); pos += 1
    queries = [x.decode() for x in data[pos:pos + q]]; pos += q
    print(' '.join(str(x) for x in solve(n, words, q, queries)))


main()
