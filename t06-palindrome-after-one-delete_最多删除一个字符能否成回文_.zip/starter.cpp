#include <bits/stdc++.h>
using namespace std;

bool solve(string s) {
    // TODO: 判断能否通过最多删除一个字符把 s 变成回文串
return false;
}
