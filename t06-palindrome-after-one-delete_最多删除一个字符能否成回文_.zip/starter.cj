package t06_palindrome_after_one_delete

func solve(s: String): Bool {
    // TODO: 判断能否通过最多删除一个字符把 s 变成回文串
return false
}
