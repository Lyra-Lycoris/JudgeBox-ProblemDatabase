import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回出现次数最多的数出现了多少次
    return 0
