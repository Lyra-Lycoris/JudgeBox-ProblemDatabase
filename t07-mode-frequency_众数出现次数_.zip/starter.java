    static long solve(long n, long[] a) {
        // TODO: 返回出现次数最多的数出现了多少次
        return 0;
    }
