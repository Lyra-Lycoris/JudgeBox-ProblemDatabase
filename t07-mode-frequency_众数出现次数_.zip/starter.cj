package t07_mode_frequency

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回出现次数最多的数出现了多少次
return 0
}
