    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 按顺序返回每次区间和询问的答案
        return new long[0];
    }
