package t11_point_add_range_sum

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次区间和询问的答案
return Array<Int64>()
}
