import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    q = int(data[pos]); pos += 1
    ops = [[int(x) for x in data[pos + r * 3: pos + (r + 1) * 3]] for r in range(q)]
    pos += q * 3
    print(' '.join(str(x) for x in solve(n, a, q, ops)))


main()
