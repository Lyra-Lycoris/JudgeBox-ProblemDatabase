package t11_range_add_point_get

import std.convert.Parsable
import std.collection.*

var __tokens = ArrayList<String>()
var __cursor = 0

func __nextToken(): String {
    while (__cursor >= __tokens.size) {
        __tokens = ArrayList<String>()
        let parts = readln().trimAscii().split(" ")
        for (part in parts) {
            if (!part.isEmpty()) {
                __tokens.add(part)
            }
        }
        __cursor = 0
    }
    let value = __tokens[__cursor]
    __cursor += 1
    return value
}

func __nextInt(): Int64 {
    return Int64.parse(__nextToken())
}

func __nextInts(count: Int64): Array<Int64> {
    let values = Array<Int64>(count, repeat: 0)
    for (i in 0..count) {
        values[i] = __nextInt()
    }
    return values
}

func __nextStrings(count: Int64): Array<String> {
    let values = Array<String>(count, repeat: "")
    for (i in 0..count) {
        values[i] = __nextToken()
    }
    return values
}

main(): Unit {
    let n = __nextInt()
    let a = __nextInts(n)
    let q = __nextInt()
    let ops = Array<Array<Int64>>(q, { _ => __nextInts(4) })
    let __answer = solve(n, a, q, ops)
    for (i in 0..__answer.size) {
        if (i > 0) { print(" ") }
        print(__answer[i].toString())
    }
    println("")
}
