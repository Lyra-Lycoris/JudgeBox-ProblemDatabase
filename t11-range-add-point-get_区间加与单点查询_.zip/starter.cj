package t11_range_add_point_get

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次单点查询的答案
return Array<Int64>()
}
