    static long solve(long n, long[][] w) {
        // TODO: 返回从 0 号城市出发、到 n-1 号城市结束、恰好经过每个城市一次的最小总费用
        return 0;
    }
