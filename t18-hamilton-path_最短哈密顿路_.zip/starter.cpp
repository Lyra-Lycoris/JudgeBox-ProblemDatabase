#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<vector<long long>>& w) {
    // TODO: 返回从 0 号城市出发、到 n-1 号城市结束、恰好经过每个城市一次的最小总费用
return 0;
}
