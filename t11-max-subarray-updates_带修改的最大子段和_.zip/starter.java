    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 按顺序返回每次询问区间的最大子段和
        return new long[0];
    }
