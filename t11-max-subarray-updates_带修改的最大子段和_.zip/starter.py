import sys


def solve(n: int, a: list[int], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次询问区间的最大子段和
    return []
