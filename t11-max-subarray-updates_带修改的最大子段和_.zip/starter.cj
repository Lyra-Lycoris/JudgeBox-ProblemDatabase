package t11_max_subarray_updates

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次询问区间的最大子段和
return Array<Int64>()
}
