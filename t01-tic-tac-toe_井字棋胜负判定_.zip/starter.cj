package t01_tic_tac_toe

func solve(moves: Array<Int64>): Int64 {
    // TODO: 返回第一次连成三子的步数（1..9），平局返回 0
return 0
}
