import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    moves = [int(x) for x in data[pos:pos + 9]]; pos += 9
    print(solve(moves))


main()
