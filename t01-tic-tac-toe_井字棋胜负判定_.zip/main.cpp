#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& moves);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    vector<long long> moves(9); for (auto& x : moves) cin >> x;
    long long answer = solve(moves);
    cout << answer << '\n';
    return 0;
}
