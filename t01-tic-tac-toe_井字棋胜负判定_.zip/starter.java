    static long solve(long[] moves) {
        // TODO: 返回第一次连成三子的步数（1..9），平局返回 0
        return 0;
    }
