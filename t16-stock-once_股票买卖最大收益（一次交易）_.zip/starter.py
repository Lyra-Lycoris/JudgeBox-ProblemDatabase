import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回最多进行一次买卖能获得的最大收益（不能获利时返回 0）
    return 0
