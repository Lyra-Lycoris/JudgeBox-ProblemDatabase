package t16_stock_once

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回最多进行一次买卖能获得的最大收益（不能获利时返回 0）
return 0
}
