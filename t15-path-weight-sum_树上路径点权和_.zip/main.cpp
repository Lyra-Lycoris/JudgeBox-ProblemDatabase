#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& w, const vector<long long>& e, long long q, const vector<long long>& queries);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> w(n); for (auto& x : w) cin >> x;
    vector<long long> e(2*(n-1)); for (auto& x : e) cin >> x;
    long long q; cin >> q;
    vector<long long> queries(2*q); for (auto& x : queries) cin >> x;
    vector<long long> answer = solve(n, w, e, q, queries);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
