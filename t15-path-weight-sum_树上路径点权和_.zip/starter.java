    static long[] solve(long n, long[] w, long[] e, long q, long[] queries) {
        // TODO: 返回 q 个整数：每次询问路径上所有节点的点权之和（含两端点）
        return new long[0];
    }
