package t15_path_weight_sum

func solve(n: Int64, w: Array<Int64>, e: Array<Int64>, q: Int64, queries: Array<Int64>): Array<Int64> {
    // TODO: 返回 q 个整数：每次询问路径上所有节点的点权之和（含两端点）
return Array<Int64>()
}
