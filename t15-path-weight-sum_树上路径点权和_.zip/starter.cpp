#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& w, const vector<long long>& e, long long q, const vector<long long>& queries) {
    // TODO: 返回 q 个整数：每次询问路径上所有节点的点权之和（含两端点）
return {};
}
