import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    w = [int(x) for x in data[pos:pos + n]]; pos += n
    e = [int(x) for x in data[pos:pos + 2*(n-1)]]; pos += 2*(n-1)
    q = int(data[pos]); pos += 1
    queries = [int(x) for x in data[pos:pos + 2*q]]; pos += 2*q
    print(' '.join(str(x) for x in solve(n, w, e, q, queries)))


main()
