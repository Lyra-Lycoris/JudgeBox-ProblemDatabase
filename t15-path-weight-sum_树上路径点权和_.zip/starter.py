import sys


def solve(n: int, w: list[int], e: list[int], q: int, queries: list[int]) -> list[int]:
    # TODO: 返回 q 个整数：每次询问路径上所有节点的点权之和（含两端点）
    return []
