    static long solve(long n, long cap, long[] g, long[] w, long[] v) {
        // TODO: 返回容量 cap 下每组至多选一件物品时的最大价值
        return 0;
    }
