#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long cap, const vector<long long>& g, const vector<long long>& w, const vector<long long>& v) {
    // TODO: 返回容量 cap 下每组至多选一件物品时的最大价值
return 0;
}
