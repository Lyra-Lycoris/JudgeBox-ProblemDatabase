package t17_group_knapsack

func solve(n: Int64, cap: Int64, g: Array<Int64>, w: Array<Int64>, v: Array<Int64>): Int64 {
    // TODO: 返回容量 cap 下每组至多选一件物品时的最大价值
return 0
}
