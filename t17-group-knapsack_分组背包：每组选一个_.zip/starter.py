import sys


def solve(n: int, cap: int, g: list[int], w: list[int], v: list[int]) -> int:
    # TODO: 返回容量 cap 下每组至多选一件物品时的最大价值
    return 0
