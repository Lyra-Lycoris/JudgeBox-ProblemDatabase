import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    cap = int(data[pos]); pos += 1
    g = [int(x) for x in data[pos:pos + n]]; pos += n
    w = [int(x) for x in data[pos:pos + n]]; pos += n
    v = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, cap, g, w, v))


main()
