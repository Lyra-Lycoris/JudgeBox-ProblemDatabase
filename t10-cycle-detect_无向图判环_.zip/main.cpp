#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, const vector<vector<long long>>& e);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<vector<long long>> e(m, vector<long long>(2)); for (auto& row : e) for (auto& x : row) cin >> x;
    bool answer = solve(n, m, e);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
