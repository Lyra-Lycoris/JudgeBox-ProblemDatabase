import sys


def solve(n: int, m: int, e: list[list[int]]) -> bool:
    # TODO: 返回这张无向图是否存在环
    return False
