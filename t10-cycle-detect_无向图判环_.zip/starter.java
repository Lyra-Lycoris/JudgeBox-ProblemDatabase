    static boolean solve(long n, long m, long[][] e) {
        // TODO: 返回这张无向图是否存在环
        return false;
    }
