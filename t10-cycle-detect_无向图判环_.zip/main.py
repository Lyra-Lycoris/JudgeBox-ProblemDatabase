import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    e = [[int(x) for x in data[pos + r * 2: pos + (r + 1) * 2]] for r in range(m)]
    pos += m * 2
    print('YES' if solve(n, m, e) else 'NO')


main()
