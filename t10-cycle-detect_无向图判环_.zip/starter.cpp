#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回这张无向图是否存在环
return false;
}
