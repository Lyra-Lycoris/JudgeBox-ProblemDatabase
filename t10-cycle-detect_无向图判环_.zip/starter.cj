package t10_cycle_detect

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Bool {
    // TODO: 返回这张无向图是否存在环
return false
}
