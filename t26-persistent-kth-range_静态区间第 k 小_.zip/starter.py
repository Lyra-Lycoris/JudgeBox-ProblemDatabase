import sys


def solve(n: int, a: list[int], m: int, queries: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次询问区间 [l, r] 内第 k 小的数
    return []
