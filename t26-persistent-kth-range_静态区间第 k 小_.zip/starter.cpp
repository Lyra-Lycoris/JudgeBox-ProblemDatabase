#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long m, const vector<vector<long long>>& queries) {
    // TODO: 按顺序返回每次询问区间 [l, r] 内第 k 小的数
return {};
}
