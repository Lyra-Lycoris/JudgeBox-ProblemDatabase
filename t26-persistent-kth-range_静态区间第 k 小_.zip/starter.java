    static long[] solve(long n, long[] a, long m, long[][] queries) {
        // TODO: 按顺序返回每次询问区间 [l, r] 内第 k 小的数
        return new long[0];
    }
