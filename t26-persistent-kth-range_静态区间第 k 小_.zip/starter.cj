package t26_persistent_kth_range

func solve(n: Int64, a: Array<Int64>, m: Int64, queries: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次询问区间 [l, r] 内第 k 小的数
return Array<Int64>()
}
