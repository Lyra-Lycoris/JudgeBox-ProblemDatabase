import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    m = int(data[pos]); pos += 1
    queries = [[int(x) for x in data[pos + r * 3: pos + (r + 1) * 3]] for r in range(m)]
    pos += m * 3
    print(' '.join(str(x) for x in solve(n, a, m, queries)))


main()
