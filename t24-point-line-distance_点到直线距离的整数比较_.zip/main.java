    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        int T = Integer.parseInt(st.nextToken());
        for (int __case = 0; __case < T; ++__case) {
            long x1 = Long.parseLong(st.nextToken());
            long y1 = Long.parseLong(st.nextToken());
            long x2 = Long.parseLong(st.nextToken());
            long y2 = Long.parseLong(st.nextToken());
            long px = Long.parseLong(st.nextToken());
            long py = Long.parseLong(st.nextToken());
            long d = Long.parseLong(st.nextToken());
            System.out.println(solve(x1, y1, x2, y2, px, py, d) ? "YES" : "NO");
        }
    }
