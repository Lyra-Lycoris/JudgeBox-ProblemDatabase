    static boolean solve(long x1, long y1, long x2, long y2, long px, long py, long d) {
        // TODO: 返回点 (px,py) 到直线 (x1,y1)-(x2,y2) 的距离是否不超过 d
        return false;
    }
