import sys


def solve(x1: int, y1: int, x2: int, y2: int, px: int, py: int, d: int) -> bool:
    # TODO: 返回点 (px,py) 到直线 (x1,y1)-(x2,y2) 的距离是否不超过 d
    return False
