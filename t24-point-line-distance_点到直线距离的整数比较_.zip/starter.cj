package t24_point_line_distance

func solve(x1: Int64, y1: Int64, x2: Int64, y2: Int64, px: Int64, py: Int64, d: Int64): Bool {
    // TODO: 返回点 (px,py) 到直线 (x1,y1)-(x2,y2) 的距离是否不超过 d
return false
}
