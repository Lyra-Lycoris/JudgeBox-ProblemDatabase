#include <bits/stdc++.h>
using namespace std;

bool solve(long long x1, long long y1, long long x2, long long y2, long long px, long long py, long long d) {
    // TODO: 返回点 (px,py) 到直线 (x1,y1)-(x2,y2) 的距离是否不超过 d
return false;
}
