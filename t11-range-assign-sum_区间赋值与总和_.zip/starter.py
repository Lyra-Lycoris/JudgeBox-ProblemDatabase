import sys


def solve(n: int, a: list[int], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 依次返回每次赋值操作之后整个序列的总和
    return []
