package t11_range_assign_sum

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 依次返回每次赋值操作之后整个序列的总和
return Array<Int64>()
}
