#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& ops) {
    // TODO: 依次返回每次赋值操作之后整个序列的总和
return {};
}
