    static long[] solve(long n, long[] a, long q, long[][] ops) {
        // TODO: 依次返回每次赋值操作之后整个序列的总和
        return new long[0];
    }
