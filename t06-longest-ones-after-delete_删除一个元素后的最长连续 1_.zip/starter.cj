package t06_longest_ones_after_delete

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回恰好删除一个元素后，剩余数组中最长连续 1 的长度
return 0
}
