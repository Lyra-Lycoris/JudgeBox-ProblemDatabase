    static long solve(long n, long[] a) {
        // TODO: 返回恰好删除一个元素后，剩余数组中最长连续 1 的长度
        return 0;
    }
