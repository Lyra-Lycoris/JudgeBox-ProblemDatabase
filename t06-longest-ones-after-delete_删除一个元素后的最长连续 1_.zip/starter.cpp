#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回恰好删除一个元素后，剩余数组中最长连续 1 的长度
return 0;
}
