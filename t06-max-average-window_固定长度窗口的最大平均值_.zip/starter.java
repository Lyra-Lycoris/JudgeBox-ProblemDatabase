    static String solve(long n, long k, long[] a) {
        // TODO: 返回最大平均值的最简分数形式 p/q（q 为正，形如 7/2）
        return "";
    }
