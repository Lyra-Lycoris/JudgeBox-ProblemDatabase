package t06_max_average_window

func solve(n: Int64, k: Int64, a: Array<Int64>): String {
    // TODO: 返回最大平均值的最简分数形式 p/q（q 为正，形如 7/2）
return ""
}
