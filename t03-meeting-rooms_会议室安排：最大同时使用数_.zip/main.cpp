#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& s, const vector<long long>& e);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> s(n); for (auto& x : s) cin >> x;
    vector<long long> e(n); for (auto& x : e) cin >> x;
    long long answer = solve(n, s, e);
    cout << answer << '\n';
    return 0;
}
