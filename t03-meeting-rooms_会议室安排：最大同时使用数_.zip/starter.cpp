#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& s, const vector<long long>& e) {
    // TODO: 返回同一时刻最多有几场会议同时进行
return 0;
}
