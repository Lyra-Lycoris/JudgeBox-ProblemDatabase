    static long solve(long n, long[] s, long[] e) {
        // TODO: 返回同一时刻最多有几场会议同时进行
        return 0;
    }
