import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    s = [int(x) for x in data[pos:pos + n]]; pos += n
    e = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, s, e))


main()
