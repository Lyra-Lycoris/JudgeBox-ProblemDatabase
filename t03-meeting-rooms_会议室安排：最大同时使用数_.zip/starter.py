import sys


def solve(n: int, s: list[int], e: list[int]) -> int:
    # TODO: 返回同一时刻最多有几场会议同时进行
    return 0
