package t22_max_gap_between_ones

func solve(n: Int64): Int64 {
    // TODO: 返回 n 的二进制表示中相邻两个 1 之间夹着的 0 的个数的最大值
return 0
}
