#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 n 的二进制表示中相邻两个 1 之间夹着的 0 的个数的最大值
return 0;
}
