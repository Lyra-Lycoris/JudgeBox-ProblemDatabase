import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    for _ in range(t):
        n = int(data[pos]); pos += 1
        print(solve(n))


main()
