package t03_gas_station

func solve(n: Int64, gas: Array<Int64>, cost: Array<Int64>): Int64 {
    // TODO: 返回可以绕行一圈的起点下标（从 0 开始），无解返回 -1
return 0
}
