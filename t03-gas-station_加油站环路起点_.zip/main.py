import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    gas = [int(x) for x in data[pos:pos + n]]; pos += n
    cost = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, gas, cost))


main()
