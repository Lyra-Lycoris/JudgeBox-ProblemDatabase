#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& gas, const vector<long long>& cost) {
    // TODO: 返回可以绕行一圈的起点下标（从 0 开始），无解返回 -1
return 0;
}
