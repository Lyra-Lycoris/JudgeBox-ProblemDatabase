#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& gas, const vector<long long>& cost);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> gas(n); for (auto& x : gas) cin >> x;
    vector<long long> cost(n); for (auto& x : cost) cin >> x;
    long long answer = solve(n, gas, cost);
    cout << answer << '\n';
    return 0;
}
