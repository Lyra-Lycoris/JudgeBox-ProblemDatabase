package t10_island_count

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>): Int64 {
    // TODO: 返回四连通意义下 1 组成的连通块数量
return 0
}
