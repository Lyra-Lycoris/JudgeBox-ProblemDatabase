    static long solve(long n, long m, long[][] g) {
        // TODO: 返回四连通意义下 1 组成的连通块数量
        return 0;
    }
