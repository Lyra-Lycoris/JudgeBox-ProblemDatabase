#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& g) {
    // TODO: 返回四连通意义下 1 组成的连通块数量
return 0;
}
