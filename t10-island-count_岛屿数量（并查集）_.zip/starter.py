import sys


def solve(n: int, m: int, g: list[list[int]]) -> int:
    # TODO: 返回四连通意义下 1 组成的连通块数量
    return 0
