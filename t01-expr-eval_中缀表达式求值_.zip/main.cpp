#include <bits/stdc++.h>
using namespace std;

long long solve(string expr);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string expr; cin >> expr;
    long long answer = solve(expr);
    cout << answer << '\n';
    return 0;
}
