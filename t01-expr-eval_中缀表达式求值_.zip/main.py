import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    expr = data[pos].decode(); pos += 1
    print(solve(expr))


main()
