import sys


def solve(expr: str) -> int:
    # TODO: 返回表达式求值结果（除法向零取整）
    return 0
