    static long solve(String expr) {
        // TODO: 返回表达式求值结果（除法向零取整）
        return 0;
    }
