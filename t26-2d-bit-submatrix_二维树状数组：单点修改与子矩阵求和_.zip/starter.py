import sys


def solve(n: int, m: int, a: list[list[int]], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次子矩阵求和询问的答案
    return []
