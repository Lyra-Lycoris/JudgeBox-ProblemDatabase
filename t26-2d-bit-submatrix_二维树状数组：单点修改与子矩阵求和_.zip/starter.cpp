#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<vector<long long>>& a, long long q, const vector<vector<long long>>& ops) {
    // TODO: 按顺序返回每次子矩阵求和询问的答案
return {};
}
