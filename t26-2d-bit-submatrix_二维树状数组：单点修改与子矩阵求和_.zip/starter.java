    static long[] solve(long n, long m, long[][] a, long q, long[][] ops) {
        // TODO: 按顺序返回每次子矩阵求和询问的答案
        return new long[0];
    }
