package t26_2d_bit_submatrix

func solve(n: Int64, m: Int64, a: Array<Array<Int64>>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次子矩阵求和询问的答案
return Array<Int64>()
}
