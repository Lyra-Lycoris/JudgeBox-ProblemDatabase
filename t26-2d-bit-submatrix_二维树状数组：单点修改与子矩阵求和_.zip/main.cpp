#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<vector<long long>>& a, long long q, const vector<vector<long long>>& ops);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<vector<long long>> a(n, vector<long long>(m)); for (auto& row : a) for (auto& x : row) cin >> x;
    long long q; cin >> q;
    vector<vector<long long>> ops(q, vector<long long>(5)); for (auto& row : ops) for (auto& x : row) cin >> x;
    vector<long long> answer = solve(n, m, a, q, ops);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
