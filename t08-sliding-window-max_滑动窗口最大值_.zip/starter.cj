package t08_sliding_window_max

func solve(n: Int64, k: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回每个长度为 k 的窗口中的最大值，共 n-k+1 个
return Array<Int64>()
}
