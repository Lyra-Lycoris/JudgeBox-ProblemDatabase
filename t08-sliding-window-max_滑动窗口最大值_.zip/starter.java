    static long[] solve(long n, long k, long[] a) {
        // TODO: 返回每个长度为 k 的窗口中的最大值，共 n-k+1 个
        return new long[0];
    }
