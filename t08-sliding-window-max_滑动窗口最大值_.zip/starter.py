import sys


def solve(n: int, k: int, a: list[int]) -> list[int]:
    # TODO: 返回每个长度为 k 的窗口中的最大值，共 n-k+1 个
    return []
