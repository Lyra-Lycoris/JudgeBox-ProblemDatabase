#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回每个长度为 k 的窗口中的最大值，共 n-k+1 个
return {};
}
