#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(const vector<long long>& spells, const vector<long long>& potions, long long success) {
    // TODO: 对每个 spell 统计乘积 >= success 的药水数量
    (void)potions;
    (void)success;
    return vector<long long>(spells.size(), 0);
}
