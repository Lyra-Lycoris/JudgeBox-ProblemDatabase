import sys


def solve(spells: list[int], potions: list[int], success: int) -> list[int]:
    # TODO: 对每个 spell 统计乘积 >= success 的药水数量
    return [0] * len(spells)
