    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int n = Integer.parseInt(st.nextToken());
        int m = Integer.parseInt(st.nextToken());
        long success = Long.parseLong(st.nextToken());
        long[] spells = new long[n];
        st = new StringTokenizer(br.readLine());
        for (int i = 0; i < n; ++i) spells[i] = Long.parseLong(st.nextToken());
        long[] potions = new long[m];
        st = new StringTokenizer(br.readLine());
        for (int i = 0; i < m; ++i) potions[i] = Long.parseLong(st.nextToken());
        long[] answer = solve(spells, potions, success);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; ++i) {
            if (i > 0) sb.append(' ');
            sb.append(answer[i]);
        }
        sb.append('\n');
        System.out.print(sb);
    }
