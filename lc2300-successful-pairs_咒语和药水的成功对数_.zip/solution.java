    static long[] solve(long[] spells, long[] potions, long success) {
        int m = potions.length;
        long[] ordered = potions.clone();
        Arrays.sort(ordered);
        long[] answer = new long[spells.length];
        for (int i = 0; i < spells.length; ++i) {
            long need = (success + spells[i] - 1) / spells[i];
            int lo = 0, hi = m;
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (ordered[mid] >= need) hi = mid;
                else lo = mid + 1;
            }
            answer[i] = m - lo;
        }
        return answer;
    }
