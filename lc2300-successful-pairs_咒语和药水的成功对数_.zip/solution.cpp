#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(const vector<long long>& spells, const vector<long long>& potions, long long success) {
    vector<long long> ordered = potions;
    sort(ordered.begin(), ordered.end());
    int m = (int)ordered.size();
    vector<long long> answer(spells.size());
    for (size_t i = 0; i < spells.size(); ++i) {
        long long need = (success + spells[i] - 1) / spells[i];
        answer[i] = m - (long long)(lower_bound(ordered.begin(), ordered.end(), need) - ordered.begin());
    }
    return answer;
}
