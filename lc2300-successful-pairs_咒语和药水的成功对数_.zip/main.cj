package lc2300

import std.convert.Parsable
import std.collection.ArrayList

main(): Unit {
    let header = ArrayList<String>()
    for (part in readln().trimAscii().split(" ")) {
        if (!part.isEmpty()) {
            header.add(part)
        }
    }
    let n = Int64.parse(header[0])
    let m = Int64.parse(header[1])
    let success = Int64.parse(header[2])
    let spells = Array<Int64>(n, repeat: 0)
    var index = 0
    for (part in readln().trimAscii().split(" ")) {
        if (!part.isEmpty()) {
            spells[index] = Int64.parse(part)
            index += 1
        }
    }
    let potions = Array<Int64>(m, repeat: 0)
    index = 0
    for (part in readln().trimAscii().split(" ")) {
        if (!part.isEmpty()) {
            potions[index] = Int64.parse(part)
            index += 1
        }
    }
    let answer = solve(spells, potions, success)
    let builder = StringBuilder()
    for (i in 0..answer.size) {
        if (i > 0) {
            builder.append(" ")
        }
        builder.append(answer[i].toString())
    }
    println(builder.toString())
}
