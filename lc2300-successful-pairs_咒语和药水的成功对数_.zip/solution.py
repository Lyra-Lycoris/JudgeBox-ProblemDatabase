import bisect


def solve(spells: list[int], potions: list[int], success: int) -> list[int]:
    ordered = sorted(potions)
    m = len(ordered)
    return [m - bisect.bisect_left(ordered, (success + s - 1) // s) for s in spells]
