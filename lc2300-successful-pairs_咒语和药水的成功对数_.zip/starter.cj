package lc2300

func solve(spells: Array<Int64>, potions: Array<Int64>, success: Int64): Array<Int64> {
    // TODO: 对每个 spell 统计乘积 >= success 的药水数量
    return Array<Int64>(spells.size, repeat: 0)
}
