    static long[] solve(long[] spells, long[] potions, long success) {
        // TODO: 对每个 spell 统计乘积 >= success 的药水数量
        return new long[spells.length];
    }
