package lc2300

import std.sort.*

func solve(spells: Array<Int64>, potions: Array<Int64>, success: Int64): Array<Int64> {
    let ordered = potions.clone()
    sort(ordered)
    let m = ordered.size
    let answer = Array<Int64>(spells.size, repeat: 0)
    for (i in 0..spells.size) {
        let need = (success + spells[i] - 1) / spells[i]
        var lo = 0
        var hi = m
        while (lo < hi) {
            let mid = (lo + hi) / 2
            if (ordered[mid] >= need) {
                hi = mid
            } else {
                lo = mid + 1
            }
        }
        answer[i] = m - lo
    }
    return answer
}
