#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(const vector<long long>& spells, const vector<long long>& potions, long long success);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    long long success;
    if (!(cin >> n >> m >> success)) return 0;
    vector<long long> spells(n), potions(m);
    for (auto& x : spells) cin >> x;
    for (auto& x : potions) cin >> x;

    vector<long long> answer = solve(spells, potions, success);
    for (int i = 0; i < n; ++i) {
        if (i) cout << ' ';
        cout << answer[i];
    }
    cout << '\n';
    return 0;
}
