import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    m = int(data[1])
    success = int(data[2])
    spells = [int(x) for x in data[3:3 + n]]
    potions = [int(x) for x in data[3 + n:3 + n + m]]
    counts = solve(spells, potions, success)
    sys.stdout.write(" ".join(map(str, counts)) + "\n")


main()
