package t28_01_matrix_rows_cols

func solve(n: Int64, m: Int64, r: Array<Int64>, c: Array<Int64>): Array<Int64> {
    // TODO: 返回按行优先展开的 n*m 个 0/1 整数；本题使用特殊评判，任意合法矩阵均可
return Array<Int64>()
}
