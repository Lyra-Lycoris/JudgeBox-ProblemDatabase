#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<long long>& r, const vector<long long>& c) {
    // TODO: 返回按行优先展开的 n*m 个 0/1 整数；本题使用特殊评判，任意合法矩阵均可
return {};
}
