    static long[] solve(long n, long m, long[] r, long[] c) {
        // TODO: 返回按行优先展开的 n*m 个 0/1 整数；本题使用特殊评判，任意合法矩阵均可
        return new long[0];
    }
