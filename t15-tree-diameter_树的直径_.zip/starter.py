import sys


def solve(n: int, e: list[int]) -> int:
    # TODO: 返回树的直径，即最远点对之间经过的边数
    return 0
