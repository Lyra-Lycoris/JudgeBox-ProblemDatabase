#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& e) {
    // TODO: 返回树的直径，即最远点对之间经过的边数
return 0;
}
