package t15_tree_diameter

func solve(n: Int64, e: Array<Int64>): Int64 {
    // TODO: 返回树的直径，即最远点对之间经过的边数
return 0
}
