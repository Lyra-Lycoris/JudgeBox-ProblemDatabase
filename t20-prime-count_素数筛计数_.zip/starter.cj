package t20_prime_count

func solve(n: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回每个查询的答案：不超过 a[i] 的素数个数
return Array<Int64>()
}
