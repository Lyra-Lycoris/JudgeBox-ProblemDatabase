#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a) {
    // TODO: 返回每个查询的答案：不超过 a[i] 的素数个数
return {};
}
