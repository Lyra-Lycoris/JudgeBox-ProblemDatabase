import sys


def solve(n: int, a: list[int]) -> list[int]:
    # TODO: 返回每个查询的答案：不超过 a[i] 的素数个数
    return []
