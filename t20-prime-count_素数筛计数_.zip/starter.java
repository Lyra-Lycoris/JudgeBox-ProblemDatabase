    static long[] solve(long n, long[] a) {
        // TODO: 返回每个查询的答案：不超过 a[i] 的素数个数
        return new long[0];
    }
