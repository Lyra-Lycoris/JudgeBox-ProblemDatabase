#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& queries) {
    // TODO: 按顺序返回每次询问的区间最大值
return {};
}
