    static long[] solve(long n, long[] a, long q, long[][] queries) {
        // TODO: 按顺序返回每次询问的区间最大值
        return new long[0];
    }
