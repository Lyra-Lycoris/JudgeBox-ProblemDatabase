package t11_range_max_query

func solve(n: Int64, a: Array<Int64>, q: Int64, queries: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次询问的区间最大值
return Array<Int64>()
}
