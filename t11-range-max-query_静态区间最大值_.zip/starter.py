import sys


def solve(n: int, a: list[int], q: int, queries: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次询问的区间最大值
    return []
