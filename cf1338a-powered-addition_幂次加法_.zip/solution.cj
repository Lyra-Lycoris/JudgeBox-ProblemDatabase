package cf1338a

func solve(n: Int64, a: Array<Int64>): Int64 {
    var mx = -1
    var need = 0
    for (x in a) {
        if (x >= mx) {
            mx = x
        } else if (mx - x > need) {
            need = mx - x
        }
    }
    var answer = 0
    var span = 0
    while (span < need) {
        answer += 1
        span = span * 2 + 1
    }
    return answer
}
