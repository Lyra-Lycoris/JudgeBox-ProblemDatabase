#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a) {
    long long mx = -1;
    long long need = 0;
    for (int i = 0; i < n; ++i) {
        long long x = a[i];
        if (x >= mx) {
            mx = x;
        } else {
            need = max(need, mx - x);
        }
    }
    long long answer = 0;
    long long span = 0;  // 2^answer - 1
    while (span < need) {
        ++answer;
        span = span * 2 + 1;
    }
    return answer;
}
