package cf1338a

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 计算使数组非递减所需的最少秒数
    return 0
}
