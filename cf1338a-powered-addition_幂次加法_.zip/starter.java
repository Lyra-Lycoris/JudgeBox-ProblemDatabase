    static long solve(int n, long[] a) {
        // TODO: 计算使数组非递减所需的最少秒数
        return 0;
    }
