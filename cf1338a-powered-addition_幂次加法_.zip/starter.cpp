#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a) {
    // TODO: 计算使数组非递减所需的最少秒数
    (void)n;
    (void)a;
    return 0;
}
