def solve(n: int, a: list[int]) -> int:
    mx = -1
    need = 0
    for x in a:
        if x >= mx:
            mx = x
        else:
            diff = mx - x
            if diff > need:
                need = diff
    answer = 0
    span = 0
    while span < need:
        answer += 1
        span = span * 2 + 1
    return answer
