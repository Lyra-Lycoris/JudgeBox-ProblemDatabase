    static long solve(int n, long[] a) {
        long mx = -1;
        long need = 0;
        for (int i = 0; i < n; ++i) {
            long x = a[i];
            if (x >= mx) {
                mx = x;
            } else {
                long diff = mx - x;
                if (diff > need) need = diff;
            }
        }
        long answer = 0;
        long span = 0;
        while (span < need) {
            ++answer;
            span = span * 2 + 1;
        }
        return answer;
    }
