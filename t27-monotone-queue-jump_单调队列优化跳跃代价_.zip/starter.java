    static long solve(long n, long k, long[] a) {
        // TODO: 返回从第 1 块石头跳到第 n 块石头的最小总代价
        return 0;
    }
