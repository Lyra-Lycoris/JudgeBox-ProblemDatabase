import sys


def solve(n: int, k: int, a: list[int]) -> int:
    # TODO: 返回从第 1 块石头跳到第 n 块石头的最小总代价
    return 0
