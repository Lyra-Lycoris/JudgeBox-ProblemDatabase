package t27_monotone_queue_jump

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回从第 1 块石头跳到第 n 块石头的最小总代价
return 0
}
