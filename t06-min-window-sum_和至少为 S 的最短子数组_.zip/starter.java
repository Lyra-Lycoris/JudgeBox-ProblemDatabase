    static long solve(long n, long s, long[] a) {
        // TODO: 返回和不少于 s 的连续子数组的最小长度，不存在时返回 0
        return 0;
    }
