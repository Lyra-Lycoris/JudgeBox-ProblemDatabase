package t06_min_window_sum

func solve(n: Int64, s: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回和不少于 s 的连续子数组的最小长度，不存在时返回 0
return 0
}
