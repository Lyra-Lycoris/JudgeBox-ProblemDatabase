package t17_stone_merge

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把 n 堆石子合并成一堆的最小总代价
return 0
}
