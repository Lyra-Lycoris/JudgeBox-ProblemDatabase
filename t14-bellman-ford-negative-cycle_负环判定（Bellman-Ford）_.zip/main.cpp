#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, long long s, const vector<vector<long long>>& e);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    long long s; cin >> s;
    vector<vector<long long>> e(m, vector<long long>(3)); for (auto& row : e) for (auto& x : row) cin >> x;
    bool answer = solve(n, m, s, e);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
