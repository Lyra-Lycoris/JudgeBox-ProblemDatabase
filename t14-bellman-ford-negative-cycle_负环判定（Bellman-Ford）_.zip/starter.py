import sys


def solve(n: int, m: int, s: int, e: list[list[int]]) -> bool:
    # TODO: 存在从 s 可达的负环返回 true，否则返回 false
    return False
