package t14_bellman_ford_negative_cycle

func solve(n: Int64, m: Int64, s: Int64, e: Array<Array<Int64>>): Bool {
    // TODO: 存在从 s 可达的负环返回 true，否则返回 false
return false
}
