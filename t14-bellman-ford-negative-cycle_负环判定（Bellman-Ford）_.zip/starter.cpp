#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, long long s, const vector<vector<long long>>& e) {
    // TODO: 存在从 s 可达的负环返回 true，否则返回 false
return false;
}
