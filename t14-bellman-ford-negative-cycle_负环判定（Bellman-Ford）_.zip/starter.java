    static boolean solve(long n, long m, long s, long[][] e) {
        // TODO: 存在从 s 可达的负环返回 true，否则返回 false
        return false;
    }
