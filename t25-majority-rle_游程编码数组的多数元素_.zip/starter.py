import sys


def solve(k: int, v: list[int], c: list[int]) -> int:
    # TODO: 返回出现次数严格大于总长度一半的那个数（保证存在）
    return 0
