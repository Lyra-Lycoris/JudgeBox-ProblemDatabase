#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<long long>& v, const vector<long long>& c) {
    // TODO: 返回出现次数严格大于总长度一半的那个数（保证存在）
return 0;
}
