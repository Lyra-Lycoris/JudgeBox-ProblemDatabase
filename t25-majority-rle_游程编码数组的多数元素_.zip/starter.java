    static long solve(long k, long[] v, long[] c) {
        // TODO: 返回出现次数严格大于总长度一半的那个数（保证存在）
        return 0;
    }
