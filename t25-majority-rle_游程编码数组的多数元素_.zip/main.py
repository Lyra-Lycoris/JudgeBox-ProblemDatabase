import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    k = int(data[pos]); pos += 1
    v = [int(x) for x in data[pos:pos + k]]; pos += k
    c = [int(x) for x in data[pos:pos + k]]; pos += k
    print(solve(k, v, c))


main()
