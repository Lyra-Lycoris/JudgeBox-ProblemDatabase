package t25_majority_rle

func solve(k: Int64, v: Array<Int64>, c: Array<Int64>): Int64 {
    // TODO: 返回出现次数严格大于总长度一半的那个数（保证存在）
return 0
}
