#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<long long>& v, const vector<long long>& c);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long k; cin >> k;
    vector<long long> v(k); for (auto& x : v) cin >> x;
    vector<long long> c(k); for (auto& x : c) cin >> x;
    long long answer = solve(k, v, c);
    cout << answer << '\n';
    return 0;
}
