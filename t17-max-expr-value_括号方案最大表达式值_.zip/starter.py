import sys


def solve(m: int, nums: list[int], ops: list[str]) -> int:
    # TODO: 返回给表达式任意加括号后能得到的最大值
    return 0
