#include <bits/stdc++.h>
using namespace std;

long long solve(long long m, const vector<long long>& nums, const vector<string>& ops) {
    // TODO: 返回给表达式任意加括号后能得到的最大值
return 0;
}
