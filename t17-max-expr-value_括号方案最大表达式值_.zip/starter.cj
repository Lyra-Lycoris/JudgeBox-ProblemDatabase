package t17_max_expr_value

func solve(m: Int64, nums: Array<Int64>, ops: Array<String>): Int64 {
    // TODO: 返回给表达式任意加括号后能得到的最大值
return 0
}
