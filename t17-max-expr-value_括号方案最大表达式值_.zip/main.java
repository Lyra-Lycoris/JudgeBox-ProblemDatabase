    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long m = Long.parseLong(st.nextToken());
        long[] nums = new long[(int) (m)];
        for (int i = 0; i < nums.length; ++i) nums[i] = Long.parseLong(st.nextToken());
        String[] ops = new String[(int) (m - 1)];
        for (int i = 0; i < ops.length; ++i) ops[i] = st.nextToken();
        System.out.println(solve(m, nums, ops));
    }
