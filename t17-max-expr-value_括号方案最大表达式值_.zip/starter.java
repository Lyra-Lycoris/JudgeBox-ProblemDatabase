    static long solve(long m, long[] nums, String[] ops) {
        // TODO: 返回给表达式任意加括号后能得到的最大值
        return 0;
    }
