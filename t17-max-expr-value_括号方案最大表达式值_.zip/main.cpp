#include <bits/stdc++.h>
using namespace std;

long long solve(long long m, const vector<long long>& nums, const vector<string>& ops);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long m; cin >> m;
    vector<long long> nums(m); for (auto& x : nums) cin >> x;
    vector<string> ops(m - 1); for (auto& x : ops) cin >> x;
    long long answer = solve(m, nums, ops);
    cout << answer << '\n';
    return 0;
}
