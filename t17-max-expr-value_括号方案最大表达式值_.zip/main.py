import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    m = int(data[pos]); pos += 1
    nums = [int(x) for x in data[pos:pos + m]]; pos += m
    ops = [x.decode() for x in data[pos:pos + m - 1]]; pos += m - 1
    print(solve(m, nums, ops))


main()
