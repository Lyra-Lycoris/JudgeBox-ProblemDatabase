import sys


def solve(s: str) -> list[int]:
    # TODO: 返回机器人最终坐标 x y
    return []
