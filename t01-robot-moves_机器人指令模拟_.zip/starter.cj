package t01_robot_moves

func solve(s: String): Array<Int64> {
    // TODO: 返回机器人最终坐标 x y
return Array<Int64>()
}
