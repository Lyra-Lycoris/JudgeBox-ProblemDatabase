    static long[] solve(String s) {
        // TODO: 返回机器人最终坐标 x y
        return new long[0];
    }
