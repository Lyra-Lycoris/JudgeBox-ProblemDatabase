import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    s = data[pos].decode(); pos += 1
    print(' '.join(str(x) for x in solve(s)))


main()
