#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(string s) {
    // TODO: 返回机器人最终坐标 x y
return {};
}
