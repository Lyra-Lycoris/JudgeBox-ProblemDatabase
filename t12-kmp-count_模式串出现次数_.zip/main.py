import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    s = data[pos].decode(); pos += 1
    m = int(data[pos]); pos += 1
    p = data[pos].decode(); pos += 1
    print(solve(n, s, m, p))


main()
