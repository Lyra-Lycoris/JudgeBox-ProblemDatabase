#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string s, long long m, string p) {
    // TODO: 返回模式串 p 在文本串 s 中出现的次数，重叠的匹配分别计数
return 0;
}
