#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string s, long long m, string p);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    string s; cin >> s;
    long long m; cin >> m;
    string p; cin >> p;
    long long answer = solve(n, s, m, p);
    cout << answer << '\n';
    return 0;
}
