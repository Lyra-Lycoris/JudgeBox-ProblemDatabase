package t12_kmp_count

func solve(n: Int64, s: String, m: Int64, p: String): Int64 {
    // TODO: 返回模式串 p 在文本串 s 中出现的次数，重叠的匹配分别计数
return 0
}
