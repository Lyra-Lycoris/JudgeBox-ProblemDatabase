    static long solve(long n, String s, long m, String p) {
        // TODO: 返回模式串 p 在文本串 s 中出现的次数，重叠的匹配分别计数
        return 0;
    }
