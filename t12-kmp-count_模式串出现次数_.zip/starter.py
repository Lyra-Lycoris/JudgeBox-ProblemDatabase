import sys


def solve(n: int, s: str, m: int, p: str) -> int:
    # TODO: 返回模式串 p 在文本串 s 中出现的次数，重叠的匹配分别计数
    return 0
