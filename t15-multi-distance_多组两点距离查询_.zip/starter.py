import sys


def solve(n: int, e: list[int], q: int, queries: list[int]) -> list[int]:
    # TODO: 每组询问返回 q 个整数：该组内每次询问的两点距离
    return []
