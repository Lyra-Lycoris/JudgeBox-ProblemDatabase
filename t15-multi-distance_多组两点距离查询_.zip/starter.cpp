#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& e, long long q, const vector<long long>& queries) {
    // TODO: 每组询问返回 q 个整数：该组内每次询问的两点距离
return {};
}
