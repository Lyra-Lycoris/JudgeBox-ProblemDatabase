    static long[] solve(long n, long[] e, long q, long[] queries) {
        // TODO: 每组询问返回 q 个整数：该组内每次询问的两点距离
        return new long[0];
    }
