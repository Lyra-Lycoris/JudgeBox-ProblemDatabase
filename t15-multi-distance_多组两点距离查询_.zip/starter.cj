package t15_multi_distance

func solve(n: Int64, e: Array<Int64>, q: Int64, queries: Array<Int64>): Array<Int64> {
    // TODO: 每组询问返回 q 个整数：该组内每次询问的两点距离
return Array<Int64>()
}
