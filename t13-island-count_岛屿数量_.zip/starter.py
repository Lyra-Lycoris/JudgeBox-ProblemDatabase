import sys


def solve(n: int, m: int, grid: list[list[int]]) -> int:
    # TODO: 返回四连通（上下左右）的 1 连通块个数
    return 0
