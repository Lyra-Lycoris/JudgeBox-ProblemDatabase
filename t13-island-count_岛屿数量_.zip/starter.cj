package t13_island_count

func solve(n: Int64, m: Int64, grid: Array<Array<Int64>>): Int64 {
    // TODO: 返回四连通（上下左右）的 1 连通块个数
return 0
}
