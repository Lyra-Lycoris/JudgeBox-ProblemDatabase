#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& grid) {
    // TODO: 返回四连通（上下左右）的 1 连通块个数
return 0;
}
