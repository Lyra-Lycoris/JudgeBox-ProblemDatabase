    static long solve(long n, long m, long[][] grid) {
        // TODO: 返回四连通（上下左右）的 1 连通块个数
        return 0;
    }
