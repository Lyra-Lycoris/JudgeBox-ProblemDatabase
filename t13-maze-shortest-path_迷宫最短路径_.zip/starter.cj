package t13_maze_shortest_path

func solve(n: Int64, m: Int64, grid: Array<Array<Int64>>): Int64 {
    // TODO: 返回从左上角走到右下角的最少步数，无法到达返回 -1
return 0
}
