    static long solve(long n, long m, long[][] grid) {
        // TODO: 返回从左上角走到右下角的最少步数，无法到达返回 -1
        return 0;
    }
