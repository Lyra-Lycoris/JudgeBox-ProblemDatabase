import sys


def solve(n: int, m: int, grid: list[list[int]]) -> int:
    # TODO: 返回从左上角走到右下角的最少步数，无法到达返回 -1
    return 0
