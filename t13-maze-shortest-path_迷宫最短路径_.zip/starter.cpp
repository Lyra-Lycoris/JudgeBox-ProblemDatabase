#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& grid) {
    // TODO: 返回从左上角走到右下角的最少步数，无法到达返回 -1
return 0;
}
