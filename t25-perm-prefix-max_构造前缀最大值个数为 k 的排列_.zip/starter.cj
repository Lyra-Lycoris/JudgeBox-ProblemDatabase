package t25_perm_prefix_max

func solve(n: Int64, k: Int64): Array<Int64> {
    // TODO: 返回任意一个 1..n 的排列，使它的前缀最大值个数恰好为 k；本题使用特殊评判
return Array<Int64>()
}
