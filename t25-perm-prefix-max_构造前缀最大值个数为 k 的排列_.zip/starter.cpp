#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k) {
    // TODO: 返回任意一个 1..n 的排列，使它的前缀最大值个数恰好为 k；本题使用特殊评判
return {};
}
