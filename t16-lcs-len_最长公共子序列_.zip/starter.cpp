#include <bits/stdc++.h>
using namespace std;

long long solve(string s, string t) {
    // TODO: 返回两个字符串的最长公共子序列长度
return 0;
}
