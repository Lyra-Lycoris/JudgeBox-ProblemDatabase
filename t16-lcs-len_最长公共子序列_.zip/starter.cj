package t16_lcs_len

func solve(s: String, t: String): Int64 {
    // TODO: 返回两个字符串的最长公共子序列长度
return 0
}
