import sys


def solve(s: str, t: str) -> int:
    # TODO: 返回两个字符串的最长公共子序列长度
    return 0
