#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回出现次数前 k 多的元素，次数相同则数值小的在前
return {};
}
