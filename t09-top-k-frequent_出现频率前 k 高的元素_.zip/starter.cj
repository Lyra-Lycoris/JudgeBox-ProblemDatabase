package t09_top_k_frequent

func solve(n: Int64, k: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回出现次数前 k 多的元素，次数相同则数值小的在前
return Array<Int64>()
}
