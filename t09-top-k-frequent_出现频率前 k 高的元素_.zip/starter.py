import sys


def solve(n: int, k: int, a: list[int]) -> list[int]:
    # TODO: 返回出现次数前 k 多的元素，次数相同则数值小的在前
    return []
