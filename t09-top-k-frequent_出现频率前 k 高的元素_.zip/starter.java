    static long[] solve(long n, long k, long[] a) {
        // TODO: 返回出现次数前 k 多的元素，次数相同则数值小的在前
        return new long[0];
    }
