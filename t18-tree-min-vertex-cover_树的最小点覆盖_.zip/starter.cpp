#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& p) {
    // TODO: 返回树的最小点覆盖大小：最少的点数，使每条边至少有一个端点被选中
return 0;
}
