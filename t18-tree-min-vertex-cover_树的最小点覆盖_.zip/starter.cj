package t18_tree_min_vertex_cover

func solve(n: Int64, p: Array<Int64>): Int64 {
    // TODO: 返回树的最小点覆盖大小：最少的点数，使每条边至少有一个端点被选中
return 0
}
