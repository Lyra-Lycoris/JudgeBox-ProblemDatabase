#include <bits/stdc++.h>
using namespace std;

string solve(long long k, string s) {
    // TODO: 返回反复删除连续 k 个相同字符后剩下的字符串
return "";
}
