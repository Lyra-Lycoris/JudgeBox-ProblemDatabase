    static String solve(long k, String s) {
        // TODO: 返回反复删除连续 k 个相同字符后剩下的字符串
        return "";
    }
