#include <bits/stdc++.h>
using namespace std;

string solve(long long k, string s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long k; cin >> k;
    string s; cin >> s;
    string answer = solve(k, s);
    cout << answer << '\n';
    return 0;
}
