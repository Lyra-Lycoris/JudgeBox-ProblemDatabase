import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    k = int(data[pos]); pos += 1
    s = data[pos].decode(); pos += 1
    print(solve(k, s))


main()
