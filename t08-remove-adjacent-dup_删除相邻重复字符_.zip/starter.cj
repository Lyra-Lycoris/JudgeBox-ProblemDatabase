package t08_remove_adjacent_dup

func solve(k: Int64, s: String): String {
    // TODO: 返回反复删除连续 k 个相同字符后剩下的字符串
return ""
}
