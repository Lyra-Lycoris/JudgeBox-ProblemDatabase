import sys


def solve(k: int, s: str) -> str:
    # TODO: 返回反复删除连续 k 个相同字符后剩下的字符串
    return ""
