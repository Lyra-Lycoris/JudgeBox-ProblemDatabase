#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long k, const vector<vector<long long>>& cons);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<vector<long long>> cons(k, vector<long long>(3)); for (auto& row : cons) for (auto& x : row) cin >> x;
    bool answer = solve(n, k, cons);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
