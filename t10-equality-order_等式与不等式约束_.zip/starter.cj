package t10_equality_order

func solve(n: Int64, k: Int64, cons: Array<Array<Int64>>): Bool {
    // TODO: 返回是否存在同时满足所有等式与严格不等式的整数赋值
return false
}
