import sys


def solve(n: int, k: int, cons: list[list[int]]) -> bool:
    # TODO: 返回是否存在同时满足所有等式与严格不等式的整数赋值
    return False
