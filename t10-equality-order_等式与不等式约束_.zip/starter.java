    static boolean solve(long n, long k, long[][] cons) {
        // TODO: 返回是否存在同时满足所有等式与严格不等式的整数赋值
        return false;
    }
