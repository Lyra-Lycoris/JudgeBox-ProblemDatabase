import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    cons = [[int(x) for x in data[pos + r * 3: pos + (r + 1) * 3]] for r in range(k)]
    pos += k * 3
    print('YES' if solve(n, k, cons) else 'NO')


main()
