#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long k, const vector<vector<long long>>& cons) {
    // TODO: 返回是否存在同时满足所有等式与严格不等式的整数赋值
return false;
}
