    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long k = Long.parseLong(st.nextToken());
        long[][] cons = new long[(int) (k)][(int) (3)];
        for (int i = 0; i < cons.length; ++i) for (int j = 0; j < cons[i].length; ++j) cons[i][j] = Long.parseLong(st.nextToken());
        System.out.println(solve(n, k, cons) ? "YES" : "NO");
    }
