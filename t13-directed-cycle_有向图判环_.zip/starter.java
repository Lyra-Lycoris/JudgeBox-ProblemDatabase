    static long solve(long n, long m, long[][] e) {
        // TODO: 返回位于至少一个有向环上的顶点个数，无环返回 0
        return 0;
    }
