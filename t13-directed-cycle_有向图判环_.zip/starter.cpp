#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回位于至少一个有向环上的顶点个数，无环返回 0
return 0;
}
