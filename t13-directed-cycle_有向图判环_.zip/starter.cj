package t13_directed_cycle

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回位于至少一个有向环上的顶点个数，无环返回 0
return 0
}
