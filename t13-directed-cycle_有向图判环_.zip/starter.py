import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回位于至少一个有向环上的顶点个数，无环返回 0
    return 0
