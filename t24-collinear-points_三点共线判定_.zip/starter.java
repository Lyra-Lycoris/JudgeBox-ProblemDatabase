    static boolean solve(long x1, long y1, long x2, long y2, long x3, long y3) {
        // TODO: 返回 (x1,y1)、(x2,y2)、(x3,y3) 三点是否共线
        return false;
    }
