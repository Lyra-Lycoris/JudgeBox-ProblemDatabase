package t24_collinear_points

import std.convert.Parsable
import std.collection.*

var __tokens = ArrayList<String>()
var __cursor = 0

func __nextToken(): String {
    while (__cursor >= __tokens.size) {
        __tokens = ArrayList<String>()
        let parts = readln().trimAscii().split(" ")
        for (part in parts) {
            if (!part.isEmpty()) {
                __tokens.add(part)
            }
        }
        __cursor = 0
    }
    let value = __tokens[__cursor]
    __cursor += 1
    return value
}

func __nextInt(): Int64 {
    return Int64.parse(__nextToken())
}

func __nextInts(count: Int64): Array<Int64> {
    let values = Array<Int64>(count, repeat: 0)
    for (i in 0..count) {
        values[i] = __nextInt()
    }
    return values
}

func __nextStrings(count: Int64): Array<String> {
    let values = Array<String>(count, repeat: "")
    for (i in 0..count) {
        values[i] = __nextToken()
    }
    return values
}

main(): Unit {
    let T = __nextInt()
    for (_ in 0..T) {
        let x1 = __nextInt()
        let y1 = __nextInt()
        let x2 = __nextInt()
        let y2 = __nextInt()
        let x3 = __nextInt()
        let y3 = __nextInt()
        if (solve(x1, y1, x2, y2, x3, y3)) {
            println("YES")
        } else {
            println("NO")
        }
    }
}
