import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    for _ in range(t):
        x1 = int(data[pos]); pos += 1
        y1 = int(data[pos]); pos += 1
        x2 = int(data[pos]); pos += 1
        y2 = int(data[pos]); pos += 1
        x3 = int(data[pos]); pos += 1
        y3 = int(data[pos]); pos += 1
        print('YES' if solve(x1, y1, x2, y2, x3, y3) else 'NO')


main()
