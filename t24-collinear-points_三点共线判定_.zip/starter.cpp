#include <bits/stdc++.h>
using namespace std;

bool solve(long long x1, long long y1, long long x2, long long y2, long long x3, long long y3) {
    // TODO: 返回 (x1,y1)、(x2,y2)、(x3,y3) 三点是否共线
return false;
}
