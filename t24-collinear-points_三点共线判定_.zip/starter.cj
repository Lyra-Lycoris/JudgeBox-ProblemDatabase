package t24_collinear_points

func solve(x1: Int64, y1: Int64, x2: Int64, y2: Int64, x3: Int64, y3: Int64): Bool {
    // TODO: 返回 (x1,y1)、(x2,y2)、(x3,y3) 三点是否共线
return false
}
