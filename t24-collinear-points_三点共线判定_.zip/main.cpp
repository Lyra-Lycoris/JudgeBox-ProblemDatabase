#include <bits/stdc++.h>
using namespace std;

bool solve(long long x1, long long y1, long long x2, long long y2, long long x3, long long y3);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while (T--) {
        long long x1; cin >> x1;
        long long y1; cin >> y1;
        long long x2; cin >> x2;
        long long y2; cin >> y2;
        long long x3; cin >> x3;
        long long y3; cin >> y3;
        bool answer = solve(x1, y1, x2, y2, x3, y3);
        cout << (answer ? "YES" : "NO") << '\n';
    }
    return 0;
}
