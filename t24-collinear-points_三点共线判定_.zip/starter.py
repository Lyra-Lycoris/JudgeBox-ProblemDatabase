import sys


def solve(x1: int, y1: int, x2: int, y2: int, x3: int, y3: int) -> bool:
    # TODO: 返回 (x1,y1)、(x2,y2)、(x3,y3) 三点是否共线
    return False
