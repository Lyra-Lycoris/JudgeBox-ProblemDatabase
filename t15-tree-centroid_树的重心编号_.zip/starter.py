import sys


def solve(n: int, e: list[int]) -> int:
    # TODO: 返回编号最小的重心节点编号
    return 0
