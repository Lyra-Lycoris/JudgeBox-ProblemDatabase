#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& e) {
    // TODO: 返回编号最小的重心节点编号
return 0;
}
