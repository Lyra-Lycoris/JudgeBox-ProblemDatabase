    static long solve(long n, long[] e) {
        // TODO: 返回编号最小的重心节点编号
        return 0;
    }
