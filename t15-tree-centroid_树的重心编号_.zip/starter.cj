package t15_tree_centroid

func solve(n: Int64, e: Array<Int64>): Int64 {
    // TODO: 返回编号最小的重心节点编号
return 0
}
