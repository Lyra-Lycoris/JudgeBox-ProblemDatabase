#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k, const vector<long long>& p) {
    // TODO: 返回洗牌 k 次后每个位置上的卡片编号
return {};
}
