import sys


def solve(n: int, k: int, p: list[int]) -> list[int]:
    # TODO: 返回洗牌 k 次后每个位置上的卡片编号
    return []
