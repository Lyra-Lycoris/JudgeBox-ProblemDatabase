package t01_card_shuffle

func solve(n: Int64, k: Int64, p: Array<Int64>): Array<Int64> {
    // TODO: 返回洗牌 k 次后每个位置上的卡片编号
return Array<Int64>()
}
