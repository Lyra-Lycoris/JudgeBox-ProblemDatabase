    static long[] solve(long n, long k, long[] p) {
        // TODO: 返回洗牌 k 次后每个位置上的卡片编号
        return new long[0];
    }
