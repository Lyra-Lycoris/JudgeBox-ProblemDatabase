    static long solve(long n, long m, long[][] e) {
        // TODO: 返回这张无向图的连通块数量
        return 0;
    }
