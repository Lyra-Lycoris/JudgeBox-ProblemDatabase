package t10_component_count

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回这张无向图的连通块数量
return 0
}
