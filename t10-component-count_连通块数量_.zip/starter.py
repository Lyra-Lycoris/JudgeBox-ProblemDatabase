import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回这张无向图的连通块数量
    return 0
