#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回这张无向图的连通块数量
return 0;
}
