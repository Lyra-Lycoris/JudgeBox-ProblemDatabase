package t09_task_scheduler

func solve(n: Int64, c: Int64, tasks: Array<Int64>): Int64 {
    // TODO: 返回执行完所有任务所需的最少总时间
return 0
}
