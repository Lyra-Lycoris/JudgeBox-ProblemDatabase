#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long c, const vector<long long>& tasks);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long c; cin >> c;
    vector<long long> tasks(n); for (auto& x : tasks) cin >> x;
    long long answer = solve(n, c, tasks);
    cout << answer << '\n';
    return 0;
}
