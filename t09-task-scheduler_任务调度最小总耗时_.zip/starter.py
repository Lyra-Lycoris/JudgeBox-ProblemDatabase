import sys


def solve(n: int, c: int, tasks: list[int]) -> int:
    # TODO: 返回执行完所有任务所需的最少总时间
    return 0
