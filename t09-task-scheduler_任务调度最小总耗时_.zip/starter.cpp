#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long c, const vector<long long>& tasks) {
    // TODO: 返回执行完所有任务所需的最少总时间
return 0;
}
