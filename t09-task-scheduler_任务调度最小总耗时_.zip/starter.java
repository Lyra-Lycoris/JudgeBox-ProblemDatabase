    static long solve(long n, long c, long[] tasks) {
        // TODO: 返回执行完所有任务所需的最少总时间
        return 0;
    }
