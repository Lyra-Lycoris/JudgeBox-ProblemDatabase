import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    c = int(data[pos]); pos += 1
    tasks = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, c, tasks))


main()
