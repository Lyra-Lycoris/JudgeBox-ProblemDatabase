package t28_misere_nim

func solve(n: Int64, a: Array<Int64>): Bool {
    // TODO: 返回 true 表示先手必胜（输出 YES），否则返回 false（输出 NO）
return false
}
