#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, const vector<long long>& a);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> a(n); for (auto& x : a) cin >> x;
    bool answer = solve(n, a);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
