import sys


def solve(n: int, a: list[int]) -> bool:
    # TODO: 返回 true 表示先手必胜（输出 YES），否则返回 false（输出 NO）
    return False
