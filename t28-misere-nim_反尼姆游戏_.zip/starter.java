    static boolean solve(long n, long[] a) {
        // TODO: 返回 true 表示先手必胜（输出 YES），否则返回 false（输出 NO）
        return false;
    }
