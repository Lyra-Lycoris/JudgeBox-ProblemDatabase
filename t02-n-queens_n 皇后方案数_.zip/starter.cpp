#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 n x n 棋盘上互不攻击的 n 皇后摆放方案数
return 0;
}
