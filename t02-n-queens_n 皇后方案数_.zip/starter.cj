package t02_n_queens

func solve(n: Int64): Int64 {
    // TODO: 返回 n x n 棋盘上互不攻击的 n 皇后摆放方案数
return 0
}
