import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回环形数组中两两不相邻的子集的最大元素和（子集可以为空）
    return 0
