package t27_circular_nonadjacent

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回环形数组中两两不相邻的子集的最大元素和（子集可以为空）
return 0
}
