import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    x = int(data[pos]); pos += 1
    print(solve(x))


main()
