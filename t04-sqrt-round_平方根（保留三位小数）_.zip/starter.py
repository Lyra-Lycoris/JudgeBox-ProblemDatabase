import sys


def solve(x: int) -> int:
    # TODO: 返回 floor(1000*sqrt(x) + 0.5)，即把 sqrt(x) 四舍五入到小数点后 3 位再乘以 1000
    return 0
