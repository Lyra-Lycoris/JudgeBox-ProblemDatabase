#include <bits/stdc++.h>
using namespace std;

long long solve(long long x);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long x; cin >> x;
    long long answer = solve(x);
    cout << answer << '\n';
    return 0;
}
