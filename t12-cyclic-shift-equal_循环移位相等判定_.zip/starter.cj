package t12_cyclic_shift_equal

func solve(n: Int64, s: String, t: String): Bool {
    // TODO: 返回 t 是否可以由 s 循环移位得到
return false
}
