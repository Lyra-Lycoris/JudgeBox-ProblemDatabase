#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, string s, string t);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    string s; cin >> s;
    string t; cin >> t;
    bool answer = solve(n, s, t);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
