import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    s = data[pos].decode(); pos += 1
    t = data[pos].decode(); pos += 1
    print('YES' if solve(n, s, t) else 'NO')


main()
