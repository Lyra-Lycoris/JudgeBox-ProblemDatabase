import sys


def solve(n: int, s: str, t: str) -> bool:
    # TODO: 返回 t 是否可以由 s 循环移位得到
    return False
