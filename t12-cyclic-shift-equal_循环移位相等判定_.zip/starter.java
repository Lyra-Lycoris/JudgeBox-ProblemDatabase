    static boolean solve(long n, String s, String t) {
        // TODO: 返回 t 是否可以由 s 循环移位得到
        return false;
    }
