package t19_digit_sum_total

func solve(l: Int64, r: Int64): Int64 {
    // TODO: 返回 [l, r] 中所有整数数位之和的总和
return 0
}
