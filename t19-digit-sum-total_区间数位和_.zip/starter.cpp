#include <bits/stdc++.h>
using namespace std;

long long solve(long long l, long long r) {
    // TODO: 返回 [l, r] 中所有整数数位之和的总和
return 0;
}
