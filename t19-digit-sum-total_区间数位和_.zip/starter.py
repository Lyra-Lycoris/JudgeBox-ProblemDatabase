import sys


def solve(l: int, r: int) -> int:
    # TODO: 返回 [l, r] 中所有整数数位之和的总和
    return 0
