#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回不小于 n 的最小回文数
return 0;
}
