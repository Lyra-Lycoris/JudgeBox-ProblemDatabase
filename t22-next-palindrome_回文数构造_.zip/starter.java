    static long solve(long n) {
        // TODO: 返回不小于 n 的最小回文数
        return 0;
    }
