package t22_next_palindrome

func solve(n: Int64): Int64 {
    // TODO: 返回不小于 n 的最小回文数
return 0
}
