#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long x) {
    // TODO: 返回最小的下标 i 使 a[i] >= x（下标从 0 开始）；若不存在这样的 i 则返回 n
return 0;
}
