package t04_lower_bound

func solve(n: Int64, a: Array<Int64>, x: Int64): Int64 {
    // TODO: 返回最小的下标 i 使 a[i] >= x（下标从 0 开始）；若不存在这样的 i 则返回 n
return 0
}
