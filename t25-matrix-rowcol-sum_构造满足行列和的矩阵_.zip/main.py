import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    r = [int(x) for x in data[pos:pos + n]]; pos += n
    c = [int(x) for x in data[pos:pos + m]]; pos += m
    print(' '.join(str(x) for x in solve(n, m, r, c)))


main()
