package t25_matrix_rowcol_sum

func solve(n: Int64, m: Int64, r: Array<Int64>, c: Array<Int64>): Array<Int64> {
    // TODO: 返回按行优先展开的 n*m 个非负整数，使第 i 行之和为 r[i]、第 j 列之和为 c[j]；本题使用特殊评判
return Array<Int64>()
}
