#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<long long>& r, const vector<long long>& c) {
    // TODO: 返回按行优先展开的 n*m 个非负整数，使第 i 行之和为 r[i]、第 j 列之和为 c[j]；本题使用特殊评判
return {};
}
