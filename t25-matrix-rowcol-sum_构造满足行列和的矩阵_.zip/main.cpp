#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<long long>& r, const vector<long long>& c);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<long long> r(n); for (auto& x : r) cin >> x;
    vector<long long> c(m); for (auto& x : c) cin >> x;
    vector<long long> answer = solve(n, m, r, c);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
