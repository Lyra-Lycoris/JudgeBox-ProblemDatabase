import sys


def solve(n: int, m: int, r: list[int], c: list[int]) -> list[int]:
    # TODO: 返回按行优先展开的 n*m 个非负整数，使第 i 行之和为 r[i]、第 j 列之和为 c[j]；本题使用特殊评判
    return []
