package cf1385d

import std.convert.Parsable

main(): Unit {
    let n = Int64.parse(readln().trimAscii())
    let s = readln().trimAscii()
    println(solve(n, s))
}
