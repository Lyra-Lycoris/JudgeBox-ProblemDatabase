def solve(n: int, s: str) -> int:
    def cost(left: int, length: int, ch: str) -> int:
        if length == 1:
            return 0 if s[left] == ch else 1
        half = length // 2
        nxt = chr(ord(ch) + 1)
        left_bad = half - s.count(ch, left, left + half)
        right_bad = half - s.count(ch, left + half, left + length)
        a = left_bad + cost(left + half, half, nxt)
        b = right_bad + cost(left, half, nxt)
        return a if a < b else b

    return cost(0, n, 'a')
