    static long cost(String s, int l, int len, char c) {
        if (len == 1) return s.charAt(l) == c ? 0 : 1;
        int half = len / 2;
        int leftBad = 0, rightBad = 0;
        for (int i = l; i < l + half; ++i) if (s.charAt(i) != c) ++leftBad;
        for (int i = l + half; i < l + len; ++i) if (s.charAt(i) != c) ++rightBad;
        char next = (char) (c + 1);
        long a = leftBad + cost(s, l + half, half, next);
        long b = rightBad + cost(s, l, half, next);
        return Math.min(a, b);
    }

    static long solve(int n, String s) {
        return cost(s, 0, n, 'a');
    }
