#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const string& s) {
    // TODO: 分治求最少修改次数
    (void)n;
    (void)s;
    return 0;
}
