def solve(n: int, s: str) -> int:
    # TODO: 分治求最少修改次数
    return 0
