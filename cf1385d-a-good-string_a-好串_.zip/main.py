import sys


def main():
    sys.setrecursionlimit(1 << 20)
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    s = data[1].decode()
    print(solve(n, s))


main()
