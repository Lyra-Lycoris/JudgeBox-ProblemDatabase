package cf1385d

func cost(s: String, l: Int64, length: Int64, c: UInt8): Int64 {
    if (length == 1) {
        if (s[l] == c) {
            return 0
        }
        return 1
    }
    let half = length / 2
    var leftBad = 0
    var rightBad = 0
    for (i in l..l + half) {
        if (s[i] != c) {
            leftBad += 1
        }
    }
    for (i in l + half..l + length) {
        if (s[i] != c) {
            rightBad += 1
        }
    }
    let next: UInt8 = c + 1
    let a = leftBad + cost(s, l + half, half, next)
    let b = rightBad + cost(s, l, half, next)
    if (a < b) {
        return a
    }
    return b
}

func solve(n: Int64, s: String): Int64 {
    let first: UInt8 = 97
    return cost(s, 0, n, first)
}
