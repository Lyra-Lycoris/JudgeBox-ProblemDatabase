package cf1385d

func solve(n: Int64, s: String): Int64 {
    // TODO: 分治求最少修改次数
    return 0
}
