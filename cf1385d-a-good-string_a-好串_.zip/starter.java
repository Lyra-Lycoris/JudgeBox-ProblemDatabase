    static long solve(int n, String s) {
        // TODO: 分治求最少修改次数
        return 0;
    }
