#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const string& s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n)) return 0;
    string s;
    cin >> s;
    cout << solve(n, s) << '\n';
    return 0;
}
