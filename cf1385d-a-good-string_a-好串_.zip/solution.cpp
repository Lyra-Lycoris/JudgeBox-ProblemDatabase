#include <bits/stdc++.h>
using namespace std;

static long long cost(const string& s, int l, int len, char c) {
    if (len == 1) return s[l] == c ? 0 : 1;
    int half = len / 2;
    int leftBad = 0, rightBad = 0;
    for (int i = l; i < l + half; ++i)
        if (s[i] != c) ++leftBad;
    for (int i = l + half; i < l + len; ++i)
        if (s[i] != c) ++rightBad;
    char next = c + 1;
    long long a = leftBad + cost(s, l + half, half, next);
    long long b = rightBad + cost(s, l, half, next);
    return min(a, b);
}

long long solve(int n, const string& s) {
    return cost(s, 0, n, 'a');
}
