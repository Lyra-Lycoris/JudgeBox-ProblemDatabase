import sys


def solve(n: int) -> int:
    # TODO: 返回反复掷六面骰子后点数之和恰好为 n 的概率，按 p * q^{-1} mod 1000000007 输出
    return 0
