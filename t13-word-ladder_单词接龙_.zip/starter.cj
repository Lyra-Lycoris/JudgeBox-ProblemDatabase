package t13_word_ladder

func solve(n: Int64, begin: String, end: String, w: Array<String>): Int64 {
    // TODO: 返回最短接龙序列的单词个数，无法接龙返回 0
return 0
}
