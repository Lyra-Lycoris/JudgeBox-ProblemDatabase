    static long solve(long n, String begin, String end, String[] w) {
        // TODO: 返回最短接龙序列的单词个数，无法接龙返回 0
        return 0;
    }
