#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string begin, string end, const vector<string>& w) {
    // TODO: 返回最短接龙序列的单词个数，无法接龙返回 0
return 0;
}
