import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    begin = data[pos].decode(); pos += 1
    end = data[pos].decode(); pos += 1
    w = [x.decode() for x in data[pos:pos + n]]; pos += n
    print(solve(n, begin, end, w))


main()
