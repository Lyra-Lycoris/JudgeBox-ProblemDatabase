#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string begin, string end, const vector<string>& w);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    string begin; cin >> begin;
    string end; cin >> end;
    vector<string> w(n); for (auto& x : w) cin >> x;
    long long answer = solve(n, begin, end, w);
    cout << answer << '\n';
    return 0;
}
