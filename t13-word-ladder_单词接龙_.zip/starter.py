import sys


def solve(n: int, begin: str, end: str, w: list[str]) -> int:
    # TODO: 返回最短接龙序列的单词个数，无法接龙返回 0
    return 0
