    static long solve(long n, long[] a, long k) {
        // TODO: 返回把数组分成 k 段非空连续子数组后，各段和的最大值的最小可能值
        return 0;
    }
