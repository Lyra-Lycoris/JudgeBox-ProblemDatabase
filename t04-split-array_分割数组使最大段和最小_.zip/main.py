import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    k = int(data[pos]); pos += 1
    print(solve(n, a, k))


main()
