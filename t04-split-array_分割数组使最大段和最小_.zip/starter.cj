package t04_split_array

func solve(n: Int64, a: Array<Int64>, k: Int64): Int64 {
    // TODO: 返回把数组分成 k 段非空连续子数组后，各段和的最大值的最小可能值
return 0
}
