    static boolean solve(long n, long m, long[][] e) {
        // TODO: 能否修完全部课程：约束无环输出 YES，否则 NO
        return false;
    }
