package t13_course_schedule

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Bool {
    // TODO: 能否修完全部课程：约束无环输出 YES，否则 NO
return false
}
