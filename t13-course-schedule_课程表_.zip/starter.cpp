#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 能否修完全部课程：约束无环输出 YES，否则 NO
return false;
}
