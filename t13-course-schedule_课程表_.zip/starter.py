import sys


def solve(n: int, m: int, e: list[list[int]]) -> bool:
    # TODO: 能否修完全部课程：约束无环输出 YES，否则 NO
    return False
