package t09_stream_median

func solve(n: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回插入每个数之后的中位数序列（共 n 个）
return Array<Int64>()
}
