#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a) {
    // TODO: 返回插入每个数之后的中位数序列（共 n 个）
return {};
}
