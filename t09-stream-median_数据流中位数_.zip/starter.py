import sys


def solve(n: int, a: list[int]) -> list[int]:
    # TODO: 返回插入每个数之后的中位数序列（共 n 个）
    return []
