    static long[] solve(long n, long[] a) {
        // TODO: 返回插入每个数之后的中位数序列（共 n 个）
        return new long[0];
    }
