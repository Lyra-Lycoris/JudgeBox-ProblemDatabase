import sys


def solve(n: int, m: int, g: list[list[int]]) -> int:
    # TODO: 返回从 (1,1) 走到 (n,m) 的最小消耗
    return 0
