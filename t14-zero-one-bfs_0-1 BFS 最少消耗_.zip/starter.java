    static long solve(long n, long m, long[][] g) {
        // TODO: 返回从 (1,1) 走到 (n,m) 的最小消耗
        return 0;
    }
