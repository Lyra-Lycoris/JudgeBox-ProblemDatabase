#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& g) {
    // TODO: 返回从 (1,1) 走到 (n,m) 的最小消耗
return 0;
}
