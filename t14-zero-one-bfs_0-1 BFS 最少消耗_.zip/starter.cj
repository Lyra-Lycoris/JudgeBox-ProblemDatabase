package t14_zero_one_bfs

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>): Int64 {
    // TODO: 返回从 (1,1) 走到 (n,m) 的最小消耗
return 0
}
