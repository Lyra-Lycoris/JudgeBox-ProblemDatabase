package t04_rotated_min

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回旋转后数组中的最小元素
return 0
}
