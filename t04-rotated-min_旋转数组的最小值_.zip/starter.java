    static long solve(long n, long[] a) {
        // TODO: 返回旋转后数组中的最小元素
        return 0;
    }
