#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long target, const vector<long long>& coins) {
    // TODO: 返回凑出 target 的方案数，对 1000000007 取模
return 0;
}
