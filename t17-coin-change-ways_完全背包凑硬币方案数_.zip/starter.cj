package t17_coin_change_ways

func solve(n: Int64, target: Int64, coins: Array<Int64>): Int64 {
    // TODO: 返回凑出 target 的方案数，对 1000000007 取模
return 0
}
