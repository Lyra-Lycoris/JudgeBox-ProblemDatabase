#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long target, const vector<long long>& coins);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long target; cin >> target;
    vector<long long> coins(n); for (auto& x : coins) cin >> x;
    long long answer = solve(n, target, coins);
    cout << answer << '\n';
    return 0;
}
