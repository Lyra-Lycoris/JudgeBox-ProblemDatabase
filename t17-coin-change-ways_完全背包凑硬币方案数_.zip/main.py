import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    target = int(data[pos]); pos += 1
    coins = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, target, coins))


main()
