import sys


def solve(n: int, target: int, coins: list[int]) -> int:
    # TODO: 返回凑出 target 的方案数，对 1000000007 取模
    return 0
