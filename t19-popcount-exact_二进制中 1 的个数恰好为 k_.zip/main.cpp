#include <bits/stdc++.h>
using namespace std;

long long solve(long long l, long long r, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long l; cin >> l;
    long long r; cin >> r;
    long long k; cin >> k;
    long long answer = solve(l, r, k);
    cout << answer << '\n';
    return 0;
}
