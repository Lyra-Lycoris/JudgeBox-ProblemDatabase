#include <bits/stdc++.h>
using namespace std;

long long solve(long long l, long long r, long long k) {
    // TODO: 返回 [l, r] 中二进制表示恰好含 k 个 1 的整数个数
return 0;
}
