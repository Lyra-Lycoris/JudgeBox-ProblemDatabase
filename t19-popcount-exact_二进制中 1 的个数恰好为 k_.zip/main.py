import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    l = int(data[pos]); pos += 1
    r = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    print(solve(l, r, k))


main()
