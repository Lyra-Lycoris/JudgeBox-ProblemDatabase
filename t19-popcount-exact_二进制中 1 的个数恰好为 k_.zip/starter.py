import sys


def solve(l: int, r: int, k: int) -> int:
    # TODO: 返回 [l, r] 中二进制表示恰好含 k 个 1 的整数个数
    return 0
