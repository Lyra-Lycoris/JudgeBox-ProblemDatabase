package t19_popcount_exact

func solve(l: Int64, r: Int64, k: Int64): Int64 {
    // TODO: 返回 [l, r] 中二进制表示恰好含 k 个 1 的整数个数
return 0
}
