#include <bits/stdc++.h>
using namespace std;

long long solve(long long a, long long m) {
    // TODO: 返回 a 模 m 的最小非负逆元，不存在逆元时返回 -1
return 0;
}
