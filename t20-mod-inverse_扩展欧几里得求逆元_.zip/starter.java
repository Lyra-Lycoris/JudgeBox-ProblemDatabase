    static long solve(long a, long m) {
        // TODO: 返回 a 模 m 的最小非负逆元，不存在逆元时返回 -1
        return 0;
    }
