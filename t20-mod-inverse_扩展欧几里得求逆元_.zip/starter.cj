package t20_mod_inverse

func solve(a: Int64, m: Int64): Int64 {
    // TODO: 返回 a 模 m 的最小非负逆元，不存在逆元时返回 -1
return 0
}
