#include <bits/stdc++.h>
using namespace std;

long long solve(long long a, long long m);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long a; cin >> a;
    long long m; cin >> m;
    long long answer = solve(a, m);
    cout << answer << '\n';
    return 0;
}
