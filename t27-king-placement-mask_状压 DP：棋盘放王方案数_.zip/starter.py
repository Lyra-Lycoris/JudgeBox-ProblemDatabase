import sys


def solve(n: int, m: int, blocked: list[int]) -> int:
    # TODO: 返回合法摆放方案数对 1000000007 取模的结果
    return 0
