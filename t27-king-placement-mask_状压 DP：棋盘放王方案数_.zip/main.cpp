#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<long long>& blocked);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<long long> blocked(n); for (auto& x : blocked) cin >> x;
    long long answer = solve(n, m, blocked);
    cout << answer << '\n';
    return 0;
}
