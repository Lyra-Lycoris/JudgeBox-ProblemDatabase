package t27_king_placement_mask

func solve(n: Int64, m: Int64, blocked: Array<Int64>): Int64 {
    // TODO: 返回合法摆放方案数对 1000000007 取模的结果
return 0
}
