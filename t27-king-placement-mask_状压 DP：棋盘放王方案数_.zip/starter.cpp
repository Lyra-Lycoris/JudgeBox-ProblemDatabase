#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<long long>& blocked) {
    // TODO: 返回合法摆放方案数对 1000000007 取模的结果
return 0;
}
