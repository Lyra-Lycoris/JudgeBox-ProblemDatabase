package t22_min_bit_ops

func solve(n: Int64): Int64 {
    // TODO: 返回把 n 变成 0 所需的最少操作次数
return 0
}
