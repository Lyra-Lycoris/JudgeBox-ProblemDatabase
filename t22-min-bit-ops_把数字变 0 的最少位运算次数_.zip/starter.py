import sys


def solve(n: int) -> int:
    # TODO: 返回把 n 变成 0 所需的最少操作次数
    return 0
