#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回把 n 变成 0 所需的最少操作次数
return 0;
}
