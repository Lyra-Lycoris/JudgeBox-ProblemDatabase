package t13_graph_components

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回无向图的连通分量个数，孤立点也算一个分量
return 0
}
