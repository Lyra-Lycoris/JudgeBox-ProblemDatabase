import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回无向图的连通分量个数，孤立点也算一个分量
    return 0
