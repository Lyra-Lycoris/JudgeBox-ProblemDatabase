#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回无向图的连通分量个数，孤立点也算一个分量
return 0;
}
