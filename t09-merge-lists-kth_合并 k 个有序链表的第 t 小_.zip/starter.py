import sys


def solve(k: int, m: int, t: int, lists: list[list[int]]) -> int:
    # TODO: 返回 k 个有序序列合并后的第 t 小元素
    return 0
