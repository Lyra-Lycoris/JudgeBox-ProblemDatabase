#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, long long m, long long t, const vector<vector<long long>>& lists);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long k; cin >> k;
    long long m; cin >> m;
    long long t; cin >> t;
    vector<vector<long long>> lists(k, vector<long long>(m)); for (auto& row : lists) for (auto& x : row) cin >> x;
    long long answer = solve(k, m, t, lists);
    cout << answer << '\n';
    return 0;
}
