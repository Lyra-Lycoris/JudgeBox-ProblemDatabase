#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, long long m, long long t, const vector<vector<long long>>& lists) {
    // TODO: 返回 k 个有序序列合并后的第 t 小元素
return 0;
}
