package t09_merge_lists_kth

func solve(k: Int64, m: Int64, t: Int64, lists: Array<Array<Int64>>): Int64 {
    // TODO: 返回 k 个有序序列合并后的第 t 小元素
return 0
}
