import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    k = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    t = int(data[pos]); pos += 1
    lists = [[int(x) for x in data[pos + r * m: pos + (r + 1) * m]] for r in range(k)]
    pos += k * m
    print(solve(k, m, t, lists))


main()
