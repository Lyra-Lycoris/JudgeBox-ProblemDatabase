    static long solve(long k, long m, long t, long[][] lists) {
        // TODO: 返回 k 个有序序列合并后的第 t 小元素
        return 0;
    }
