import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回出现次数严格大于 n/2 的那个数（保证存在）
    return 0
