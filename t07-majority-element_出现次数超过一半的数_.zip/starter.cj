package t07_majority_element

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回出现次数严格大于 n/2 的那个数（保证存在）
return 0
}
