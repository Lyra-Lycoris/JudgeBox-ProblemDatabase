    static long solve(long n, long[] a) {
        // TODO: 返回出现次数严格大于 n/2 的那个数（保证存在）
        return 0;
    }
