#include <bits/stdc++.h>
using namespace std;

long long solve(string s, string t);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; cin >> s;
    string t; cin >> t;
    long long answer = solve(s, t);
    cout << answer << '\n';
    return 0;
}
