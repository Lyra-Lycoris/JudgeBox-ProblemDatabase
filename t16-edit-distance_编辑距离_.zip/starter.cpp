#include <bits/stdc++.h>
using namespace std;

long long solve(string s, string t) {
    // TODO: 返回把 s 变成 t 所需的最少单字符编辑次数
return 0;
}
