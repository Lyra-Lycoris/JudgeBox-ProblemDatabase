import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    s = data[pos].decode(); pos += 1
    t = data[pos].decode(); pos += 1
    print(solve(s, t))


main()
