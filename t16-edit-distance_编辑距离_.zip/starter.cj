package t16_edit_distance

func solve(s: String, t: String): Int64 {
    // TODO: 返回把 s 变成 t 所需的最少单字符编辑次数
return 0
}
