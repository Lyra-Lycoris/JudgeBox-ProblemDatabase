import sys


def solve(s: str, t: str) -> int:
    # TODO: 返回把 s 变成 t 所需的最少单字符编辑次数
    return 0
