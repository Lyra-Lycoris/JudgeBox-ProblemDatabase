#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回数组 a 的 n 个元素作为多重集时不同排列的个数，对 1000000007 取模
return 0;
}
