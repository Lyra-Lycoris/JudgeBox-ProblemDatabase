import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回数组 a 的 n 个元素作为多重集时不同排列的个数，对 1000000007 取模
    return 0
