package t21_multiset_perm

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回数组 a 的 n 个元素作为多重集时不同排列的个数，对 1000000007 取模
return 0
}
