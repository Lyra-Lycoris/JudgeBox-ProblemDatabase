import sys


def solve(n: int, s: str) -> int:
    # TODO: 返回字符串的最小循环节长度 d（要求 d 整除 n）
    return 0
