import sys


def solve(a: int, b: int) -> list[int]:
    # TODO: 返回 [a 与 b 的最大公约数, a 与 b 的最小公倍数]
    return []
