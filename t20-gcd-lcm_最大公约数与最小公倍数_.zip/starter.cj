package t20_gcd_lcm

func solve(a: Int64, b: Int64): Array<Int64> {
    // TODO: 返回 [a 与 b 的最大公约数, a 与 b 的最小公倍数]
return Array<Int64>()
}
