#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long a, long long b);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while (T--) {
        long long a; cin >> a;
        long long b; cin >> b;
        vector<long long> answer = solve(a, b);
        for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
        if (answer.empty()) cout << '\n';
    }
    return 0;
}
