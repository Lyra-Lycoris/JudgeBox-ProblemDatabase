import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    for _ in range(t):
        a = int(data[pos]); pos += 1
        b = int(data[pos]); pos += 1
        print(' '.join(str(x) for x in solve(a, b)))


main()
