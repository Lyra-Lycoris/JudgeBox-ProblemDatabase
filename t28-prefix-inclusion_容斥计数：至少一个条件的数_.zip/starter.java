    static long solve(long n, long m, long[][] cond) {
        // TODO: 返回 [1, n] 中至少满足一个条件的整数个数
        return 0;
    }
