import sys


def solve(n: int, m: int, cond: list[list[int]]) -> int:
    # TODO: 返回 [1, n] 中至少满足一个条件的整数个数
    return 0
