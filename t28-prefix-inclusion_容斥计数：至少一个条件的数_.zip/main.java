    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long m = Long.parseLong(st.nextToken());
        long[][] cond = new long[(int) (m)][(int) (2)];
        for (int i = 0; i < cond.length; ++i) for (int j = 0; j < cond[i].length; ++j) cond[i][j] = Long.parseLong(st.nextToken());
        System.out.println(solve(n, m, cond));
    }
