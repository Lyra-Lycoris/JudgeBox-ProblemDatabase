#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& cond) {
    // TODO: 返回 [1, n] 中至少满足一个条件的整数个数
return 0;
}
