package t28_prefix_inclusion

func solve(n: Int64, m: Int64, cond: Array<Array<Int64>>): Int64 {
    // TODO: 返回 [1, n] 中至少满足一个条件的整数个数
return 0
}
