import sys


def solve(s: str) -> int:
    # TODO: 返回最长无重复字符子串的长度
    return 0
