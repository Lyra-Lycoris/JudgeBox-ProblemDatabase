#include <bits/stdc++.h>
using namespace std;

long long solve(string s) {
    // TODO: 返回最长无重复字符子串的长度
return 0;
}
