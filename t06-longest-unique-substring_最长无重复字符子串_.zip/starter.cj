package t06_longest_unique_substring

func solve(s: String): Int64 {
    // TODO: 返回最长无重复字符子串的长度
return 0
}
