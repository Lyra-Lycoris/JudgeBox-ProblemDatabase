package t15_sum_pair_dist

func solve(n: Int64, e: Array<Int64>): Int64 {
    // TODO: 返回所有无序点对之间距离的总和
return 0
}
