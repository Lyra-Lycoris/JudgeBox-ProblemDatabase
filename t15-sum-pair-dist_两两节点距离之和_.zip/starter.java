    static long solve(long n, long[] e) {
        // TODO: 返回所有无序点对之间距离的总和
        return 0;
    }
