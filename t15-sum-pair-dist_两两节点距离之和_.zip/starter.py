import sys


def solve(n: int, e: list[int]) -> int:
    # TODO: 返回所有无序点对之间距离的总和
    return 0
