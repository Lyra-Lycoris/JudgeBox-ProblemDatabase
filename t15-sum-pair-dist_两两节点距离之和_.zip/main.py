import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    e = [int(x) for x in data[pos:pos + 2*(n-1)]]; pos += 2*(n-1)
    print(solve(n, e))


main()
