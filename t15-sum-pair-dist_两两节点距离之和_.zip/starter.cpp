#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& e) {
    // TODO: 返回所有无序点对之间距离的总和
return 0;
}
