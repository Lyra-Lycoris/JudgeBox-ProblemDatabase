import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    target = int(data[pos]); pos += 1
    n = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    print('YES' if solve(target, n, a) else 'NO')


main()
