#include <bits/stdc++.h>
using namespace std;

bool solve(long long target, long long n, const vector<long long>& a) {
    // TODO: 判断是否存在一个子集（允许空集）其元素和恰好等于 target
return false;
}
