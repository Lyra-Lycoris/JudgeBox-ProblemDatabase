    static boolean solve(long target, long n, long[] a) {
        // TODO: 判断是否存在一个子集（允许空集）其元素和恰好等于 target
        return false;
    }
