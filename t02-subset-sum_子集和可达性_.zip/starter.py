import sys


def solve(target: int, n: int, a: list[int]) -> bool:
    # TODO: 判断是否存在一个子集（允许空集）其元素和恰好等于 target
    return False
