package t02_subset_sum

func solve(target: Int64, n: Int64, a: Array<Int64>): Bool {
    // TODO: 判断是否存在一个子集（允许空集）其元素和恰好等于 target
return false
}
