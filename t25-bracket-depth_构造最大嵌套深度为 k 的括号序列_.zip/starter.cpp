#include <bits/stdc++.h>
using namespace std;

string solve(long long n, long long k) {
    // TODO: 返回任意一个长度为 n、最大嵌套深度为 k 的合法括号序列；本题使用特殊评判
return "";
}
