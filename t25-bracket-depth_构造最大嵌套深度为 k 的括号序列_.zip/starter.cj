package t25_bracket_depth

func solve(n: Int64, k: Int64): String {
    // TODO: 返回任意一个长度为 n、最大嵌套深度为 k 的合法括号序列；本题使用特殊评判
return ""
}
