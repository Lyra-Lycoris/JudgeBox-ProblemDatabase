#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a) {
    // TODO: 返回把数组变成非递减序列所需的最少相邻交换次数
return 0;
}
