    static long solve(long n, long[] a) {
        // TODO: 返回把数组变成非递减序列所需的最少相邻交换次数
        return 0;
    }
