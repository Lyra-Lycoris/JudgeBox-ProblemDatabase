package t03_min_adjacent_swaps

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把数组变成非递减序列所需的最少相邻交换次数
return 0
}
