import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    a = data[pos].decode(); pos += 1
    b = data[pos].decode(); pos += 1
    print(solve(a, b))


main()
