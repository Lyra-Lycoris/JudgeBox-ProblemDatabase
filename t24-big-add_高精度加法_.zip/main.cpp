#include <bits/stdc++.h>
using namespace std;

string solve(string a, string b);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string a; cin >> a;
    string b; cin >> b;
    string answer = solve(a, b);
    cout << answer << '\n';
    return 0;
}
