package t24_big_add

func solve(a: String, b: String): String {
    // TODO: 返回 a+b 的十进制字符串（不含前导零）
return ""
}
