    static long solve(long n) {
        // TODO: 返回长度为 2n 的合法括号序列个数对 1000000007 取模的结果
        return 0;
    }
