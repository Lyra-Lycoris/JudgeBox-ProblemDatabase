import sys


def solve(n: int, k: int) -> int:
    # TODO: 返回从 n 个不同物品中选 k 个的方案数 C(n, k) 对 1000000007 取模的结果
    return 0
