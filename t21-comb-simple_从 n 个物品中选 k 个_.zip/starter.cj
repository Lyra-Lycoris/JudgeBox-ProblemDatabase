package t21_comb_simple

func solve(n: Int64, k: Int64): Int64 {
    // TODO: 返回从 n 个不同物品中选 k 个的方案数 C(n, k) 对 1000000007 取模的结果
return 0
}
