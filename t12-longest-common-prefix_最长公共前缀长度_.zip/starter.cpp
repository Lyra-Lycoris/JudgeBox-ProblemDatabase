#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<string>& words) {
    // TODO: 返回所有字符串的最长公共前缀长度
return 0;
}
