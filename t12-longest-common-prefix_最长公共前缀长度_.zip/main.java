    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long k = Long.parseLong(st.nextToken());
        String[] words = new String[(int) (k)];
        for (int i = 0; i < words.length; ++i) words[i] = st.nextToken();
        System.out.println(solve(k, words));
    }
