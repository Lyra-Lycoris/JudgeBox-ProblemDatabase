#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, const vector<string>& words);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long k; cin >> k;
    vector<string> words(k); for (auto& x : words) cin >> x;
    long long answer = solve(k, words);
    cout << answer << '\n';
    return 0;
}
