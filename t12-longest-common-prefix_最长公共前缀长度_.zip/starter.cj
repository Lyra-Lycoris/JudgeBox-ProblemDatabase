package t12_longest_common_prefix

func solve(k: Int64, words: Array<String>): Int64 {
    // TODO: 返回所有字符串的最长公共前缀长度
return 0
}
