import sys


def solve(k: int, words: list[str]) -> int:
    # TODO: 返回所有字符串的最长公共前缀长度
    return 0
