#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& piles, long long k) {
    priority_queue<long long> heap;
    long long total = 0;
    for (long long x : piles) {
        total += x;
        heap.push(x);
    }
    for (long long i = 0; i < k; ++i) {
        long long x = heap.top();
        heap.pop();
        long long removed = x / 2;
        total -= removed;
        heap.push(x - removed);
    }
    return total;
}
