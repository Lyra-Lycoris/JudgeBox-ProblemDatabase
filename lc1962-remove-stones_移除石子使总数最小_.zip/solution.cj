package lc1962

func solve(piles: Array<Int64>, k: Int64): Int64 {
    let heap = MaxHeap(piles.size)
    var total = 0
    for (x in piles) {
        total += x
        heap.push(x)
    }
    var ops = 0
    while (ops < k) {
        let x = heap.pop()
        let removed = x / 2
        total -= removed
        heap.push(x - removed)
        ops += 1
    }
    return total
}

class MaxHeap {
    private var data: Array<Int64>
    private var heapSize: Int64

    init(capacity: Int64) {
        let cap = max(capacity, 1)
        this.data = Array<Int64>(cap, repeat: 0)
        this.heapSize = 0
    }

    func push(value: Int64): Unit {
        var index = this.heapSize
        this.data[index] = value
        this.heapSize += 1
        while (index > 0) {
            let parent = (index - 1) / 2
            if (this.data[parent] < this.data[index]) {
                let temp = this.data[parent]
                this.data[parent] = this.data[index]
                this.data[index] = temp
                index = parent
            } else {
                break
            }
        }
    }

    func pop(): Int64 {
        let top = this.data[0]
        this.heapSize -= 1
        this.data[0] = this.data[this.heapSize]
        var index = 0
        while (true) {
            let left = 2 * index + 1
            let right = left + 1
            var largest = index
            if (left < this.heapSize && this.data[left] > this.data[largest]) {
                largest = left
            }
            if (right < this.heapSize && this.data[right] > this.data[largest]) {
                largest = right
            }
            if (largest == index) {
                break
            }
            let temp = this.data[largest]
            this.data[largest] = this.data[index]
            this.data[index] = temp
            index = largest
        }
        return top
    }
}
