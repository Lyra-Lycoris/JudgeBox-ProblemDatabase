#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& piles, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long k;
    if (!(cin >> n >> k)) return 0;
    vector<long long> piles(n);
    for (auto& x : piles) cin >> x;
    cout << solve(piles, k) << '\n';
    return 0;
}
