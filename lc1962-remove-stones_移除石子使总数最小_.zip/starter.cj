package lc1962

func solve(piles: Array<Int64>, k: Int64): Int64 {
    // TODO: 每次取当前最大堆，移除 floor(x/2)，恰好 k 次后求最小总数
    return 0
}
