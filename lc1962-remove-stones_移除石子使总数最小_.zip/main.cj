package lc1962

import std.convert.Parsable

main(): Unit {
    let header = readln().trimAscii().split(" ")
    let n = Int64.parse(header[0])
    let k = Int64.parse(header[1])
    let piles = Array<Int64>(n, repeat: 0)
    var index = 0
    while (index < n) {
        let line = readln().trimAscii()
        for (part in line.split(" ")) {
            if (!part.isEmpty() && index < n) {
                piles[index] = Int64.parse(part)
                index += 1
            }
        }
    }
    println(solve(piles, k))
}
