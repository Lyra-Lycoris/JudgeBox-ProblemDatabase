    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer header = new StringTokenizer(br.readLine());
        int n = Integer.parseInt(header.nextToken());
        int k = Integer.parseInt(header.nextToken());
        long[] piles = new long[n];
        int index = 0;
        while (index < n) {
            String line = br.readLine();
            if (line == null) break;
            StringTokenizer st = new StringTokenizer(line);
            while (st.hasMoreTokens() && index < n) {
                piles[index++] = Long.parseLong(st.nextToken());
            }
        }
        System.out.println(solve(piles, k));
    }
