    static long solve(long[] piles, int k) {
        // TODO: 每次取当前最大堆，移除 floor(x/2)，恰好 k 次后求最小总数
        return 0;
    }
