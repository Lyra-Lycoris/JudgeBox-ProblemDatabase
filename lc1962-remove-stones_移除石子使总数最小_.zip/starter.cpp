#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& piles, long long k) {
    // TODO: 每次取当前最大堆，移除 floor(x/2)，恰好 k 次后求最小总数
    (void)piles;
    (void)k;
    return 0;
}
