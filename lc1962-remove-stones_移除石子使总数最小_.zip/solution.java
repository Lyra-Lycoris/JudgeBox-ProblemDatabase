    static long solve(long[] piles, int k) {
        PriorityQueue<Long> heap = new PriorityQueue<>(Collections.reverseOrder());
        long total = 0;
        for (long x : piles) {
            total += x;
            heap.add(x);
        }
        for (int i = 0; i < k; ++i) {
            long x = heap.poll();
            long removed = x / 2;
            total -= removed;
            heap.add(x - removed);
        }
        return total;
    }
