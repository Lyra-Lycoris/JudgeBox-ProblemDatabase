import heapq


def solve(piles: list[int], k: int) -> int:
    heap = [-x for x in piles]
    heapq.heapify(heap)
    total = sum(piles)
    for _ in range(k):
        x = -heapq.heappop(heap)
        removed = x // 2
        total -= removed
        heapq.heappush(heap, -(x - removed))
    return total
