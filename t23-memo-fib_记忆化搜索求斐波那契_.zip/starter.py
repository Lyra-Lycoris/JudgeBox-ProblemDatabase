import sys


def solve(n: int) -> int:
    # TODO: 返回斐波那契数列第 n 项对 1000000007 取模的结果
    return 0
