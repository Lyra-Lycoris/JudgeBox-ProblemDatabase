#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回斐波那契数列第 n 项对 1000000007 取模的结果
return 0;
}
