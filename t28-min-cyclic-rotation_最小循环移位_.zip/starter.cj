package t28_min_cyclic_rotation

func solve(n: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回字典序最小的循环移位（长度仍为 n）
return Array<Int64>()
}
