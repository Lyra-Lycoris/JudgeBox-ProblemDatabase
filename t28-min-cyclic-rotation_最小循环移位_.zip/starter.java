    static long[] solve(long n, long[] a) {
        // TODO: 返回字典序最小的循环移位（长度仍为 n）
        return new long[0];
    }
