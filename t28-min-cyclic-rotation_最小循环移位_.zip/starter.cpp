#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a) {
    // TODO: 返回字典序最小的循环移位（长度仍为 n）
return {};
}
