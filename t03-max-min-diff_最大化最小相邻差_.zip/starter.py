import sys


def solve(n: int, a: list[int], k: int) -> int:
    # TODO: 返回选出恰好 k 个元素后，相邻元素之差最小值的最大可能值
    return 0
