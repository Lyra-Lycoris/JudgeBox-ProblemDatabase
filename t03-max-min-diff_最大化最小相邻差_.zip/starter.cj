package t03_max_min_diff

func solve(n: Int64, a: Array<Int64>, k: Int64): Int64 {
    // TODO: 返回选出恰好 k 个元素后，相邻元素之差最小值的最大可能值
return 0
}
