#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long k) {
    // TODO: 返回选出恰好 k 个元素后，相邻元素之差最小值的最大可能值
return 0;
}
