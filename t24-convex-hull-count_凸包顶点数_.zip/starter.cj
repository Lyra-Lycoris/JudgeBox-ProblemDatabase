package t24_convex_hull_count

func solve(n: Int64, xs: Array<Int64>, ys: Array<Int64>): Int64 {
    // TODO: 返回凸包的顶点个数（落在凸包边上的中间点不计入）
return 0
}
