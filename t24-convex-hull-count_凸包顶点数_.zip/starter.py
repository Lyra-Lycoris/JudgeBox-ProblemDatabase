import sys


def solve(n: int, xs: list[int], ys: list[int]) -> int:
    # TODO: 返回凸包的顶点个数（落在凸包边上的中间点不计入）
    return 0
