#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& xs, const vector<long long>& ys) {
    // TODO: 返回凸包的顶点个数（落在凸包边上的中间点不计入）
return 0;
}
