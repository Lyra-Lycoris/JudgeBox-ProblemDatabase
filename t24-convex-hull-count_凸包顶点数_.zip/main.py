import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    xs = [int(x) for x in data[pos:pos + n]]; pos += n
    ys = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, xs, ys))


main()
