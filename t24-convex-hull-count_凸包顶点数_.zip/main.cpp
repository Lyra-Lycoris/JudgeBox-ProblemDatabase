#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& xs, const vector<long long>& ys);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> xs(n); for (auto& x : xs) cin >> x;
    vector<long long> ys(n); for (auto& x : ys) cin >> x;
    long long answer = solve(n, xs, ys);
    cout << answer << '\n';
    return 0;
}
