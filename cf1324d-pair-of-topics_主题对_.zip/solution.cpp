#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a, const vector<long long>& b) {
    vector<long long> c(n);
    for (int i = 0; i < n; ++i) c[i] = a[i] - b[i];
    sort(c.begin(), c.end());
    long long answer = 0;
    int left = 0, right = n - 1;
    while (left < right) {
        if (c[left] + c[right] > 0) {
            answer += right - left;
            --right;
        } else {
            ++left;
        }
    }
    return answer;
}
