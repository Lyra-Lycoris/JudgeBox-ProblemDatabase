package cf1324d

import std.sort.*

func solve(n: Int64, a: Array<Int64>, b: Array<Int64>): Int64 {
    let c = Array<Int64>(n, repeat: 0)
    for (i in 0..n) {
        c[i] = a[i] - b[i]
    }
    sort(c)
    var left = 0
    var right = n - 1
    var answer = 0
    while (left < right) {
        if (c[left] + c[right] > 0) {
            answer += right - left
            right -= 1
        } else {
            left += 1
        }
    }
    return answer
}
