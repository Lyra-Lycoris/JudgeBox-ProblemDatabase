#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a, const vector<long long>& b) {
    // TODO: 统计满足 a_i + a_j > b_i + b_j 的主题对 (i < j) 的数量
    (void)n;
    (void)a;
    (void)b;
    return 0;
}
