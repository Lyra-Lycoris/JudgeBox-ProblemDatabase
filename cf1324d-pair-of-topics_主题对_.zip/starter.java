    static long solve(int n, long[] a, long[] b) {
        // TODO: 统计满足 a_i + a_j > b_i + b_j 的主题对 (i < j) 的数量
        return 0;
    }
