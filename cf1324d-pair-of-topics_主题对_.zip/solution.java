    static long solve(int n, long[] a, long[] b) {
        long[] c = new long[n];
        for (int i = 0; i < n; ++i) c[i] = a[i] - b[i];
        Arrays.sort(c);
        long answer = 0;
        int left = 0, right = n - 1;
        while (left < right) {
            if (c[left] + c[right] > 0) {
                answer += right - left;
                --right;
            } else {
                ++left;
            }
        }
        return answer;
    }
