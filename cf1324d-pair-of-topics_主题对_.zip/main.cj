package cf1324d

import std.convert.Parsable

func readArray(count: Int64): Array<Int64> {
    let values = Array<Int64>(count, repeat: 0)
    var index = 0
    for (part in readln().trimAscii().split(" ")) {
        if (!part.isEmpty()) {
            values[index] = Int64.parse(part)
            index += 1
        }
    }
    return values
}

main(): Unit {
    let n = Int64.parse(readln().trimAscii())
    let a = readArray(n)
    let b = readArray(n)
    println(solve(n, a, b))
}
