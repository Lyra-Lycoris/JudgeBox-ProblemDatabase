package cf1324d

func solve(n: Int64, a: Array<Int64>, b: Array<Int64>): Int64 {
    // TODO: 统计满足 a_i + a_j > b_i + b_j 的主题对 (i < j) 的数量
    return 0
}
