import sys


def solve(n: int, a: list[int], b: list[int]) -> int:
    c = [a[i] - b[i] for i in range(n)]
    c.sort()
    answer = 0
    left, right = 0, n - 1
    while left < right:
        if c[left] + c[right] > 0:
            answer += right - left
            right -= 1
        else:
            left += 1
    return answer
