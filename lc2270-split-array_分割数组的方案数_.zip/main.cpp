#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& nums);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    if (!(cin >> n)) return 0;
    vector<long long> nums(n);
    for (auto& x : nums) cin >> x;
    cout << solve(n, nums) << '\n';
    return 0;
}
