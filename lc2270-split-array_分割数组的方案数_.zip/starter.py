import sys


def solve(n: int, nums: list[int]) -> int:
    # TODO: 统计合法分割点个数
    return 0
