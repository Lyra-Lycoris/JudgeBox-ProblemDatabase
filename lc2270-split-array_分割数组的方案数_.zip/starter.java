    static long solve(int n, long[] nums) {
        // TODO: 统计合法分割点个数
        return 0;
    }
