package lc2270

func solve(n: Int64, nums: Array<Int64>): Int64 {
    // TODO: 统计合法分割点个数
    return 0
}
