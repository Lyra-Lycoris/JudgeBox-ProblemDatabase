package lc2270

import std.convert.Parsable

main(): Unit {
    let n = Int64.parse(readln().trimAscii())
    let nums = Array<Int64>(n, repeat: 0)
    var index = 0
    for (part in readln().trimAscii().split(" ")) {
        if (!part.isEmpty()) {
            nums[index] = Int64.parse(part)
            index += 1
        }
    }
    println(solve(n, nums))
}
