#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& nums) {
    // TODO: 统计合法分割点个数
    (void)n;
    (void)nums;
    return 0;
}
