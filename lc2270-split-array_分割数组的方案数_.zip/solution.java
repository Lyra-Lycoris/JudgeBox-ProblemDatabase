    static long solve(int n, long[] nums) {
        long total = 0;
        for (long x : nums) total += x;
        long prefix = 0, answer = 0;
        for (int i = 0; i + 1 < n; ++i) {
            prefix += nums[i];
            if (2 * prefix >= total) ++answer;
        }
        return answer;
    }
