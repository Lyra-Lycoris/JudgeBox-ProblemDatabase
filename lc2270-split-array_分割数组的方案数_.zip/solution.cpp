#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& nums) {
    long long total = 0;
    for (long long x : nums) total += x;
    long long prefix = 0, answer = 0;
    for (int i = 0; i + 1 < n; ++i) {
        prefix += nums[i];
        if (2 * prefix >= total) ++answer;
    }
    return answer;
}
