def solve(n: int, nums: list[int]) -> int:
    total = sum(nums)
    prefix = 0
    answer = 0
    for i in range(n - 1):
        prefix += nums[i]
        if 2 * prefix >= total:
            answer += 1
    return answer
