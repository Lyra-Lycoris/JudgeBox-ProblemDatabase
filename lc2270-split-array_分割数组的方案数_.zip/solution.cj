package lc2270

func solve(n: Int64, nums: Array<Int64>): Int64 {
    var total = 0
    for (x in nums) {
        total += x
    }
    var prefix = 0
    var answer = 0
    for (i in 0..n - 1) {
        prefix += nums[i]
        if (2 * prefix >= total) {
            answer += 1
        }
    }
    return answer
}
