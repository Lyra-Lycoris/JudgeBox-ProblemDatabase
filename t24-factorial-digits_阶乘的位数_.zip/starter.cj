package t24_factorial_digits

func solve(n: Int64): Int64 {
    // TODO: 返回 n! 的十进制位数
return 0
}
