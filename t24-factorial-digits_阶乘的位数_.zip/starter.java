    static long solve(long n) {
        // TODO: 返回 n! 的十进制位数
        return 0;
    }
