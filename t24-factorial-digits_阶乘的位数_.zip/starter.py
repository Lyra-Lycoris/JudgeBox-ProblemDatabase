import sys


def solve(n: int) -> int:
    # TODO: 返回 n! 的十进制位数
    return 0
