#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 n! 的十进制位数
return 0;
}
