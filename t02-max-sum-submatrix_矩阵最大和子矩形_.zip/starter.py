import sys


def solve(n: int, m: int, g: list[list[int]]) -> int:
    # TODO: 返回和最大的非空子矩形的元素和
    return 0
