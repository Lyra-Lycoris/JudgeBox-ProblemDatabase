package t02_max_sum_submatrix

func solve(n: Int64, m: Int64, g: Array<Array<Int64>>): Int64 {
    // TODO: 返回和最大的非空子矩形的元素和
return 0
}
