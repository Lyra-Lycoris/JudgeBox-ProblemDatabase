    static long solve(long n, long m, long[][] g) {
        // TODO: 返回和最大的非空子矩形的元素和
        return 0;
    }
