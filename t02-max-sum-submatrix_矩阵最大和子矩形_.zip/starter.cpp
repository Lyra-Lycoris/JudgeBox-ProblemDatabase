#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& g) {
    // TODO: 返回和最大的非空子矩形的元素和
return 0;
}
