#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& g);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    vector<vector<long long>> g(n, vector<long long>(m)); for (auto& row : g) for (auto& x : row) cin >> x;
    long long answer = solve(n, m, g);
    cout << answer << '\n';
    return 0;
}
