package t23_inversion_count

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回满足 i<j 且 a[i]>a[j] 的下标对个数
return 0
}
