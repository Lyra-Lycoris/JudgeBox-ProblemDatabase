#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& h) {
    // TODO: 返回总共能接住的雨水体积
return 0;
}
