import sys


def solve(n: int, h: list[int]) -> int:
    # TODO: 返回总共能接住的雨水体积
    return 0
