    static long solve(long n, long[] h) {
        // TODO: 返回总共能接住的雨水体积
        return 0;
    }
