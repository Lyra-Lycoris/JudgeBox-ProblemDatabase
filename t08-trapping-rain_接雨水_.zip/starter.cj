package t08_trapping_rain

func solve(n: Int64, h: Array<Int64>): Int64 {
    // TODO: 返回总共能接住的雨水体积
return 0
}
