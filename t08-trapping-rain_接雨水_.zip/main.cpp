#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& h);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> h(n); for (auto& x : h) cin >> x;
    long long answer = solve(n, h);
    cout << answer << '\n';
    return 0;
}
