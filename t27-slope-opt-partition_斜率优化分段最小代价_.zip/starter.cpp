#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long cost, const vector<long long>& a) {
    // TODO: 返回把数组划分成若干连续段后的最小总代价
return 0;
}
