    static long solve(long n, long cost, long[] a) {
        // TODO: 返回把数组划分成若干连续段后的最小总代价
        return 0;
    }
