import sys


def solve(n: int, cost: int, a: list[int]) -> int:
    # TODO: 返回把数组划分成若干连续段后的最小总代价
    return 0
