package t27_slope_opt_partition

func solve(n: Int64, cost: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把数组划分成若干连续段后的最小总代价
return 0
}
