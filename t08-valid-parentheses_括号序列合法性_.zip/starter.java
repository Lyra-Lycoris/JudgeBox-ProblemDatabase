    static boolean solve(String s) {
        // TODO: 判断括号序列是否合法：合法返回 true（输出 YES），否则返回 false（输出 NO）
        return false;
    }
