import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    s = data[pos].decode(); pos += 1
    print('YES' if solve(s) else 'NO')


main()
