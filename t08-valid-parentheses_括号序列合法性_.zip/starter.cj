package t08_valid_parentheses

func solve(s: String): Bool {
    // TODO: 判断括号序列是否合法：合法返回 true（输出 YES），否则返回 false（输出 NO）
return false
}
