#include <bits/stdc++.h>
using namespace std;

bool solve(string s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; cin >> s;
    bool answer = solve(s);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
