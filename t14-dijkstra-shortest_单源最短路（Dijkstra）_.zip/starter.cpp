#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, long long s, const vector<vector<long long>>& e) {
    // TODO: 返回 s 到 1..n 号点的最短距离，不可达记为 -1
return {};
}
