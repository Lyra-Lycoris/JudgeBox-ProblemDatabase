    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long m = Long.parseLong(st.nextToken());
        long s = Long.parseLong(st.nextToken());
        long[][] e = new long[(int) (m)][(int) (3)];
        for (int i = 0; i < e.length; ++i) for (int j = 0; j < e[i].length; ++j) e[i][j] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, m, s, e);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
