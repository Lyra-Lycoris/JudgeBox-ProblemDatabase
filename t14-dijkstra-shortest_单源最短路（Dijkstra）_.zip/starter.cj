package t14_dijkstra_shortest

func solve(n: Int64, m: Int64, s: Int64, e: Array<Array<Int64>>): Array<Int64> {
    // TODO: 返回 s 到 1..n 号点的最短距离，不可达记为 -1
return Array<Int64>()
}
