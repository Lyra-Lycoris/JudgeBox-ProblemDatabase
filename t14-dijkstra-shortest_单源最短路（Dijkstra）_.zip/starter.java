    static long[] solve(long n, long m, long s, long[][] e) {
        // TODO: 返回 s 到 1..n 号点的最短距离，不可达记为 -1
        return new long[0];
    }
