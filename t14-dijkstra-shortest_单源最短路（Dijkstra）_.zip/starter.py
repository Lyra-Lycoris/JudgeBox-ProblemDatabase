import sys


def solve(n: int, m: int, s: int, e: list[list[int]]) -> list[int]:
    # TODO: 返回 s 到 1..n 号点的最短距离，不可达记为 -1
    return []
