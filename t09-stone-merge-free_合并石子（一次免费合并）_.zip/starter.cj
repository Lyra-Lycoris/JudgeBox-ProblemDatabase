package t09_stone_merge_free

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把所有石子合并成一堆的最小总代价（允许一次免费合并）
return 0
}
