import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回把所有石子合并成一堆的最小总代价（允许一次免费合并）
    return 0
