#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a) {
    // TODO: 返回只出现一次的两个整数，按从小到大的顺序
return {};
}
