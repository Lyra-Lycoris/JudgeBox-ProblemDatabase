package t22_two_single_numbers

func solve(n: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回只出现一次的两个整数，按从小到大的顺序
return Array<Int64>()
}
