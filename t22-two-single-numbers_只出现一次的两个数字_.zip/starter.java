    static long[] solve(long n, long[] a) {
        // TODO: 返回只出现一次的两个整数，按从小到大的顺序
        return new long[0];
    }
