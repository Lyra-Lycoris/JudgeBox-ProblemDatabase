import sys


def solve(n: int, a: list[int]) -> list[int]:
    # TODO: 返回只出现一次的两个整数，按从小到大的顺序
    return []
