#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long r, const vector<long long>& ch) {
    // TODO: 返回之字形层序遍历得到的节点编号序列
return {};
}
