import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    r = int(data[pos]); pos += 1
    ch = [int(x) for x in data[pos:pos + 2*n]]; pos += 2*n
    print(' '.join(str(x) for x in solve(n, r, ch)))


main()
