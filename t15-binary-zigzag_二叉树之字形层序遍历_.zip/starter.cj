package t15_binary_zigzag

func solve(n: Int64, r: Int64, ch: Array<Int64>): Array<Int64> {
    // TODO: 返回之字形层序遍历得到的节点编号序列
return Array<Int64>()
}
