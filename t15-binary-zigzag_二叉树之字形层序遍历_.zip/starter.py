import sys


def solve(n: int, r: int, ch: list[int]) -> list[int]:
    # TODO: 返回之字形层序遍历得到的节点编号序列
    return []
