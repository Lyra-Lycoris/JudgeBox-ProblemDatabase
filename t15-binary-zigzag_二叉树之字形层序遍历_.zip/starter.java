    static long[] solve(long n, long r, long[] ch) {
        // TODO: 返回之字形层序遍历得到的节点编号序列
        return new long[0];
    }
