    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder sb = new StringBuilder();
        char[] buffer = new char[1 << 16];
        int read;
        while ((read = br.read(buffer)) != -1) {
            sb.append(buffer, 0, read);
        }
        StringTokenizer st = new StringTokenizer(sb.toString());
        int n = Integer.parseInt(st.nextToken());
        int k = Integer.parseInt(st.nextToken());
        long[] nums = new long[n];
        for (int i = 0; i < n; ++i) {
            nums[i] = Long.parseLong(st.nextToken());
        }
        System.out.println(solve(nums, k));
    }
