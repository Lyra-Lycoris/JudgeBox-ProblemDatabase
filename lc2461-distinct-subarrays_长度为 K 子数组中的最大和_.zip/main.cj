package lc2461

import std.convert.Parsable

main(): Unit {
    let head = readln().trimAscii().split(" ")
    var n = 0
    var k = 0
    var seen = 0
    for (part in head) {
        if (!part.isEmpty()) {
            if (seen == 0) {
                n = Int64.parse(part)
            } else if (seen == 1) {
                k = Int64.parse(part)
            }
            seen += 1
        }
    }
    let nums = Array<Int64>(n, repeat: 0)
    var index = 0
    while (index < n) {
        for (part in readln().trimAscii().split(" ")) {
            if (!part.isEmpty()) {
                nums[index] = Int64.parse(part)
                index += 1
            }
        }
    }
    println(solve(nums, k))
}
