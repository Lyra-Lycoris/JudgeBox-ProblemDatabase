def solve(nums: list[int], k: int) -> int:
    n = len(nums)
    if k <= 0 or k > n:
        return 0
    cnt = {}
    total = 0
    distinct = 0
    best = 0
    for i in range(n):
        x = nums[i]
        c = cnt.get(x, 0)
        if c == 0:
            distinct += 1
        cnt[x] = c + 1
        total += x
        if i >= k:
            y = nums[i - k]
            cy = cnt[y] - 1
            if cy == 0:
                del cnt[y]
                distinct -= 1
            else:
                cnt[y] = cy
            total -= y
        if i >= k - 1 and distinct == k and total > best:
            best = total
    return best
