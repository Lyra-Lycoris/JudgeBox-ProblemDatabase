#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& nums, long long k) {
    int n = (int)nums.size();
    if (k <= 0 || k > n) return 0;
    unordered_map<long long, int> cnt;
    cnt.reserve(static_cast<size_t>(n) * 2 + 16);
    long long sum = 0, best = 0;
    int distinct = 0;
    for (int i = 0; i < n; ++i) {
        long long x = nums[i];
        if (cnt[x]++ == 0) ++distinct;
        sum += x;
        if ((long long)i >= k) {
            long long y = nums[i - (int)k];
            if (--cnt[y] == 0) --distinct;
            sum -= y;
        }
        if ((long long)i >= k - 1 && distinct == k && sum > best) best = sum;
    }
    return best;
}
