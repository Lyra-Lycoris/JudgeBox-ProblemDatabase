#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& nums, long long k) {
    // TODO: 滑动窗口求长度为 k 且元素互不相同的子数组的最大和
    (void)nums;
    (void)k;
    return 0;
}
