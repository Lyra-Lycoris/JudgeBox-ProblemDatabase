    static long solve(long[] nums, int k) {
        // TODO: 滑动窗口求长度为 k 且元素互不相同的子数组的最大和
        return 0;
    }
