    static long solve(long[] nums, int k) {
        int n = nums.length;
        if (k <= 0 || k > n) return 0;
        HashMap<Long, Integer> cnt = new HashMap<>(n * 2 + 16);
        long sum = 0, best = 0;
        int distinct = 0;
        for (int i = 0; i < n; ++i) {
            long x = nums[i];
            int c = cnt.getOrDefault(x, 0);
            if (c == 0) ++distinct;
            cnt.put(x, c + 1);
            sum += x;
            if (i >= k) {
                long y = nums[i - k];
                int cy = cnt.get(y) - 1;
                if (cy == 0) {
                    cnt.remove(y);
                    --distinct;
                } else {
                    cnt.put(y, cy);
                }
                sum -= y;
            }
            if (i >= k - 1 && distinct == k && sum > best) best = sum;
        }
        return best;
    }
