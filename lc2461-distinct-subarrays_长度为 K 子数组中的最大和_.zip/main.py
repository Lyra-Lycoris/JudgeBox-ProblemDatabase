import sys


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    k = int(data[1])
    nums = [int(x) for x in data[2:2 + n]]
    print(solve(nums, k))


main()
