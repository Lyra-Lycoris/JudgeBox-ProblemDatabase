package lc2461

import std.collection.HashMap

func solve(nums: Array<Int64>, k: Int64): Int64 {
    let n = nums.size
    if (k <= 0 || k > n) {
        return 0
    }
    let cnt = HashMap<Int64, Int64>()
    var total: Int64 = 0
    var distinct: Int64 = 0
    var best: Int64 = 0
    for (i in 0..n) {
        let x = nums[i]
        let c = cnt.get(x) ?? 0
        if (c == 0) {
            distinct += 1
        }
        cnt[x] = c + 1
        total += x
        if (i >= k) {
            let y = nums[i - k]
            let cy = cnt.get(y) ?? 0
            if (cy == 1) {
                distinct -= 1
            }
            cnt[y] = cy - 1
            total -= y
        }
        if (i >= k - 1 && distinct == k && total > best) {
            best = total
        }
    }
    return best
}
