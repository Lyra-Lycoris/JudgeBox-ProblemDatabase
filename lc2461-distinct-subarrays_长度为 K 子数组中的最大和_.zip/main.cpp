#include <bits/stdc++.h>
using namespace std;

long long solve(const vector<long long>& nums, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long k;
    if (!(cin >> n >> k)) return 0;
    vector<long long> nums(n);
    for (auto& x : nums) cin >> x;
    cout << solve(nums, k) << '\n';
    return 0;
}
