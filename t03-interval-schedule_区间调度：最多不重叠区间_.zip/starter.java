    static long solve(long n, long[] l, long[] r) {
        // TODO: 返回最多能选出的互不重叠区间个数
        return 0;
    }
