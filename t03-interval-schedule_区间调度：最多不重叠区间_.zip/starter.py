import sys


def solve(n: int, l: list[int], r: list[int]) -> int:
    # TODO: 返回最多能选出的互不重叠区间个数
    return 0
