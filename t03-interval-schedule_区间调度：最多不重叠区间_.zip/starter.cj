package t03_interval_schedule

func solve(n: Int64, l: Array<Int64>, r: Array<Int64>): Int64 {
    // TODO: 返回最多能选出的互不重叠区间个数
return 0
}
