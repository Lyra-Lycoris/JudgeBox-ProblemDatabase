#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& l, const vector<long long>& r) {
    // TODO: 返回最多能选出的互不重叠区间个数
return 0;
}
