#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& l, const vector<long long>& r);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> l(n); for (auto& x : l) cin >> x;
    vector<long long> r(n); for (auto& x : r) cin >> x;
    long long answer = solve(n, l, r);
    cout << answer << '\n';
    return 0;
}
