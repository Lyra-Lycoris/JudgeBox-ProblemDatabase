import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    l = [int(x) for x in data[pos:pos + n]]; pos += n
    r = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, l, r))


main()
