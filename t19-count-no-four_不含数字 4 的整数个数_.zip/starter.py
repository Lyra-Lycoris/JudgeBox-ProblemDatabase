import sys


def solve(l: int, r: int) -> int:
    # TODO: 返回 [l, r] 中十进制表示不含数字 4 的整数个数
    return 0
