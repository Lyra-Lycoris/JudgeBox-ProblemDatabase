package t19_count_no_four

func solve(l: Int64, r: Int64): Int64 {
    // TODO: 返回 [l, r] 中十进制表示不含数字 4 的整数个数
return 0
}
