    static long solve(long l, long r) {
        // TODO: 返回 [l, r] 中十进制表示不含数字 4 的整数个数
        return 0;
    }
