    static long solve(long n, long k, long[] a) {
        // TODO: 返回数组中第 k 大的元素（k 从 1 开始，不去重）
        return 0;
    }
