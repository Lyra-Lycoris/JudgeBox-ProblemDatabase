package t09_kth_largest

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回数组中第 k 大的元素（k 从 1 开始，不去重）
return 0
}
