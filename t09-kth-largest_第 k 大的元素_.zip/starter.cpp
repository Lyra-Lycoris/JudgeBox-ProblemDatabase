#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回数组中第 k 大的元素（k 从 1 开始，不去重）
return 0;
}
