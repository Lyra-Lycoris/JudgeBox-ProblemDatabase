import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    p = [int(x) for x in data[pos:pos + n-1]]; pos += n-1
    print(' '.join(str(x) for x in solve(n, p)))


main()
