#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& p);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> p(n-1); for (auto& x : p) cin >> x;
    vector<long long> answer = solve(n, p);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
