#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& p) {
    // TODO: 返回 n 个整数，第 i 个是节点 i 到最远节点的距离
return {};
}
