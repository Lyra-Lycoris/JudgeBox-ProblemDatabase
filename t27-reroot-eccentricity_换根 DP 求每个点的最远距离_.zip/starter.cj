package t27_reroot_eccentricity

func solve(n: Int64, p: Array<Int64>): Array<Int64> {
    // TODO: 返回 n 个整数，第 i 个是节点 i 到最远节点的距离
return Array<Int64>()
}
