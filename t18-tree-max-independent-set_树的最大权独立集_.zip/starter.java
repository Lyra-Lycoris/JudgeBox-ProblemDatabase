    static long solve(long n, long[] w, long[] p) {
        // TODO: 返回树上不相邻点集的最大权值和（可以不选任何点，答案为 0 时表示不选）
        return 0;
    }
