package t18_tree_max_independent_set

func solve(n: Int64, w: Array<Int64>, p: Array<Int64>): Int64 {
    // TODO: 返回树上不相邻点集的最大权值和（可以不选任何点，答案为 0 时表示不选）
return 0
}
