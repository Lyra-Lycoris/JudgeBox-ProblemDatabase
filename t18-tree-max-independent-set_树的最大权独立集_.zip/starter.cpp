#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& w, const vector<long long>& p) {
    // TODO: 返回树上不相邻点集的最大权值和（可以不选任何点，答案为 0 时表示不选）
return 0;
}
