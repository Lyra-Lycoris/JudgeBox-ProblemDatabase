import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    w = [int(x) for x in data[pos:pos + n]]; pos += n
    p = [int(x) for x in data[pos:pos + n-1]]; pos += n-1
    print(solve(n, w, p))


main()
