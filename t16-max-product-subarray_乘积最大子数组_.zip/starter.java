    static long solve(long n, long[] a) {
        // TODO: 返回所有非空连续子数组乘积的最大值
        return 0;
    }
