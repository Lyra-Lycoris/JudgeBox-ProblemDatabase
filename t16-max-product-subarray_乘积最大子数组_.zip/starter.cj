package t16_max_product_subarray

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回所有非空连续子数组乘积的最大值
return 0
}
