def solve(n: int, a: list[int]) -> int:
    count = {}
    answer = 0
    for i in range(n):
        key = a[i] - i - 1
        previous = count.get(key, 0)
        answer += previous
        count[key] = previous + 1
    return answer
