package cf1520d

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 统计满足 a[j] - a[i] == j - i 的下标对个数
    return 0
}
