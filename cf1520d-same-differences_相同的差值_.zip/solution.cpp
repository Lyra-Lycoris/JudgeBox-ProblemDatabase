#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a) {
    unordered_map<long long, long long> count;
    count.reserve(static_cast<size_t>(n) * 2 + 16);
    long long answer = 0;
    for (int i = 0; i < n; ++i) {
        long long key = a[i] - (i + 1);
        long long& previous = count[key];
        answer += previous;
        ++previous;
    }
    return answer;
}
