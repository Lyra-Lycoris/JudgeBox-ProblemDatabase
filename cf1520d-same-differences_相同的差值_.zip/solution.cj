package cf1520d

import std.collection.HashMap

func solve(n: Int64, a: Array<Int64>): Int64 {
    let count = HashMap<Int64, Int64>()
    var answer = 0
    for (i in 0..n) {
        let key = a[i] - (i + 1)
        let previous = count.get(key) ?? 0
        answer += previous
        count[key] = previous + 1
    }
    return answer
}
