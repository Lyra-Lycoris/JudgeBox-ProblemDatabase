    static long solve(int n, long[] a) {
        // TODO: 统计满足 a[j] - a[i] == j - i 的下标对个数
        return 0;
    }
