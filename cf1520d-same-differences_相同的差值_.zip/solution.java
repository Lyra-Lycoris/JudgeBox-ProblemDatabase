    static long solve(int n, long[] a) {
        HashMap<Long, Long> count = new HashMap<>(Math.max(16, n * 2));
        long answer = 0;
        for (int i = 0; i < n; ++i) {
            long key = a[i] - (i + 1);
            Long boxed = count.get(key);
            long previous = boxed == null ? 0L : boxed;
            answer += previous;
            count.put(key, previous + 1);
        }
        return answer;
    }
