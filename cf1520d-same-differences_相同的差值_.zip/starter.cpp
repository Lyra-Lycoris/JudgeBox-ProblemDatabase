#include <bits/stdc++.h>
using namespace std;

long long solve(int n, const vector<long long>& a) {
    // TODO: 统计满足 a[j] - a[i] == j - i 的下标对个数
    (void)n;
    (void)a;
    return 0;
}
