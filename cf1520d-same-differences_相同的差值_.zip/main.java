    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        int n = Integer.parseInt(br.readLine().trim());
        long[] a = new long[n];
        StringBuilder sb = new StringBuilder();
        char[] buffer = new char[1 << 16];
        int read;
        while ((read = br.read(buffer)) > 0) sb.append(buffer, 0, read);
        StringTokenizer st = new StringTokenizer(sb.toString());
        for (int i = 0; i < n && st.hasMoreTokens(); ++i) a[i] = Long.parseLong(st.nextToken());
        System.out.println(solve(n, a));
    }
