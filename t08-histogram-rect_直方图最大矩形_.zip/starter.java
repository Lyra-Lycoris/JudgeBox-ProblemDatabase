    static long solve(long n, long[] h) {
        // TODO: 返回直方图中能画出的最大矩形面积
        return 0;
    }
