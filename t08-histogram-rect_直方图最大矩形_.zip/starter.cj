package t08_histogram_rect

func solve(n: Int64, h: Array<Int64>): Int64 {
    // TODO: 返回直方图中能画出的最大矩形面积
return 0
}
