#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& h) {
    // TODO: 返回直方图中能画出的最大矩形面积
return 0;
}
