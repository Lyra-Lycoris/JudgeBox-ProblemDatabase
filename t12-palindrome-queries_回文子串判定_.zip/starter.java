    static long[] solve(long n, String s, long q, long[][] qs) {
        // TODO: 对每个询问返回 1（子串是回文）或 0（不是）
        return new long[0];
    }
