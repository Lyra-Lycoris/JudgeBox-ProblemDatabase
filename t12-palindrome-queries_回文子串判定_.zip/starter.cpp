#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, string s, long long q, const vector<vector<long long>>& qs) {
    // TODO: 对每个询问返回 1（子串是回文）或 0（不是）
return {};
}
