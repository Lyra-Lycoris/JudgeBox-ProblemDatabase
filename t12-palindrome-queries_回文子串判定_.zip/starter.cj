package t12_palindrome_queries

func solve(n: Int64, s: String, q: Int64, qs: Array<Array<Int64>>): Array<Int64> {
    // TODO: 对每个询问返回 1（子串是回文）或 0（不是）
return Array<Int64>()
}
