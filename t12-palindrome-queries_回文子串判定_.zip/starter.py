import sys


def solve(n: int, s: str, q: int, qs: list[list[int]]) -> list[int]:
    # TODO: 对每个询问返回 1（子串是回文）或 0（不是）
    return []
