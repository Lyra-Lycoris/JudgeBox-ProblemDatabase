import sys


def solve(k: int, s: str) -> int:
    # TODO: 返回不同字符个数不超过 k 的最长子串长度
    return 0
