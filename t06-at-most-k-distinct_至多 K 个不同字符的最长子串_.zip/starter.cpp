#include <bits/stdc++.h>
using namespace std;

long long solve(long long k, string s) {
    // TODO: 返回不同字符个数不超过 k 的最长子串长度
return 0;
}
