package t06_at_most_k_distinct

func solve(k: Int64, s: String): Int64 {
    // TODO: 返回不同字符个数不超过 k 的最长子串长度
return 0
}
