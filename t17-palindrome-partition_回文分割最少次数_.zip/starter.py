import sys


def solve(s: str) -> int:
    # TODO: 返回把 s 切成若干回文串所需的最少刀数
    return 0
