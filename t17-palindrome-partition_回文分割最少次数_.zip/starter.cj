package t17_palindrome_partition

func solve(s: String): Int64 {
    // TODO: 返回把 s 切成若干回文串所需的最少刀数
return 0
}
