#include <bits/stdc++.h>
using namespace std;

long long solve(string s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s; cin >> s;
    long long answer = solve(s);
    cout << answer << '\n';
    return 0;
}
