    static long solve(String s) {
        // TODO: 返回把 s 切成若干回文串所需的最少刀数
        return 0;
    }
