package t20_fast_pow

func solve(a: Int64, b: Int64, m: Int64): Int64 {
    // TODO: 返回 a 的 b 次方对 m 取模的结果
return 0
}
