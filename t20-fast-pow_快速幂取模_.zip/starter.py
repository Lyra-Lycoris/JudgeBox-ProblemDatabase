import sys


def solve(a: int, b: int, m: int) -> int:
    # TODO: 返回 a 的 b 次方对 m 取模的结果
    return 0
