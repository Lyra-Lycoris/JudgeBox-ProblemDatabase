#include <bits/stdc++.h>
using namespace std;

long long solve(long long a, long long b, long long m) {
    // TODO: 返回 a 的 b 次方对 m 取模的结果
return 0;
}
