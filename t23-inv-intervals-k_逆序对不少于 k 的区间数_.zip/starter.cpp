#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回逆序对个数不少于 k 的连续子区间个数
return 0;
}
