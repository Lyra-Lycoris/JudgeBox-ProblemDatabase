package t23_inv_intervals_k

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回逆序对个数不少于 k 的连续子区间个数
return 0
}
