    static long solve(long n, long k, long[] a) {
        // TODO: 返回逆序对个数不少于 k 的连续子区间个数
        return 0;
    }
