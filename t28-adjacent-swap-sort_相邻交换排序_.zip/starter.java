    static long solve(long n, long[] a) {
        // TODO: 返回把序列变成非降序所需的最少相邻交换次数
        return 0;
    }
