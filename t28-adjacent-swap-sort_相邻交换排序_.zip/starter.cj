package t28_adjacent_swap_sort

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回把序列变成非降序所需的最少相邻交换次数
return 0
}
