#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& xs, const vector<long long>& ys) {
    // TODO: 返回多边形面积的二倍（即鞋带公式求和的绝对值）
return 0;
}
