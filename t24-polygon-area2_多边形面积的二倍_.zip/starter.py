import sys


def solve(n: int, xs: list[int], ys: list[int]) -> int:
    # TODO: 返回多边形面积的二倍（即鞋带公式求和的绝对值）
    return 0
