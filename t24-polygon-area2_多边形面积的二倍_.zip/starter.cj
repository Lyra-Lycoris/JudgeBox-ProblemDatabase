package t24_polygon_area2

func solve(n: Int64, xs: Array<Int64>, ys: Array<Int64>): Int64 {
    // TODO: 返回多边形面积的二倍（即鞋带公式求和的绝对值）
return 0
}
