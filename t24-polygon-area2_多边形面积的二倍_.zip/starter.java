    static long solve(long n, long[] xs, long[] ys) {
        // TODO: 返回多边形面积的二倍（即鞋带公式求和的绝对值）
        return 0;
    }
