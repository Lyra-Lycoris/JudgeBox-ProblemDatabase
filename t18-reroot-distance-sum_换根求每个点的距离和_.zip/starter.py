import sys


def solve(n: int, p: list[int]) -> list[int]:
    # TODO: 返回 n 个整数，第 i 个是节点 i 到其余所有节点的距离之和
    return []
