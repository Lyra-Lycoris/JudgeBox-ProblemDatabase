package t18_reroot_distance_sum

func solve(n: Int64, p: Array<Int64>): Array<Int64> {
    // TODO: 返回 n 个整数，第 i 个是节点 i 到其余所有节点的距离之和
return Array<Int64>()
}
