package t21_derangement

func solve(n: Int64): Int64 {
    // TODO: 返回 n 个元素的错排数（没有任何元素留在原位的排列数）对 1000000007 取模的结果
return 0
}
