#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& w, long long d);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> w(n); for (auto& x : w) cin >> x;
    long long d; cin >> d;
    long long answer = solve(n, w, d);
    cout << answer << '\n';
    return 0;
}
