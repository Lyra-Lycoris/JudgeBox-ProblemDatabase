import sys


def solve(n: int, w: list[int], d: int) -> int:
    # TODO: 返回在 d 天内按顺序运完所有货物所需的最小单日运载容量
    return 0
