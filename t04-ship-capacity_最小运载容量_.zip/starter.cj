package t04_ship_capacity

func solve(n: Int64, w: Array<Int64>, d: Int64): Int64 {
    // TODO: 返回在 d 天内按顺序运完所有货物所需的最小单日运载容量
return 0
}
