#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& w, long long d) {
    // TODO: 返回在 d 天内按顺序运完所有货物所需的最小单日运载容量
return 0;
}
