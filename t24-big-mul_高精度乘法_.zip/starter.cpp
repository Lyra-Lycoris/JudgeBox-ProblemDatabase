#include <bits/stdc++.h>
using namespace std;

string solve(string a, string b) {
    // TODO: 返回 a*b 的十进制字符串（不含前导零）
return "";
}
