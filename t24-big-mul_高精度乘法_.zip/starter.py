import sys


def solve(a: str, b: str) -> str:
    # TODO: 返回 a*b 的十进制字符串（不含前导零）
    return ""
