import sys


def solve(n: int, a: list[int]) -> int:
    # TODO: 返回满足 a[i]+a[j]+a[k]=0（i<j<k）的三元组个数
    return 0
