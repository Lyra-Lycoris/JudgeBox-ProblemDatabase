package t06_three_sum_zero_count

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回满足 a[i]+a[j]+a[k]=0（i<j<k）的三元组个数
return 0
}
