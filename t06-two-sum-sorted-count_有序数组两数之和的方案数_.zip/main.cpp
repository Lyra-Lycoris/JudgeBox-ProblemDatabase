#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long target, const vector<long long>& a);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long target; cin >> target;
    vector<long long> a(n); for (auto& x : a) cin >> x;
    long long answer = solve(n, target, a);
    cout << answer << '\n';
    return 0;
}
