import sys


def solve(n: int, target: int, a: list[int]) -> int:
    # TODO: 返回满足 a[i]+a[j]=target（i<j）的下标对数
    return 0
