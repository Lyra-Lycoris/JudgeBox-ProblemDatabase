package t06_two_sum_sorted_count

func solve(n: Int64, target: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回满足 a[i]+a[j]=target（i<j）的下标对数
return 0
}
