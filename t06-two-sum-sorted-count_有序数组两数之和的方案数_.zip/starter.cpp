#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long target, const vector<long long>& a) {
    // TODO: 返回满足 a[i]+a[j]=target（i<j）的下标对数
return 0;
}
