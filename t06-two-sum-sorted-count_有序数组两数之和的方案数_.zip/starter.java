    static long solve(long n, long target, long[] a) {
        // TODO: 返回满足 a[i]+a[j]=target（i<j）的下标对数
        return 0;
    }
