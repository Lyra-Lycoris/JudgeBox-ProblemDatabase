#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, string s) {
    // TODO: 返回字符串 s 的不同非空子序列个数对 1000000007 取模的结果
return 0;
}
