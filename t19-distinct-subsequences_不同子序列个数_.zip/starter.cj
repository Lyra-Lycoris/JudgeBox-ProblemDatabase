package t19_distinct_subsequences

func solve(n: Int64, s: String): Int64 {
    // TODO: 返回字符串 s 的不同非空子序列个数对 1000000007 取模的结果
return 0
}
