import sys


def solve(n: int, s: str) -> int:
    # TODO: 返回字符串 s 的不同非空子序列个数对 1000000007 取模的结果
    return 0
