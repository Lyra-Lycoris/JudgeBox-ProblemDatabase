package t21_expected_inversion_swap

func solve(n: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回等概率随机选一对下标并交换后，数组逆序对数的期望，按 p * q^{-1} mod 1000000007 输出
return 0
}
