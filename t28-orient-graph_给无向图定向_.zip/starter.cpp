#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 依次输出每条边的方向：a_i 指向 b_i（共 2m 个整数）；无解时只输出一个 -1
return {};
}
