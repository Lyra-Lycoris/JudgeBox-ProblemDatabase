    static long[] solve(long n, long m, long[][] e) {
        // TODO: 依次输出每条边的方向：a_i 指向 b_i（共 2m 个整数）；无解时只输出一个 -1
        return new long[0];
    }
