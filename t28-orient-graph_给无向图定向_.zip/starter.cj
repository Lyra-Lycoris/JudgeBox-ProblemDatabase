package t28_orient_graph

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Array<Int64> {
    // TODO: 依次输出每条边的方向：a_i 指向 b_i（共 2m 个整数）；无解时只输出一个 -1
return Array<Int64>()
}
