#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long m, const vector<long long>& b) {
    // TODO: 返回合并后数组中位数的两倍（一定是整数）
return 0;
}
