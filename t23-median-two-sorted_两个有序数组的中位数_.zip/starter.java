    static long solve(long n, long[] a, long m, long[] b) {
        // TODO: 返回合并后数组中位数的两倍（一定是整数）
        return 0;
    }
