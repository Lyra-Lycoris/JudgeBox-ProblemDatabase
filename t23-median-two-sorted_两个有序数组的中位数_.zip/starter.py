import sys


def solve(n: int, a: list[int], m: int, b: list[int]) -> int:
    # TODO: 返回合并后数组中位数的两倍（一定是整数）
    return 0
