package t23_median_two_sorted

func solve(n: Int64, a: Array<Int64>, m: Int64, b: Array<Int64>): Int64 {
    // TODO: 返回合并后数组中位数的两倍（一定是整数）
return 0
}
