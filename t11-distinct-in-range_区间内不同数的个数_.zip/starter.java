    static long[] solve(long n, long[] a, long q, long[][] queries) {
        // TODO: 按顺序返回每个询问区间内不同数值的个数
        return new long[0];
    }
