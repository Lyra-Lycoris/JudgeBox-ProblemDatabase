package t11_distinct_in_range

func solve(n: Int64, a: Array<Int64>, q: Int64, queries: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每个询问区间内不同数值的个数
return Array<Int64>()
}
