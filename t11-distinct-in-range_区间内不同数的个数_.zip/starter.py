import sys


def solve(n: int, a: list[int], q: int, queries: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每个询问区间内不同数值的个数
    return []
