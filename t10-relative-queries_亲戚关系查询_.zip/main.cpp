#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<vector<long long>>& rel, long long q, const vector<vector<long long>>& qs);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<vector<long long>> rel(k, vector<long long>(2)); for (auto& row : rel) for (auto& x : row) cin >> x;
    long long q; cin >> q;
    vector<vector<long long>> qs(q, vector<long long>(2)); for (auto& row : qs) for (auto& x : row) cin >> x;
    long long answer = solve(n, k, rel, q, qs);
    cout << answer << '\n';
    return 0;
}
