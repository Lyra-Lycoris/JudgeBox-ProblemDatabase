    static long solve(long n, long k, long[][] rel, long q, long[][] qs) {
        // TODO: 返回有多少个询问中的两个人是亲戚
        return 0;
    }
