import sys


def solve(n: int, k: int, rel: list[list[int]], q: int, qs: list[list[int]]) -> int:
    # TODO: 返回有多少个询问中的两个人是亲戚
    return 0
