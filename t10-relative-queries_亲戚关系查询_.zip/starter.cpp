#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<vector<long long>>& rel, long long q, const vector<vector<long long>>& qs) {
    // TODO: 返回有多少个询问中的两个人是亲戚
return 0;
}
