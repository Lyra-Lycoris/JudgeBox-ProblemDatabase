package t10_relative_queries

func solve(n: Int64, k: Int64, rel: Array<Array<Int64>>, q: Int64, qs: Array<Array<Int64>>): Int64 {
    // TODO: 返回有多少个询问中的两个人是亲戚
return 0
}
