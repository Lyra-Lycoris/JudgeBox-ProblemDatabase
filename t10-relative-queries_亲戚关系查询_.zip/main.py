import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    rel = [[int(x) for x in data[pos + r * 2: pos + (r + 1) * 2]] for r in range(k)]
    pos += k * 2
    q = int(data[pos]); pos += 1
    qs = [[int(x) for x in data[pos + r * 2: pos + (r + 1) * 2]] for r in range(q)]
    pos += q * 2
    print(solve(n, k, rel, q, qs))


main()
