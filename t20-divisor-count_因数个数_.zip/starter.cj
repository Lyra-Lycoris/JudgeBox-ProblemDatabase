package t20_divisor_count

func solve(n: Int64): Int64 {
    // TODO: 返回 n 的正因数个数
return 0
}
