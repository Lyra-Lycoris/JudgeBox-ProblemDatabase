#include <bits/stdc++.h>
using namespace std;

long long solve(long long n);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long answer = solve(n);
    cout << answer << '\n';
    return 0;
}
