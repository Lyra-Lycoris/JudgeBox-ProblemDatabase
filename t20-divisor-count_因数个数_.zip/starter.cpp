#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    // TODO: 返回 n 的正因数个数
return 0;
}
