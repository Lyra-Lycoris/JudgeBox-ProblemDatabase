import sys


def solve(n: int) -> int:
    # TODO: 返回 n 的正因数个数
    return 0
