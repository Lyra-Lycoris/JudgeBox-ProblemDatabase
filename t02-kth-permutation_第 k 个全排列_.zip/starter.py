import sys


def solve(n: int, k: int) -> list[int]:
    # TODO: 返回 1..n 按字典序排列后的第 k 个排列（k 从 1 开始）
    return []
