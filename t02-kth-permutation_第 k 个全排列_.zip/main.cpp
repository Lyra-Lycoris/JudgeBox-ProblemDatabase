#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<long long> answer = solve(n, k);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
