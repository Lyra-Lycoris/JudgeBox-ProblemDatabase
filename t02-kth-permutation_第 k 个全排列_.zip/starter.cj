package t02_kth_permutation

func solve(n: Int64, k: Int64): Array<Int64> {
    // TODO: 返回 1..n 按字典序排列后的第 k 个排列（k 从 1 开始）
return Array<Int64>()
}
