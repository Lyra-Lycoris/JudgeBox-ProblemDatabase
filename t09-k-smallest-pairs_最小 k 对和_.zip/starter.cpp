#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, long long k, const vector<long long>& a, const vector<long long>& b) {
    // TODO: 返回最小的 k 个 a[i]+b[j]，按非降序排列
return {};
}
