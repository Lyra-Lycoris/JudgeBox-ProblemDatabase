import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    a = [int(x) for x in data[pos:pos + n]]; pos += n
    b = [int(x) for x in data[pos:pos + m]]; pos += m
    print(' '.join(str(x) for x in solve(n, m, k, a, b)))


main()
