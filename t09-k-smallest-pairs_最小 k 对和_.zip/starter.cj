package t09_k_smallest_pairs

func solve(n: Int64, m: Int64, k: Int64, a: Array<Int64>, b: Array<Int64>): Array<Int64> {
    // TODO: 返回最小的 k 个 a[i]+b[j]，按非降序排列
return Array<Int64>()
}
