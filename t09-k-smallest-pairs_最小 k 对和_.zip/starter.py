import sys


def solve(n: int, m: int, k: int, a: list[int], b: list[int]) -> list[int]:
    # TODO: 返回最小的 k 个 a[i]+b[j]，按非降序排列
    return []
