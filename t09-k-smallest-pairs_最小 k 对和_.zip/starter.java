    static long[] solve(long n, long m, long k, long[] a, long[] b) {
        // TODO: 返回最小的 k 个 a[i]+b[j]，按非降序排列
        return new long[0];
    }
