#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long m, long long k, const vector<long long>& a, const vector<long long>& b);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long m; cin >> m;
    long long k; cin >> k;
    vector<long long> a(n); for (auto& x : a) cin >> x;
    vector<long long> b(m); for (auto& x : b) cin >> x;
    vector<long long> answer = solve(n, m, k, a, b);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
