#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<vector<long long>>& w) {
    // TODO: 返回 n×n 个整数，第 (i,j) 个是点 i 到点 j 的最短距离，不可达为 -1
return {};
}
