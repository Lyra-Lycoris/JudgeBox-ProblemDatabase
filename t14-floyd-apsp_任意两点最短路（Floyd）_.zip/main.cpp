#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<vector<long long>>& w);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<vector<long long>> w(n, vector<long long>(n)); for (auto& row : w) for (auto& x : row) cin >> x;
    vector<long long> answer = solve(n, w);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
