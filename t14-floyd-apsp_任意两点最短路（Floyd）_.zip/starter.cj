package t14_floyd_apsp

func solve(n: Int64, w: Array<Array<Int64>>): Array<Int64> {
    // TODO: 返回 n×n 个整数，第 (i,j) 个是点 i 到点 j 的最短距离，不可达为 -1
return Array<Int64>()
}
