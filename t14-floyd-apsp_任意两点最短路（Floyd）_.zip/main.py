import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    w = [[int(x) for x in data[pos + r * n: pos + (r + 1) * n]] for r in range(n)]
    pos += n * n
    print(' '.join(str(x) for x in solve(n, w)))


main()
