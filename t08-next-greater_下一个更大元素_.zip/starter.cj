package t08_next_greater

func solve(n: Int64, a: Array<Int64>): Array<Int64> {
    // TODO: 返回长度为 n 的数组，第 i 个数是 a[i] 右边第一个比它大的数，不存在则填 -1
return Array<Int64>()
}
