import sys


def solve(n: int, a: list[int]) -> list[int]:
    # TODO: 返回长度为 n 的数组，第 i 个数是 a[i] 右边第一个比它大的数，不存在则填 -1
    return []
