import sys


def solve(n: int) -> list[int]:
    # TODO: 返回任意一个使相邻元素差的绝对值之和最大的 1..n 排列；本题使用特殊评判
    return []
