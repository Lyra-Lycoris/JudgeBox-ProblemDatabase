package t26_bit_lifting_kth

func solve(n: Int64, a: Array<Int64>, q: Int64, ops: Array<Array<Int64>>): Array<Int64> {
    // TODO: 按顺序返回每次第 k 小询问的答案
return Array<Int64>()
}
