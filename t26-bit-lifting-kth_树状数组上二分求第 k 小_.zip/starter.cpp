#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& a, long long q, const vector<vector<long long>>& ops) {
    // TODO: 按顺序返回每次第 k 小询问的答案
return {};
}
