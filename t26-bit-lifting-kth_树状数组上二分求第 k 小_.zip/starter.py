import sys


def solve(n: int, a: list[int], q: int, ops: list[list[int]]) -> list[int]:
    # TODO: 按顺序返回每次第 k 小询问的答案
    return []
