package t15_lca_queries

func solve(n: Int64, e: Array<Int64>, q: Int64, queries: Array<Int64>): Array<Int64> {
    // TODO: 返回 q 个整数：每次询问的两个节点的最近公共祖先编号
return Array<Int64>()
}
