    static long[] solve(long n, long[] e, long q, long[] queries) {
        // TODO: 返回 q 个整数：每次询问的两个节点的最近公共祖先编号
        return new long[0];
    }
