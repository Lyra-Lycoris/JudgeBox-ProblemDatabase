import sys


def solve(n: int, e: list[int], q: int, queries: list[int]) -> list[int]:
    # TODO: 返回 q 个整数：每次询问的两个节点的最近公共祖先编号
    return []
