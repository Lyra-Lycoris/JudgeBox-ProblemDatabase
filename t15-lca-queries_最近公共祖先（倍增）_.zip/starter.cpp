#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, const vector<long long>& e, long long q, const vector<long long>& queries) {
    // TODO: 返回 q 个整数：每次询问的两个节点的最近公共祖先编号
return {};
}
