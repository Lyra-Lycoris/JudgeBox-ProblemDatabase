    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long[] e = new long[(int) (2*(n-1))];
        for (int i = 0; i < e.length; ++i) e[i] = Long.parseLong(st.nextToken());
        long q = Long.parseLong(st.nextToken());
        long[] queries = new long[(int) (2*q)];
        for (int i = 0; i < queries.length; ++i) queries[i] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, e, q, queries);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
