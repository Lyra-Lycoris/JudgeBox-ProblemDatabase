package t17_course_tree_knapsack

func solve(n: Int64, k: Int64, parent: Array<Int64>, profit: Array<Int64>): Int64 {
    // TODO: 返回恰好选 k 门课（含先修约束）时的最大总收益
return 0
}
