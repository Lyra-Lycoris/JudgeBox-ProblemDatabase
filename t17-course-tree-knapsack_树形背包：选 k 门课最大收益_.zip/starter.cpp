#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& parent, const vector<long long>& profit) {
    // TODO: 返回恰好选 k 门课（含先修约束）时的最大总收益
return 0;
}
