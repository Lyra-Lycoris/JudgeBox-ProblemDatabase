    static long solve(long n, long k, long[] parent, long[] profit) {
        // TODO: 返回恰好选 k 门课（含先修约束）时的最大总收益
        return 0;
    }
