import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    parent = [int(x) for x in data[pos:pos + n]]; pos += n
    profit = [int(x) for x in data[pos:pos + n]]; pos += n
    print(solve(n, k, parent, profit))


main()
