import sys


def solve(n: int, k: int, parent: list[int], profit: list[int]) -> int:
    # TODO: 返回恰好选 k 门课（含先修约束）时的最大总收益
    return 0
