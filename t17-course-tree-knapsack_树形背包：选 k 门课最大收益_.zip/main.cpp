#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& parent, const vector<long long>& profit);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<long long> parent(n); for (auto& x : parent) cin >> x;
    vector<long long> profit(n); for (auto& x : profit) cin >> x;
    long long answer = solve(n, k, parent, profit);
    cout << answer << '\n';
    return 0;
}
