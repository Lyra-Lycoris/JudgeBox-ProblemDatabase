    static long solve(long n, long m, long[][] e) {
        // TODO: 返回最小生成树的总权重
        return 0;
    }
