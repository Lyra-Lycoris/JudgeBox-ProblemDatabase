#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回最小生成树的总权重
return 0;
}
