import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回最小生成树的总权重
    return 0
