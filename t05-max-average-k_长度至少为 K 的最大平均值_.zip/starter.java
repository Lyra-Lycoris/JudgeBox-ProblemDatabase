    static long solve(long n, long k, long[] a) {
        // TODO: 返回 1000 倍最大平均值的下取整，二分答案 + 前缀和判定
        return 0;
    }
