package t05_max_average_k

func solve(n: Int64, k: Int64, a: Array<Int64>): Int64 {
    // TODO: 返回 1000 倍最大平均值的下取整，二分答案 + 前缀和判定
return 0
}
