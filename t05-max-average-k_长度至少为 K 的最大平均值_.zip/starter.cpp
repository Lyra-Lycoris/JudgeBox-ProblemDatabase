#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long k, const vector<long long>& a) {
    // TODO: 返回 1000 倍最大平均值的下取整，二分答案 + 前缀和判定
return 0;
}
