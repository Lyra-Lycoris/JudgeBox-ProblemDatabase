#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, long long m, const vector<vector<long long>>& e) {
    // TODO: 返回 1 到 n 的严格次短路长度，不存在则返回 -1
return 0;
}
