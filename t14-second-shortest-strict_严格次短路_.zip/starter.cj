package t14_second_shortest_strict

func solve(n: Int64, m: Int64, e: Array<Array<Int64>>): Int64 {
    // TODO: 返回 1 到 n 的严格次短路长度，不存在则返回 -1
return 0
}
