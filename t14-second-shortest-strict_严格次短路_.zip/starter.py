import sys


def solve(n: int, m: int, e: list[list[int]]) -> int:
    # TODO: 返回 1 到 n 的严格次短路长度，不存在则返回 -1
    return 0
