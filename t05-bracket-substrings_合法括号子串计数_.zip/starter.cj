package t05_bracket_substrings

func solve(s: String): Int64 {
    // TODO: 返回满足合法括号序列的连续子串个数
return 0
}
