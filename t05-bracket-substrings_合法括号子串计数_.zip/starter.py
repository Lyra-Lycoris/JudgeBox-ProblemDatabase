import sys


def solve(s: str) -> int:
    # TODO: 返回满足合法括号序列的连续子串个数
    return 0
