#include <bits/stdc++.h>
using namespace std;

long long solve(string s) {
    // TODO: 返回满足合法括号序列的连续子串个数
return 0;
}
