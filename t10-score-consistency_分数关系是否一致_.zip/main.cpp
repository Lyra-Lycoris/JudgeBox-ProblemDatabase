#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long k, const vector<vector<long long>>& rel);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<vector<long long>> rel(k, vector<long long>(3)); for (auto& row : rel) for (auto& x : row) cin >> x;
    bool answer = solve(n, k, rel);
    cout << (answer ? "YES" : "NO") << '\n';
    return 0;
}
