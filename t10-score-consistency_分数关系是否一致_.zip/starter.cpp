#include <bits/stdc++.h>
using namespace std;

bool solve(long long n, long long k, const vector<vector<long long>>& rel) {
    // TODO: 返回是否所有陈述可以同时成立
return false;
}
