    static boolean solve(long n, long k, long[][] rel) {
        // TODO: 返回是否所有陈述可以同时成立
        return false;
    }
