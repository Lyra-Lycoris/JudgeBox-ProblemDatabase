import sys


def solve(n: int, k: int, rel: list[list[int]]) -> bool:
    # TODO: 返回是否所有陈述可以同时成立
    return False
