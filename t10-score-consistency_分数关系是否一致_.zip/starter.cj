package t10_score_consistency

func solve(n: Int64, k: Int64, rel: Array<Array<Int64>>): Bool {
    // TODO: 返回是否所有陈述可以同时成立
return false
}
