package t18_min_set_partition

func solve(n: Int64, c: Array<Int64>): Int64 {
    // TODO: 返回把 n 个物品划分成若干非空组的最小总代价，c[S] 是把集合 S 装进一组的代价
return 0
}
