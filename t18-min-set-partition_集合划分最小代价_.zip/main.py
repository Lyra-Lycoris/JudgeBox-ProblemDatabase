import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    c_n = int(data[pos]); pos += 1
    c = [int(x) for x in data[pos:pos + c_n]]; pos += c_n
    print(solve(n, c))


main()
