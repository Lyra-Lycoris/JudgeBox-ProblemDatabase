#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& c);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    int c_n; cin >> c_n; vector<long long> c(c_n); for (auto& x : c) cin >> x;
    long long answer = solve(n, c);
    cout << answer << '\n';
    return 0;
}
